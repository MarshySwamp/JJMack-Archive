// A Photoshop Script by JJMack's used by Action in image effects

// This script is supplied as is. It is provided as freeware. 
// The author accepts no liability for any problems arising from its use.

#target photoshop
app.bringToFront();

/*
<javascriptresource>
<name>DeleteDisplacementMap</name>
<about>$$$/JavaScripts/DeleteDisplacementMap/About=JJMack's DeleteDisplacementMap.^r^rCopyright 2010 Mouseprints.^r^rScript utility for action.^rNOTE:Delete DisplacementMap.psd on Users Desktop</about>
<category>JJMack's Action Utility</category>
</javascriptresource>
*/

try{
   var mapfile =  new File('~/Desktop/DisplacementMap.psd');
   //alert("mapfile = " + mapfile);
   mapfile.remove();
}catch(e){
alert("Error, Can Not Open.");
};