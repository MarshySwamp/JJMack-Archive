// A Photoshop Script by JJMack's

// This script is supplied as is. It is provided as freeware. 
// The author accepts no liability for any problems arising from its use.

#target photoshop
app.bringToFront();

/*
<javascriptresource>
<name>JJMack's Photo Collage and Mockup Toolkit</name>
<about>$$$/JavaScripts/HelpPhotoCollageToolkit/About=Web Help for JJMack's Photo Collage Toolkit.^r^rCopyright 2010 Mouseprints.^r^rOpen Browser Toolkit Help Page</about>
<category>JJMack's Collage Script</category>
<menu>help</menu>
</javascriptresource>
*/
try{
   var URL = new File(Folder.temp + "/PhotoCollageToolkit.html");
   URL.open("w");
   URL.writeln('<html><HEAD><meta HTTP-EQUIV="REFRESH" content="0; url=http://www.mouseprints.net/old/dpr/PhotoCollageToolkit.html"></HEAD></HTML>');
   URL.close();
   URL.execute();   // The temp file is created but this fails to open the users default browser using Photoshop CC prior Photoshop versions work
}catch(e){
alert("Error, Can Not Open.");
};