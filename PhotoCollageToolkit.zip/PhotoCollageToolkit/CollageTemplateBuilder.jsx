// ======================================
// Photoshop CS javascript: Collage Template Builder
// Build a template layout for image files in a collage
// Copyright (c) 2006 Rags Gardner.  All Rights Reserved.
// Rags Gardner www.rags-int-inc.com
//
// ======================================
// Modified John J. McAssey to generate Photo Collage Templates files
//          That are compatible with the scripts in my Photoshop
//          Photo Collage Toolkit package 
/* Help Category note tag menu can be used to place script in automate menu
<javascriptresource>
<about>$$$/JavaScripts/CollageTemplateBuilder/About=JJMack's modified Rags Gardner collage building script.^r^rCopyright 2011 Mouseprints.^r^rBuild a Photo Collage Toolkit type Template</about>
<category>JJMack's Collage Script</category>
</javascriptresource>
*/
// ======================================
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided the following conditions are met:
//
// 1. Redistribution in source code must contain the above copyright notice,
//    this list of conditions and the following disclaimer.
// 2. Redistribution in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other matereials provided with the distribution.
// 3. The name of the author may not be used to promote or endorse products
//    derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// =======================================================
//
// This will build a collage template based on user options
//
// Change History
// 05/27/06 V1.0   Initial Release
// 06/07/06 V1.1   Fix exceptions in ColorMenu with icon image
//                 Fix defect in stroke and add glow effect & drop CS1 support
// 02/28/08 V1.2   Vista: icon image locked? + showUsage()
// 08/16/11 vPCT   Photo Collage Toolkit type collage templates are built 
//                 Scipt renamed to CollageTemplateBuilder so they can co-exists

// ======================================
// Configuration Variables
// ======================================
var scriptVersion = "V1.2";                       // the script version
var scriptVersion = "vPCT";                       // the script version 
var scriptName = "CollageBuilder";                // this script name
var scriptName = "CollageTemplateBuilder";        // this script name
var newDocName = "MyCollageTemplate";             // documant name
var newDocName = "PhotoCollageToolkit";           // documant name 
var useIconPreview = true;                        // should we use an icon image for color preview?
var protoType = false;                            // ProtoType
var canvasSizeV = 16;                             // vertical inches
var canvasSizeH = 20;                             // horizontal inches
var canvasPPI = 300;                              // resolution PPI
var canvasBitDepth = 16;                          // RGB bit depth
var canvasBitDepth = 8;                           // RGB bit depth
var canvasEdgePct = 0;                            // edge padding
var canvasScale = false;                          // scale canvas or images
var mainImageV = 12;                              // vertical inches
var mainImageH = 8;                               // horizontal inches
var mainEdgePct = 0;                              // edge padding
var mainImageAlign = "hcenter";                   // main image placement
var mainIsBg = false;                             // main image is background layer
var smallImageV = 6;                              // vertical inches
var smallImageH = 4;                              // horizontal inches
var smallEdgePct = 0;                             // edge padding
var smallImageRows = 2;                           // rows
var smallImageCols = 2;                           // columns
var frameStyles = "none";                         // PS frame style
var styleScalePct = 100.0;                        // Named styles scaling percent
var dismissPreview = true;                        // close preview window
var canvasPreview = true;                         // preview or template
// ======================================
// color theme
// ======================================
var bgColor = newRGBColor(255, 255, 255);         // canvas background color (white)
var mainColor = newRGBColor(0, 255, 255);         // main image color (red)
var smallColor = newRGBColor(128, 128, 128);      // small image color (gray)
var canvasEdgeColor = newRGBColor(255, 0, 0);     // preview border stroke color (red)
var imageEdgeColor = newRGBColor(0, 0, 255);      // preview image edge color (blue)
// ======================================
// layer effects configuration defaults
// ======================================
var strokeEffect = false;
var overlayEffect = false;
var dropShadowEffect = false;
var embossEffect = false;
var glowEffect = false;
var strokeColor = newRGBColor(0, 0, 0);           // black
var strokeSize = 10.0;                            // 0 - 250 px
var strokePosition = "InsF";                      // Outside[OutF], Inside[InsF], Center[CtrF]
var overlayColor = newRGBColor(0, 0, 0);          // black
var overlayOpacity = 100.0;                       // 0 - 100 %
var dropShadowColor = newRGBColor(0, 0, 0);       // black
var dropShadowAngle = 120.0;                      // -180 - +180 �
var dropShadowSize = 10.0;                        // 0 - 250 px
var dropShadowDistance = 20.0;                    // 0 - 30000 px
var dropShadowSpread = 5.0;                       // 0 - 100 px;
var embossDepth = 200.0;                          // 0 - 1000 %
var embossSize = 15.0;                            // 0 - 250 px
var embossSoften = 5.0;                           // 0 - 16 px
var shadingAngle = -120.0;                        // -180- +180 �
var shadingAltitude = 30.0;                       // 0 - 90 �
var glowInner = false;                            // inner or outer glow
var glowColor = newRGBColor(0, 0, 0);             // black
var glowOpacity = 100.0;                          // 0 - 100 %
var glowSize = 20.0;                              // 0 - 250 px
var glowContourName = "Ring - Double";            // [Linear], [Ring], [Ring - Double]

// ======================================
// Diagnostics and testing
// ======================================
var previewAlert = false;
var dialogMenu = DialogModes.NO;                  // dialogs NO/ALL

cTID = function(s) { return app.charIDToTypeID(s); };
sTID = function(s) { return app.stringIDToTypeID(s); };


// ======================================================================================
// Basic operation:
// This script will build a template for image collages.  Specify a size for the main 
// (large) image and the secondary (small) images in inches.  Also a size for the 
// canvas and some default borders as a percentage of the canvas and small images sizes.  
//
// It will build a new canvas and place the images in unique layers.  If scale canvas 
// is checked the canvas size will be based on the image sizes and layout.  If it is not 
// checked the image sizes may be scaled if they do not fit in the user selected canvas.  
// Thus the image aspect ratios are more important than the actual sizes.  
//
// The alignment options determine where the main image will be placed relative to the 
// canvas and small images.  The edge percent specifies the minimum border around the 
// image (% of image size).  These may be adjusted as the layout is created to preserve 
// symmetry.  
//
// If preview layout is checked, a preview will be created on a single layer. If not checked,
// the template with layers for each image will be built and the script will end with the
// template left open. 
//
// Layer Styles
//  DoubleRing:    "Double Ring Glow (Button)" from PS default styles
//  CollageStyle1: User supplied PS style, sample uses bevel & emboss
//  CollageStyle2: User supplied PS style, sample uses inner glow & stroke
//  CollageStyle3: User supplied PS style, sample uses drop shadow & b/w color overlay
//  CollageStyle4: User supplied PS style, sample uses inner glow & bevel & emboss
//
// CollageStyle1-4 must be loaded to the Photoshop styles folder, [ps]/Presets/Styles/.  
// A sample is provided as CollageBuilderStyles.asl.  These must then be loaded in the 
// PS Styles menu pallet.  Or you can create your own styles with these names.  
//
// A preview layout will emulate these styles.  Each preview canvas is dismissed on the
// next operationby default.  This is provided simply to review the basic layout geometry.  
//
// The images can be opened and placed in the template later with the 
// companion script, CollageLoader.jsx.  
//
// These templates can be saved and/or modified as desired for future use.  The layer 
// naming convention must be preserved, MainImage(xx) and smImage(xx).  If additional 
// layers are created that do not conform to these conventions, they will simply be 
// ignored.  The layer styles, image size, orientation, and position can be altered as 
// desired.  Thus these templates can be saved with any customization desired.  The 
// collage images will be scaled to fit the layer size as they are loaded.  If the image has 
// transparent pixels in the border, the layer shape will change accordingly and the layer 
// edge style will warp to fit.  Similar effects can be obtained by applying a layer mask to 
// the template layer.  In this case, some image cropping may be observed.  Be creative.  
// ======================================================================================

// =======================================================
// Options Dialog Menu Routines
// =======================================================

// -------------------------------------------------------
// Options()
// Constructor: menu defaults from global configuration
// -------------------------------------------------------
function Options() {
    this.canvasSizeV;
    this.canvasSizeH;
    this.canvasPPI;
    this.canvasEdgePct;
    this.canvasScale;
    this.canvasPreview;
    this.protoType;
    this.newDocName;
    this.mainImageV;
    this.mainImageH;
    this.mainImageAlign;
    this.mainIsBg;
    this.smallImageV;
    this.smallImageH;
    this.smallImageRows;
    this.smallImageCols;
    this.smallEdgePct;
    this.mainEdgePct;
    this.frameStyles;
    this.styleScalePct;
    this.dismissPreview;
    this.buildTime;
    this.winFrameLocation = null;            // current window placement
    this.suggestedScale;                     // current layer scaling suggestion
    this.menuActive = false;                 // initialization switch
    this.checkOptions = false;               // ok or cancel ?
    this.menu = undefined;                   // the dialog menu window
    return;
}

// -------------------------------------------------------
// Options.rePop()
// repopulate global variables
// -------------------------------------------------------
Options.prototype["rePop"] = function() {
    canvasSizeV = this.canvasSizeV;
    canvasSizeH = this.canvasSizeH;
    canvasPPI = this.canvasPPI;
    canvasEdgePct = this.canvasEdgePct;
    canvasScale = this.canvasScale;
    canvasPreview = this.canvasPreview;
    protoType = this.protoType;
    mainImageV = this.mainImageV;
    mainImageH = this.mainImageH;
    mainImageAlign = this.mainImageAlign;
    mainIsBg = this.mainIsBg;
    smallImageV = this.smallImageV;
    smallImageH = this.smallImageH;
    smallImageRows = this.smallImageRows;
    smallImageCols = this.smallImageCols;
    smallEdgePct = this.smallEdgePct;
    mainEdgePct = this.mainEdgePct;
    frameStyles = this.frameStyles;
    styleScalePct = this.styleScalePct;
    dismissPreview = this.dismissPreview;
    newDocName = this.newDocName;
    return;
}

// -------------------------------------------------------
// Options.buildMenu()
// create the menu, panels, and option boxes
// -------------------------------------------------------
Options.prototype["buildMenu"] = function() {
    var listValues;
    var helpText;

    //---------------------------
    // Refresh the object options
    //---------------------------
    this.canvasSizeV = canvasSizeV;
    this.canvasSizeH = canvasSizeH;
    this.canvasPPI = canvasPPI;
    this.canvasEdgePct = canvasEdgePct;
    this.canvasScale = canvasScale;
    this.canvasPreview = canvasPreview;
    this.protoType = protoType;
    this.newDocName = newDocName;
    this.mainImageV = mainImageV;
    this.mainImageH = mainImageH;
    this.mainImageAlign = mainImageAlign;
    this.mainIsBg = mainIsBg;
    this.smallImageV = smallImageV;
    this.smallImageH = smallImageH;
    this.smallImageRows = smallImageRows;
    this.smallImageCols = smallImageCols;
    this.smallEdgePct = smallEdgePct;
    this.mainEdgePct = mainEdgePct;
    this.frameStyles = frameStyles;
    this.styleScalePct = styleScalePct;
    this.dismissPreview = dismissPreview;
    this.buildTime = buildTime;
    //-----------------------------------------------
    // create the template options dialog menu window
    //-----------------------------------------------
    this.menuActive = false;
    this.menu = new Window("dialog", "  Collage Template Builder " + scriptVersion, undefined);
    if (this.winFrameLocation == null)
        this.menu.frameLocation = [100, 100];
    else
        this.menu.frameLocation = this.winFrameLocation;
    //------------
    // base groups
    //------------
    this.menu.menuRow1 = this.menu.add("group");
    this.menu.menuRow1.orientation = "row";
    this.menu.menuRow1.alignChildren = "fill";
    this.menu.menuRow1.spacing = 15;
    this.menu.menuRow2 = this.menu.add("group");
    this.menu.menuRow2.orientation = "row";
    this.menu.menuRow2.alignChildren = "fill";
    this.menu.menuRow2.spacing = 15;
    this.menu.menuRow3 = this.menu.add("group");
    this.menu.menuRow3.orientation = "row";
    this.menu.menuRow3.alignChildren = "fill";
    this.menu.menuRow3.spacing = 15;
    //--------------------
    // ok & cancel buttons
    //--------------------
    this.menu.okBtn = this.menu.menuRow1.add("button", undefined, "OK", {name:"ok"});
    this.menu.okBtn.helpTip = "Validate and accept changes\nBuild template or preview";
    this.menu.okBtn.onClick = function()   // tell onClose event to Check Options
                  {dlg.checkOptions = true; this.parent.parent.close(1);};
    this.menu.showBtn = this.menu.menuRow1.add("button", undefined, "Show Usage", {name:"showUsage"});
    this.menu.showBtn.onClick = function() {dlg.tryUpdateMenu("showUsage");};
    this.menu.showBtn.helpTip = "Show summary usage instructions";
    this.menu.canBtn = this.menu.menuRow1.add("button", undefined, "Cancel", {name:"cancel"});
    this.menu.canBtn.helpTip = "Finished: Cancel execution";
    //--------------------------
    // dismiss preview check box
    //--------------------------
    if (this.canvasPreview)
          this.menu.dismissCb = this.menu.menuRow2.add("checkbox", undefined, "Dismiss Preview");
    else
          this.menu.dismissCb = this.menu.menuRow2.add("checkbox", undefined, "Dismiss Template");
    this.menu.dismissCb.preferredSize = [120,20];
    this.menu.dismissCb.onClick = function() {dlg.tryUpdateMenu("DismissImage");};
    this.menu.dismissCb.helpTip = "Dismiss the current document before the next iteration or if cancelled";
    if (this.dismissPreview)
       this.menu.dismissCb.value = true;
    else
       this.menu.dismissCb.value = false;
    //-------------------------
    // preview canvas check box
    //-------------------------
    this.menu.previewCanvasCb = this.menu.menuRow2.add("checkbox", undefined, "Preview Layout");
    this.menu.previewCanvasCb.preferredSize = [120,20];
    this.menu.previewCanvasCb.helpTip = "Preview canvas layout\nElse build layered template";
    this.menu.previewCanvasCb.onClick = function() {dlg.tryUpdateMenu("PreviewOpts");};
    if (this.canvasPreview)
       this.menu.previewCanvasCb.value = true;
    else
       this.menu.previewCanvasCb.value = false;
    //-------------------------
    // protoType check box
    //-------------------------
    this.menu.protoTypeCb = this.menu.menuRow2.add("checkbox", undefined, "ProtoType Layers");
    this.menu.protoTypeCb.preferredSize = [120,20];
    this.menu.protoTypeCb.helpTip = "Build Prototyoe Layers\nElse build Alpha Channels template";
    this.menu.protoTypeCb.onClick = function() {dlg.tryUpdateMenu("ProtoType");};
    if (this.protoType)
       this.menu.protoTypeCb.value = true;
    else
       this.menu.protoTypeCb.value = false;
    //------------------------

    this.menu.buildTimeTxt = this.menu.menuRow3.add("statictext", undefined, this.buildTime);


    // canvas panel and groups
    //------------------------
    this.menu.canvasPanel = this.menu.add("panel", undefined, "Canvas Size");
    this.menu.canvasPanel.alignChildren = "left";
    this.menu.canvasRow1 = this.menu.canvasPanel.add("group");
    this.menu.canvasRow1.orientation = "row";
    this.menu.canvasRow1.alignChildren = "fill";
    this.menu.canvasRow1.spacing = 15;
    this.menu.canvasRow2 = this.menu.canvasPanel.add("group");
    this.menu.canvasRow2.orientation = "row";
    this.menu.canvasRow2.alignChildren = "fill";
    this.menu.canvasRow2.spacing = 15;
    this.menu.canvasRow3 = this.menu.canvasPanel.add("group");
    this.menu.canvasRow3.orientation = "row";
    this.menu.canvasRow3.alignChildren = "fill";
    this.menu.canvasRow3.spacing = 15;
    //----------------------
    // canvas panel controls
    //----------------------

    this.menu.canvasWidthTxt = this.menu.canvasRow1.add("statictext", undefined, "Width");
    this.menu.canvasWidthTxt.preferredSize = [35,20];
    this.menu.canvasWidthValue = this.menu.canvasRow1.add("edittext", undefined, this.canvasSizeH);
    this.menu.canvasWidthValue.preferredSize = [40,20];
    this.menu.canvasWidthValue.onChange = function() {dlg.tryUpdateMenu("CanvasSize");};
    this.menu.canvasWidthValue.helpTip = "Canvas horizontal size in inches";
    this.menu.canvasHeightTxt = this.menu.canvasRow1.add("statictext", undefined, "Height");
    this.menu.canvasHeightTxt.preferredSize = [35,20];
    this.menu.canvasHeightValue = this.menu.canvasRow1.add("edittext", undefined, this.canvasSizeV);
    this.menu.canvasHeightValue.preferredSize = [40,20];
    this.menu.canvasHeightValue.onChange = function() {dlg.tryUpdateMenu("CanvasSize");};
    this.menu.canvasHeightValue.helpTip = "Canvas vertical size in inches";
    this.menu.canvasEdgeTxt = this.menu.canvasRow1.add("statictext", undefined, "Edge%");
    this.menu.canvasEdgeTxt.preferredSize = [35,20];
    this.menu.canvasEdgeValue = this.menu.canvasRow1.add("edittext", undefined, this.canvasEdgePct);
    this.menu.canvasEdgeValue.preferredSize = [40,20];
    this.menu.canvasEdgeValue.onChange = function() {dlg.tryUpdateMenu("BorderPct");};
    this.menu.canvasEdgeValue.helpTip = "Canvas outer border percentage";
    this.menu.canvasScaleCb = this.menu.canvasRow2.add("checkbox", undefined, "Scale Canvas");
    this.menu.canvasScaleCb.preferredSize = [90,20];
    this.menu.canvasScaleCb.helpTip = "Scale canvas size to fit images" +
                                     "\nElse images are scaled to fit the canvas";
    this.menu.canvasScaleCb.onClick = function() {dlg.tryUpdateMenu("CanvasOpts");};
    if (this.canvasScale)
       this.menu.canvasScaleCb.value = true;
    else
       this.menu.canvasScaleCb.value = false;
    this.menu.colorThemeBtn = this.menu.canvasRow2.add("button", undefined, "Color Theme");
    this.menu.colorThemeBtn.onClick = function() {dlg.tryUpdateMenu("ColorTheme");};
    this.menu.colorThemeBtn.helpTip = "Set basic template color scheme";
    this.menu.canvasPpiTxt = this.menu.canvasRow3.add("statictext", undefined, "PPI");
    this.menu.canvasPpiTxt.preferredSize = [35,20];
    this.menu.canvasPpiValue = this.menu.canvasRow3.add("edittext", undefined, this.canvasPPI);
    this.menu.canvasPpiValue.preferredSize = [40,20];
    this.menu.canvasPpiValue.onChange = function() {dlg.tryUpdateMenu("DocPPI");};
    this.menu.canvasPpiValue.helpTip = "Canvas pixels per inch";
    this.menu.canvasDocNameTxt = this.menu.canvasRow3.add("statictext", undefined, "Doc Name");
    this.menu.canvasDocNameTxt.preferredSize = [60,20];
    this.menu.canvasDocNameValue = this.menu.canvasRow3.add("edittext", undefined, this.newDocName);
    this.menu.canvasDocNameValue.preferredSize = [120,20];
    this.menu.canvasDocNameValue.onChange = function() {dlg.tryUpdateMenu("DocName");};
    this.menu.canvasDocNameValue.helpTip = "Default name for new template document";
    //---------------------------
    // mainImage panel and groups
    //---------------------------
    this.menu.mainPanel = this.menu.add("panel", undefined, "Main Image");
    this.menu.mainPanel.alignChildren = "left";
    this.menu.mainRow1 = this.menu.mainPanel.add("group");
    this.menu.mainRow1.orientation = "row";
    this.menu.mainRow1.alignChildren = "fill";
    this.menu.mainRow1.spacing = 15;
    this.menu.mainRow2 = this.menu.mainPanel.add("group");
    this.menu.mainRow2.orientation = "row";
    this.menu.mainRow2.alignChildren = "fill";
    this.menu.mainRow2.spacing = 5;
    this.menu.mainRow3 = this.menu.mainPanel.add("group");
    this.menu.mainRow3.orientation = "row";
    this.menu.mainRow3.alignChildren = "fill";
    this.menu.mainRow3.spacing = 5;
    this.menu.mainRow4 = this.menu.mainPanel.add("group");
    this.menu.mainRow4.orientation = "row";
    this.menu.mainRow4.alignChildren = "fill";
    this.menu.mainRow4.spacing = 5;
    //-------------------------
    // mainImage panel controls
    //-------------------------

    this.menu.mainWidthTxt = this.menu.mainRow1.add("statictext", undefined, "Width");
    this.menu.mainWidthTxt.preferredSize = [35,20];
    this.menu.mainWidthValue = this.menu.mainRow1.add("edittext", undefined, this.mainImageH);
    this.menu.mainWidthValue.preferredSize = [40,20];
    this.menu.mainWidthValue.onChange = function() {dlg.tryUpdateMenu("MainSize");};
    this.menu.mainWidthValue.helpTip = "Main image horizontal size in inches";
    this.menu.mainHeightTxt = this.menu.mainRow1.add("statictext", undefined, "Height");
    this.menu.mainHeightTxt.preferredSize = [35,20];
    this.menu.mainHeightValue = this.menu.mainRow1.add("edittext", undefined, this.mainImageV);
    this.menu.mainHeightValue.preferredSize = [40,20];
    this.menu.mainHeightValue.onChange = function() {dlg.tryUpdateMenu("MainSize");};
    this.menu.mainHeightValue.helpTip = "Main image vertical size in inches";
    this.menu.mainEdgeTxt = this.menu.mainRow1.add("statictext", undefined, "Edge%");
    this.menu.mainEdgeTxt.preferredSize = [35,20];
    this.menu.mainEdgeValue = this.menu.mainRow1.add("edittext", undefined, this.mainEdgePct);
    this.menu.mainEdgeValue.preferredSize = [40,20];
    this.menu.mainEdgeValue.onChange = function() {dlg.tryUpdateMenu("EdgePct");};
    this.menu.mainEdgeValue.helpTip = "Main image minimum border percentage";
    this.menu.mainLeftRb = this.menu.mainRow2.add("radiobutton", undefined, "Left");
    this.menu.mainLeftRb.preferredSize = [70,20];
    this.menu.mainLeftRb.onClick = function() {dlg.tryUpdateMenu("MainImageOne");};
    this.menu.mainLeftRb.helpTip = "Main image on left";
    this.menu.mainRightRb = this.menu.mainRow2.add("radiobutton", undefined, "Right");
    this.menu.mainRightRb.preferredSize = [70,20];
    this.menu.mainRightRb.onClick = function() {dlg.tryUpdateMenu("MainImageOne");};
    this.menu.mainRightRb.helpTip = "Main image on right";
    this.menu.mainCenterhRb = this.menu.mainRow2.add("radiobutton", undefined, "H-Center");
    this.menu.mainCenterhRb.preferredSize = [70,20];
    this.menu.mainCenterhRb.onClick = function() {dlg.tryUpdateMenu("MainImageOne");};
    this.menu.mainCenterhRb.helpTip = "Main image centered left and right";
    this.menu.mainNoneRb = this.menu.mainRow2.add("radiobutton", undefined, "none");
    this.menu.mainNoneRb.preferredSize = [70,20];
    this.menu.mainNoneRb.onClick = function() {dlg.tryUpdateMenu("MainImageOne");};
    this.menu.mainNoneRb.helpTip = "Main image omitted";
    this.menu.mainTopRb = this.menu.mainRow3.add("radiobutton", undefined, "Top");
    this.menu.mainTopRb.preferredSize = [70,20];
    this.menu.mainTopRb.onClick = function() {dlg.tryUpdateMenu("MainImageTwo");};
    this.menu.mainTopRb.helpTip = "Main image at top";
    this.menu.mainBottomRb = this.menu.mainRow3.add("radiobutton", undefined, "Bottom");
    this.menu.mainBottomRb.preferredSize = [70,20];
    this.menu.mainBottomRb.onClick = function() {dlg.tryUpdateMenu("MainImageTwo");};
    this.menu.mainBottomRb.helpTip = "Main image at bottom";
    this.menu.mainCentervRb = this.menu.mainRow3.add("radiobutton", undefined, "V-Center");
    this.menu.mainCentervRb.preferredSize = [70,20];
    this.menu.mainCentervRb.onClick = function() {dlg.tryUpdateMenu("MainImageTwo");};
    this.menu.mainCentervRb.helpTip = "Main image centered top and bottom";
    this.menu.mainMiddleRb = this.menu.mainRow3.add("radiobutton", undefined, "Middle");
    this.menu.mainMiddleRb.preferredSize = [70,20];
    this.menu.mainMiddleRb.onClick = function() {dlg.tryUpdateMenu("MainImageTwo");};
    this.menu.mainMiddleRb.helpTip = "Main image at canvas middle\n" +
                                    "Rows and columnss must be even multiples\n" +
                                    "Some filler images may be created";
    switch(this.mainImageAlign) {
        case "left":
            this.menu.mainLeftRb.value = true; break;
        case "right":
            this.menu.mainRightRb.value = true; break;
        case "hcenter":
            this.menu.mainCenterhRb.value = true; break;
        case "none":
            this.menu.mainNoneRb.value = true; break;
        case "top":
            this.menu.mainTopRb.value = true; break;
        case "bottom":
            this.menu.mainBottomRb.value = true; break;
        case "vcenter":
            this.menu.mainCentervRb.value = true; break;
        case "middle":
            this.menu.mainMiddleRb.value = true; break;
        default: break;
    }
    this.menu.mainIsBgCb = this.menu.mainRow4.add("checkbox", undefined, "Use background for main image");
    this.menu.mainIsBgCb.helpTip = "Main image is the canvas background\n" +
                                  "Main image size and location will still determine small image placement";
    this.menu.mainIsBgCb.onClick = function() {dlg.tryUpdateMenu("MainisBG");};
    if (this.mainIsBg)
       this.menu.mainIsBgCb.value = true;
    else
       this.menu.mainIsBgCb.value = false;
    //---------------------------
    // smallImage panel and groups
    //---------------------------
    this.menu.smallPanel = this.menu.add("panel", undefined, "Secondary (small) Images");
    this.menu.smallPanel.alignChildren = "left";
    this.menu.smallRow1 = this.menu.smallPanel.add("group");
    this.menu.smallRow1.orientation = "row";
    this.menu.smallRow1.alignChildren = "fill";
    this.menu.smallRow1.spacing = 15;
    this.menu.smallRow2 = this.menu.smallPanel.add("group");
    this.menu.smallRow2.orientation = "row";
    this.menu.smallRow2.alignChildren = "fill";
    this.menu.smallRow2.spacing = 15;
    //--------------------------
    // smallImage panel controls
    //--------------------------

    this.menu.smallWidthTxt = this.menu.smallRow1.add("statictext", undefined, "Width");
    this.menu.smallWidthTxt.preferredSize = [35,20];
    this.menu.smallWidthValue = this.menu.smallRow1.add("edittext", undefined, this.smallImageH);
    this.menu.smallWidthValue.preferredSize = [40,20];
    this.menu.smallWidthValue.onChange = function() {dlg.tryUpdateMenu("SmallSize");};
    this.menu.smallWidthValue.helpTip = "Small image horizontal size in inches";
    this.menu.smallHeightTxt = this.menu.smallRow1.add("statictext", undefined, "Height");
    this.menu.smallHeightTxt.preferredSize = [35,20];
    this.menu.smallHeightValue = this.menu.smallRow1.add("edittext", undefined, this.smallImageV);
    this.menu.smallHeightValue.preferredSize = [40,20];
    this.menu.smallHeightValue.onChange = function() {dlg.tryUpdateMenu("SmallSize");};
    this.menu.smallHeightValue.helpTip = "Small image vertical size in inches";
    this.menu.smallEdgeTxt = this.menu.smallRow1.add("statictext", undefined, "Edge%");
    this.menu.smallEdgeTxt.preferredSize = [35,20];
    this.menu.smallEdgeValue = this.menu.smallRow1.add("edittext", undefined, this.smallEdgePct);
    this.menu.smallEdgeValue.preferredSize = [40,20];
    this.menu.smallEdgeValue.onChange = function() {dlg.tryUpdateMenu("EdgePct");};
    this.menu.smallEdgeValue.helpTip = "Small image minimum border percentage";
    this.menu.smallRowsTxt = this.menu.smallRow2.add("statictext", undefined, "Rows");
    this.menu.smallRowsTxt.preferredSize = [35,20];
    this.menu.smallRowsValue = this.menu.smallRow2.add("edittext", undefined, this.smallImageRows);
    this.menu.smallRowsValue.preferredSize = [40,20];
    this.menu.smallRowsValue.onChange = function() {dlg.tryUpdateMenu("RowsCols");};
    this.menu.smallRowsValue.helpTip = "Small image: number of rows";
    this.menu.smallColumnsTxt = this.menu.smallRow2.add("statictext", undefined, "Cols");
    this.menu.smallColumnsTxt.preferredSize = [35,20];
    this.menu.smallColumnsValue = this.menu.smallRow2.add("edittext", undefined, this.smallImageCols);
    this.menu.smallColumnsValue.preferredSize = [40,20];
    this.menu.smallColumnsValue.onChange = function() {dlg.tryUpdateMenu("RowsCols");};
    this.menu.smallColumnsValue.helpTip = "Small image: number of columns";

    //----------------------------
    // frameStyle panel and groups
    //----------------------------
    this.menu.framesPanel = this.menu.add("panel", undefined, "Image Frames");
    this.menu.framesPanel.alignChildren = "left";
    this.menu.frameRow1 = this.menu.framesPanel.add("group");
    this.menu.frameRow1.orientation = "row";
    this.menu.frameRow1.alignChildren = "fill";
    this.menu.frameRow1.spacing = 15;
    this.menu.frameRow2 = this.menu.framesPanel.add("group");
    this.menu.frameRow2.orientation = "row";
    this.menu.frameRow2.alignChildren = "fill";
    this.menu.frameRow2.spacing = 15;
    //--------------------------
    // frameStyle panel controls
    //--------------------------
/* JJmack
    listValues = new Array("none", "DoubleRing", "CollageStyle1",
                           "CollageStyle", "CollageStyle3", "CollageStyle4");
   JJMack */
      listValues = new Array("none");
    this.menu.frameStyleTxtBx = this.menu.frameRow1.add("statictext", undefined, "Layer Style");
    this.menu.frameStyleTxtBx.preferredSize = [70,20];
    this.menu.frameStyleLstBx = this.menu.frameRow1.add("dropdownlist", undefined, listValues);
/* JJmack
    helpText  = "Select a named Photoshop layer style";
    helpText += "\nDouble Ring Glow (Button): [PS Style Defaults]";
    helpText += "\nCollageStyle1-4: Rags supplied user Styles, 1-4";
    helpText += "\n  Style1: bevel and emboss";
    helpText += "\n  Style2: inner glow and stroke";
    helpText += "\n  Style3: drop shadow and b/w color overlay";
    helpText += "\n  Style4: inner glow and bevel and emboss";
   JJMack */
    helpText  = "Use a Photo Collage ToolKit Script for this";
    this.menu.frameStyleLstBx.helpTip = helpText;
    this.menu.frameStyleLstBx.onChange = function() {dlg.tryUpdateMenu("FrameStyles");};
    switch(this.frameStyles) {
        case "DoubleRing":
            this.menu.frameStyleLstBx.items[1].selected = true; break;
        case "CollageStyle1":
            this.menu.frameStyleLstBx.items[2].selected = true; break;
        case "CollageStyle2":
            this.menu.frameStyleLstBx.items[3].selected = true; break;
        case "CollageStyle3":
            this.menu.frameStyleLstBx.items[4].selected = true; break;
        case "CollageStyle4":
            this.menu.frameStyleLstBx.items[5].selected = true; break;
        case "none":
        default:
            this.menu.frameStyleLstBx.items[0].selected = true; break;
    }
    this.menu.frameStyleBtn = this.menu.frameRow1.add("button", undefined, "Layer Effects");
    this.menu.frameStyleBtn.onClick = function() {dlg.tryUpdateMenu("FrameEffects");};
    this.menu.frameStyleBtn.helpTip = "Set custom layer effects";
    if (this.frameStyles != "none")
        this.menu.frameStyleBtn.enabled = false;
    else
        this.menu.frameStyleBtn.enabled = true;
    this.menu.styleScaleTxt = this.menu.frameRow2.add("statictext", undefined, "Style Scale%");
    this.menu.styleScaleTxt.preferredSize = [70,20];
    this.menu.styleScaleValue = this.menu.frameRow2.add("edittext", undefined, this.styleScalePct);
    this.menu.styleScaleValue.preferredSize = [40,20];
    this.menu.styleScaleValue.onChange = function() {dlg.tryUpdateMenu("StyleScale");};
    this.menu.styleScaleValue.helpTip = "Named layer style effects scaling percentage";
    this.suggestedScale = Math.min(this.smallImageV, this.smallImageH) * this.canvasPPI;
    this.suggestedScale = Math.round(this.suggestedScale / (5 * 300) * 10000)/100;
    this.menu.suggestedScaleTxt = this.menu.frameRow2.add("statictext", undefined,
                                 "Suggeested Scale=" + this.suggestedScale + "%");
    this.menu.suggestedScaleTxt.preferredSize = [150,20];
    if (this.frameStyles != "none")
        this.menu.styleScaleValue.enabled = true;
    else
        this.menu.styleScaleValue.enabled = false;
    this.menu.onMove = function() {dlg.tryUpdateMenu("Move");};
    this.menu.onShow = function() {dlg.tryUpdateMenu("Show");};

    return;
}

// -------------------------------------------------------
// Options.tryUpdateMenu()
// -------------------------------------------------------
Options.prototype["tryUpdateMenu"] = function(caller) {
    var ex;

    try {
        if (this.menuActive || caller == "Move" || caller == "Show")
            this.updateMenu(caller);
    } catch(ex) {
        alert(scriptName + " Options.updateMenu(" + caller +
                           ") exception caught? line[" + ex.line + "]\n"  + ex);
        if (this.menuActive)
            this.menu.close(0); // there is no point in re-throwing the exception
    }
    return;
}

// -------------------------------------------------------
// Options.updateMenu()
// -------------------------------------------------------
Options.prototype["updateMenu"] = function(caller) {
    var selectItem, testNum;

    switch(caller) {
        case "Move":
            this.winFrameLocation = this.menu.frameLocation;
            if (this.menuActive)
                waitForRedraw();
            break;
        case "showUsage":
            showUsage("");
            break;
        case "CanvasSize":
            testNum = Number(this.menu.canvasHeightValue.text);
            if (isNaN(testNum) || testNum < 5) {
                alert(scriptName + " Canvas size=" + testNum + " must be a number > 5 inches");
                this.menu.canvasHeightValue.text = this.canvasSizeV;
            } else
                this.canvasSizeV = testNum;
            testNum = Number(this.menu.canvasWidthValue.text);
            if (isNaN(testNum) || testNum < 5) {
                alert(scriptName + " Canvas size=" + testNum + " must be a number > 5 inches");
                this.menu.canvasWidthValue.text = this.canvasSizeH;
            } else
                this.canvasSizeH = testNum;
            break;
        case "DocPPI":
            testNum = Number(this.menu.canvasPpiValue.text);
            if (isNaN(testNum) || testNum < 72 || testNum > 360) {
                alert(scriptName + " Canvas PPI=" + testNum + ", must be a number 72-360 PPI");
                this.menu.canvasPpiValue.text = this.canvasPPI;
            } else
                this.canvasPPI = testNum;
            break;
        case "BorderPct":
            testNum = Number(this.menu.canvasEdgeValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 50) {
                alert(scriptName + " Canvas border percent=" + testNum + ", must be a number 0 to 50");
                this.menu.canvasEdgeValue.text = this.canvasEdgePct;
            } else
                this.canvasEdgePct = testNum;
            break;
        case "DocName":
            if (this.menu.canvasDocNameValue.text == "") {
                alert(scriptName + " A new document name must be specified");
                this.menu.canvasDocNameValue.text = dlg.newDocName;
            } else
                this.newDocName = this.menu.canvasDocNameValue.text;
            break;
        case "CanvasOpts":
            if (this.menu.canvasScaleCb.value == true)
                this.canvasScale = true;
            else
                this.canvasScale = false;
            break;
        case "MainSize":
            testNum = Number(this.menu.mainHeightValue.text);
            if (isNaN(testNum) || testNum < 0) {
                alert(scriptName + " Main image height=" + testNum + " must be a number, 0 inches or larger");
                this.menu.mainHeightValue.text = this.mainImageV;
            } else
                this.mainImageV = testNum;
            testNum = Number(this.menu.mainWidthValue.text);
            if (isNaN(testNum) || testNum < 0) {
                alert(scriptName + " Main image width=" + testNum + " must be a number, 0 inches or larger");
                this.menu.mainWidthValue.text = this.mainImageH;
            } else
                this.mainImageH = testNum;
            break;
        case "MainImageOne":  // turn off group two buttons
            this.menu.mainTopRb.value = false;
            this.menu.mainBottomRb.value = false;
            this.menu.mainCentervRb.value = false;
            this.menu.mainMiddleRb.value = false;
            break;
        case "MainImageTwo":  // turn off group one buttons
            this.menu.mainLeftRb.value = false;
            this.menu.mainRightRb.value = false;
            this.menu.mainCenterhRb.value = false;
            this.menu.mainNoneRb.value = false;
            break;
        case "ProtoType":      // ProtoType
            if (this.menu.protoTypeCb.value)
                this.protoType = true;
            else
                this.protoType = false;

            break;
        case "MainisBG":      // main image is background
            if (this.menu.mainIsBgCb.value)
                this.mainIsBg = true;
            else
                this.mainIsBg = false;
            break;
        case "SmallSize":
            testNum = Number(this.menu.smallHeightValue.text);
            if (isNaN(testNum) || testNum < 1) {
                alert(scriptName + " Small image height=" + testNum + " must be a number, 1 inch or larger");
                this.menu.smallHeightValue.text = this.smallImageV;
            } else
                this.smallImageV = testNum;
            testNum = Number(this.menu.smallWidthValue.text);
            if (isNaN(testNum) || testNum < 1) {
                alert(scriptName + " Small image width=" + testNum + " must be a number, 1 inch or larger");
                this.menu.smallWidthValue.text = this.smallImageH;
            } else
                this.smallImageH = testNum;
            break;
        case "EdgePct":
            testNum = Number(this.menu.smallEdgeValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 50) {
                alert(scriptName + " Small Image border percent=" + testNum + ", must be a number 0 to 50");
                this.menu.smallEdgeValue.text = this.smallEdgePct;
            } else
                this.smallEdgePct = testNum;
            testNum = Number(this.menu.mainEdgeValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 50) {
                alert(scriptName + " Main Image border percent=" + testNum + ", must be a number 0 to 50");
                this.menu.mainEdgeValue.text = this.mainEdgePct;
            } else
                this.mainEdgePct = testNum;
            break;
        case "RowsCols":
            testNum = Number(this.menu.smallRowsValue.text);
            if (isNaN(testNum) || testNum < 1 || testNum % 1) {
                alert(scriptName + " Small image rows=" + testNum + " must be an integer > 0");
                this.menu.smallRowsValue.text = this.smallImageRows;
            } else
                this.smallImageRows = testNum;
            testNum = Number(this.menu.smallColumnsValue.text);
            if (isNaN(testNum) || testNum < 1 || testNum % 1) {
                alert(scriptName + " Small image columns=" + testNum + " must be an integer > 0");
                this.menu.smallColumnsValue.text = this.smallImageCols;
            } else
                this.smallImageCols = testNum;
            break;
        case "PreviewOpts":
            if (this.menu.previewCanvasCb.value == true)
                this.canvasPreview = true;
            else {
                this.canvasPreview = false;
                this.dismissPreview = false;
                this.menu.dismissCb.value = false;
            }
            if (this.canvasPreview)
                this.menu.dismissCb.text = "Dismiss Preview";
            else
                this.menu.dismissCb.text = "Dismiss Template";
            break;
        case "DismissImage":
            if (this.menu.dismissCb.value)
                this.dismissPreview = true;
            else
                this.dismissPreview = false;
            break;
        case "FrameStyles":
            selectItem = Math.round(this.menu.frameStyleLstBx.selection);
            switch (selectItem) {
                case 0: this.frameStyles = "none"; break;
                case 1: this.frameStyles = "DoubleRing"; break;
                case 2: this.frameStyles = "CollageStyle1"; break;
                case 3: this.frameStyles = "CollageStyle2"; break;
                case 4: this.frameStyles = "CollageStyle3"; break;
                case 5: this.frameStyles = "CollageStyle4"; break;
                default:
                    alert(scriptName + " Invalid Frame Style [" + selectItem + "]");
                    this.frameStyles = "none";
                    break;
            }
            if (this.frameStyles != "none") {
                this.menu.frameStyleBtn.enabled = false;
                this.menu.styleScaleValue.enabled = true;
            } else {
                this.menu.frameStyleBtn.enabled = true;
                this.menu.styleScaleValue.enabled = false;
            }
            break;
        case "StyleScale":
            testNum = Number(this.menu.styleScaleValue.text);
            if (isNaN(testNum) || testNum < 1 || testNum > 1000) {
                alert(scriptName + " Scale Layer Styles%=" + testNum + " must be a number: 1 to 1,000");
                this.menu.styleScaleValue.text = this.styleScalePct;
            } else
                this.styleScalePct = testNum;
            break;
        case "FrameEffects":
            layerMenu.showDialog(this.winFrameLocation);
            break;
        case "ColorTheme":
            colorScheme.showMenu([this.winFrameLocation[0] + 80, this.winFrameLocation[1] + 180]);
            break;
        case "Show":
            this.menuActive = true;
            break;
        default:
            alert("Options.updateMenu() Invalid caller=" + caller);
            break;
    }
    if (caller == "MainImageOne" || caller == "MainImageTwo") {
        if (this.menu.mainLeftRb.value)
            this.mainImageAlign = "left";
        else if (this.menu.mainRightRb.value)
            this.mainImageAlign = "right";
        else if (this.menu.mainCenterhRb.value)
            this.mainImageAlign = "hcenter";
        else if (this.menu.mainNoneRb.value)
            this.mainImageAlign = "none";
        else if (this.menu.mainTopRb.value)
            this.mainImageAlign = "top";
        else if (this.menu.mainBottomRb.value)
            this.mainImageAlign = "bottom";
        else if (this.menu.mainCentervRb.value)
            this.mainImageAlign = "vcenter";
        else if (this.menu.mainMiddleRb.value)
            this.mainImageAlign = "middle";
    }
    this.suggestedScale = Math.min(this.smallImageV, this.smallImageH) * this.canvasPPI;
    this.suggestedScale = Math.round(this.suggestedScale / (5 * 300) * 10000)/100;
    this.menu.suggestedScaleTxt.text = "Suggeested Scale=" + this.suggestedScale + "%";
    return;
}

// -------------------------------------------------------
// Options.showMenu()
// -------------------------------------------------------
Options.prototype["showMenu"] = function() {
    var retCd;
    var testNum;

    // --------------------
    // build the dialog menu
    // --------------------
    this.buildMenu();
    // ----------------------------------------------------------------
    // menu.onClose() inline event handler: validate the current options
    // ----------------------------------------------------------------
    this.menu.onClose = function() {
        var rc = true;
        var itemSelected = 0;

        dismissPreview = dlg.dismissPreview;  // always update this one
        if (dlg.checkOptions) {               // OK button
            dlg.checkOptions = false;         // reset it
            //-----------------------------
            // check for illogic conditions
            //-----------------------------
            if (dlg.mainImageAlign != "none" && (dlg.mainImageV == 0 || dlg.mainImageH == 0)) {
                alert(scriptName + " Main image size cannot be zero unless none is checked!");
                rc = false;
            }
            if (rc && (dlg.mainImageV < dlg.smallImageV || dlg.mainImageH < dlg.smallImageH)
                 && dlg.mainImageAlign != "none") {
                if (!confirm(scriptName + " Main image is smaller than secondary image size, " +
                                          "Possible unexpected results\n\nContinue?"))
                    rc = false;
            }
            if (dlg.mainImageAlign == "hcenter" && (dlg.smallImageCols < 2 || dlg.smallImageCols%2 != 0)) {
                alert(scriptName + " Main image alignment = hcenter, " +
                                   "columns must be an even multiple of 2 or more");
                rc = false;
            }
            if (dlg.mainImageAlign == "vcenter" && (dlg.smallImageRows < 2 || dlg.smallImageRows%2 != 0)) {
                alert(scriptName + " Main image alignment = vcenter, " +
                                   "rows must be an even multiple of 2 or more");
                rc = false;
            }
            if ((dlg.mainImageAlign == "middle") && ((dlg.smallImageRows < 2 || dlg.smallImageCols < 2) ||
                (dlg.smallImageCols%2 != 0 || dlg.smallImageRows%2 != 0))) {
                alert(scriptName + " Main image alignment = middle, Rows and Columns " +
                                   "must each be an even multiple of 2 or more");
                rc = false;
            }
            if (rc && dlg.smallImageRows * dlg.smallImageCols > 253) {
                if (!confirm(scriptName + " Excessive small image layers(" +
                                          (dlg.smallImageRows * dlg.smallImageCols) +
                                          ") may impact performance\n\nContinue?"))
                    rc = false;
            }
        } // CANCEL button
        return(rc);
    } // end function: this.menu.onClose()
    // --------------------
    // show the dialog menu
    // --------------------
    retCd = this.menu.show();
    if (retCd == 1)                        // OK
        this.rePop();                      // update selected global options
    return(retCd);
}

// =======================================================
// ColorScheme Dialog Menu Routines
// =======================================================

// -------------------------------------------------------
// ColorScheme()
// Constructor:
// -------------------------------------------------------
function ColorScheme(useIcon) {
    this.bgColor;
    this.mainColor;
    this.smallColor;
    this.canvasEdgeColor;
    this.imageEdgeColor;
    this.isIconValid = useIcon;              // shuld we use the PNG icon
    this.winFrameLocation = null;            // current window placement
    this.menuActive = false;                 // initialization switch
    this.checkOptions = false;               // ok or cancel ?
    this.menu = undefined;                    // the dialog menu window
    return;
}

// -------------------------------------------------------
// ColorScheme.rePop()
// repopulate global variables
// -------------------------------------------------------
ColorScheme.prototype["rePop"] = function() {
    bgColor = this.bgColor;
    mainColor = this.mainColor;
    smallColor = this.smallColor;
    canvasEdgeColor = this.canvasEdgeColor;
    imageEdgeColor = this.imageEdgeColor;
    return;
}

// -------------------------------------------------------
// ColorScheme.buildMenu()
// create the menu, panels, and option boxes
// -------------------------------------------------------
ColorScheme.prototype["buildMenu"] = function(placement) {
    var listValues;
    var helpText;

    //---------------------------
    // Refresh the object options
    //---------------------------
    this.bgColor = bgColor;
    this.mainColor = mainColor;
    this.smallColor = smallColor;
    this.canvasEdgeColor = canvasEdgeColor;
    this.imageEdgeColor = imageEdgeColor;
    //------------------------------
    // Create the dialog menu window
    //------------------------------
    this.menuActive = false;
    this.menu = new Window("dialog", "  Select Template Colors", undefined);
    if (this.winFrameLocation == null)
        this.menu.frameLocation = placement;
    else
        this.menu.frameLocation = this.winFrameLocation;
    //--------------------
    // base groups
    //--------------------
    this.menu.menuRow1 = this.menu.add("group");
    this.menu.menuRow1.orientation = "row";
    this.menu.menuRow1.alignChildren = "fill";
    this.menu.menuRow1.spacing = 15;
    this.menu.menuRow2 = this.menu.add("group");
    this.menu.menuRow2.orientation = "row";
    this.menu.menuRow2.alignChildren = "fill";
    this.menu.menuRow2.spacing = 15;
    //--------------------
    // ok & cancel buttons
    //--------------------
    this.menu.okBtn = this.menu.menuRow1.add("button", undefined, "OK", {name:"ok"});
    this.menu.okBtn.helpTip = "Accept changes";
    this.menu.okBtn.onClick = function()   // tell onClose event to Check Options
                  {colorScheme.checkOptions = true; this.parent.parent.close(1);};
    this.menu.canBtn = this.menu.menuRow1.add("button", undefined, "Cancel", {name:"cancel"});
    this.menu.canBtn.helpTip = "Cancel changes";
    //-----------------------
    // color panel and groups
    //-----------------------
    this.menu.colorPanel = this.menu.add("panel", undefined, "Color Options");
    this.menu.colorPanel.orientation = "column";
    this.menu.colorPanel.alignChildren = "fill";
    this.menu.colorPanel.spacing = 15;
    this.menu.colorRow1 = this.menu.colorPanel.add("group");
    this.menu.colorRow1.orientation = "row";
    this.menu.colorRow1.alignChildren = "fill";
    this.menu.colorRow1.spacing = 15;
    this.menu.colorRow2 = this.menu.colorPanel.add("group");
    this.menu.colorRow2.orientation = "row";
    this.menu.colorRow2.alignChildren = "fill";
    this.menu.colorRow2.spacing = 15;
    this.menu.colorRow3 = this.menu.colorPanel.add("group");
    this.menu.colorRow3.orientation = "row";
    this.menu.colorRow3.alignChildren = "fill";
    this.menu.colorRow3.spacing = 15;
    this.menu.colorRow4 = this.menu.colorPanel.add("group");
    this.menu.colorRow4.orientation = "row";
    this.menu.colorRow4.alignChildren = "fill";
    this.menu.colorRow4.spacing = 15;
    this.menu.colorRow5 = this.menu.colorPanel.add("group");
    this.menu.colorRow5.orientation = "row";
    this.menu.colorRow5.alignChildren = "fill";
    this.menu.colorRow5.spacing = 15;
    //--------------------
    // color panel buttons
    //--------------------
    this.menu.canvasColorBtn = this.menu.colorRow1.add("button", undefined, "Background Color");
    this.menu.canvasColorBtn.onClick = function() {colorScheme.tryUpdateMenu("CanvasColor");};
    this.menu.canvasColorBtn.helpTip = "Set the template background color";
    this.menu.canvasColorBtn.preferredSize = [130,20];
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.canvasBgIcon = this.menu.colorRow1.add("image", undefined, iconURL);
    this.menu.mainColorBtn = this.menu.colorRow2.add("button", undefined, "Main Image Color");
    this.menu.mainColorBtn.onClick = function() {colorScheme.tryUpdateMenu("MainColor");};
    this.menu.mainColorBtn.helpTip = "Set the template main image color";
    this.menu.mainColorBtn.preferredSize = [130,20];
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.mainIcon = this.menu.colorRow2.add("image", undefined, iconURL);
    this.menu.smallColorBtn = this.menu.colorRow3.add("button", undefined, "Small Image Color");
    this.menu.smallColorBtn.onClick = function() {colorScheme.tryUpdateMenu("SmallColor");};
    this.menu.smallColorBtn.helpTip = "Set the template small iamge color";
    this.menu.smallColorBtn.preferredSize = [130,20];
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.smallIcon = this.menu.colorRow3.add("image", undefined, iconURL);
    this.menu.canvasEdgeColorBtn = this.menu.colorRow4.add("button", undefined, "Canvas Border Color");
    this.menu.canvasEdgeColorBtn.onClick = function() {colorScheme.tryUpdateMenu("CanvasEdgeColor");};
    this.menu.canvasEdgeColorBtn.helpTip = "Set the template canvas border color";
    this.menu.canvasEdgeColorBtn.preferredSize = [130,20];
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.canvasEdgeIcon = this.menu.colorRow4.add("image", undefined, iconURL);
    this.menu.imageEdgeColorBtn = this.menu.colorRow5.add("button", undefined, "Image Border Color");
    this.menu.imageEdgeColorBtn.onClick = function() {colorScheme.tryUpdateMenu("ImageEdgeColor");};
    this.menu.imageEdgeColorBtn.helpTip = "Set the template image border color";
    this.menu.imageEdgeColorBtn.preferredSize = [130,20];
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.imageEdgeIcon = this.menu.colorRow5.add("image", undefined, iconURL);
    this.menu.onMove = function() {colorScheme.tryUpdateMenu("Move");};
    this.menu.onShow = function() {colorScheme.tryUpdateMenu("Show");};
    return;
}

// -------------------------------------------------------
// ColorScheme.tryUpdateMenu()
// -------------------------------------------------------
ColorScheme.prototype["tryUpdateMenu"] = function(caller) {
    var ex;

    try {
        if (this.menuActive || caller == "Move" || caller == "Show")
            this.updateMenu(caller);
    } catch(ex) {
        alert(scriptName + " ColorScheme.updateMenu(" + caller +
                           ") exception caught? line[" + ex.line + "]\n"  + ex);
        if (this.menuActive)
            this.menu.close(0); // there is no point in re-throwing the exception
    }
    return;
}

// -------------------------------------------------------
// ColorScheme.updateMenu()
// -------------------------------------------------------
ColorScheme.prototype["updateMenu"] = function(caller) {
    var aColor;

    switch(caller) {
        case "Move":
            this.winFrameLocation = this.menu.frameLocation;
            if (this.menuActive)
                waitForRedraw();
            break;
        case "CanvasColor":
            aColor = colorMenu.showDialog(this.bgColor, this.winFrameLocation);
            if (aColor != undefined) {
                this.bgColor = aColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.bgColor, true);
                    this.menu.canvasBgIcon.icon = "Step1Icon";
                    this.menu.canvasBgIcon.icon = iconURL;
                    this.menu.active = true;  // lost focus due to icon update?
                }
            }
            break;
        case "MainColor":
            aColor = colorMenu.showDialog(this.mainColor, this.winFrameLocation);
            if (aColor != undefined) {
                this.mainColor = aColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.mainColor, true);
                    this.menu.mainIcon.icon = "Step1Icon";
                    this.menu.mainIcon.icon = iconURL;
                    this.menu.active = true;  // lost focus due to icon update?
                }
            }
            break;
        case "SmallColor":
            aColor = colorMenu.showDialog(this.smallColor, this.winFrameLocation);
            if (aColor != undefined) {
                this.smallColor = aColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.smallColor, true);
                    this.menu.smallIcon.icon = "Step1Icon";
                    this.menu.smallIcon.icon = iconURL;
                    this.menu.active = true;  // lost focus due to icon update?
                }
            }
            break;
        case "CanvasEdgeColor":
            aColor = colorMenu.showDialog(this.canvasEdgeColor, this.winFrameLocation);
            if (aColor != undefined) {
                this.canvasEdgeColor = aColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.canvasEdgeColor, true);
                    this.menu.canvasEdgeIcon.icon = "Step1Icon";
                    this.menu.canvasEdgeIcon.icon = iconURL;
                    this.menu.active = true;  // lost focus due to icon update?
                }
            }
            break;
        case "ImageEdgeColor":
            aColor = colorMenu.showDialog(this.imageEdgeColor, this.winFrameLocation);
            if (aColor != undefined) {
                this.imageEdgeColor = aColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.imageEdgeColor, true);
                    this.menu.imageEdgeIcon.icon = "Step1Icon";
                    this.menu.imageEdgeIcon.icon = iconURL;
                    this.menu.active = true;  // lost focus due to icon update?
                }
            }
            break;
        case "Show":
            if (this.isIconValid) {    // update the PNG image icon colors
                this.updatePNGicon(this.bgColor, false);
                this.menu.canvasBgIcon.icon = "Step1Icon";
                this.menu.canvasBgIcon.icon = iconURL;
                this.updatePNGicon(this.mainColor, false);
                this.menu.mainIcon.icon = "Step1Icon";
                this.menu.mainIcon.icon = iconURL;
                this.updatePNGicon(this.smallColor, false);
                this.menu.smallIcon.icon = "Step1Icon";
                this.menu.smallIcon.icon = iconURL;
                this.updatePNGicon(this.canvasEdgeColor, false);
                this.menu.canvasEdgeIcon.icon = "Step1Icon";
                this.menu.canvasEdgeIcon.icon = iconURL;
                this.updatePNGicon(this.imageEdgeColor, true);
                this.menu.imageEdgeIcon.icon = "Step1Icon";
                this.menu.imageEdgeIcon.icon = iconURL;
            }
            this.menuActive = true;
            break;
        default:
            alert("ColorScheme.updateMenu() Invalid caller=" + caller);
            break;
    }
    return;
}

// -------------------------------------------------------
// ColorScheme.updatePNGicon()
// -------------------------------------------------------
ColorScheme.prototype["updatePNGicon"] = function(color, closeOpt) {
    var ex;

    if (docRefIcon == null) {
        try {
            app.open(File(iconURL));
            docRefIcon = app.activeDocument;
            docRefIcon.activeLayer = docRefIcon.layers[docRefIcon.layers.length-1];
        } catch(ex) {
            alert("ColorScheme.updatePNGicon() Failed to open icon: " + iconURL +
                  "\n Line(" + ex.line + ") " + ex);
            return;
        }
    }
    try {
        app.activeDocument = docRefIcon;
        docRefIcon.selection.selectAll();
        docRefIcon.selection.fill(color);       // fill selection with solid color
        docRefIcon.selection.deselect();
        if (closeOpt) {
            docRefIcon.close(SaveOptions.SAVECHANGES);
            docRefIcon = null;                  // close the PS document
        } else {
            docRefIcon.save();                  // save changes for icon display update
        }
    } catch(ex) {
        alert("ColorScheme.updatePNGicon() exception caught? line[" + ex.line + "] "  + ex);
        this.menu.close(0); // there is no point in re-throwing the exception
    }
    return;
}

// -------------------------------------------------------
// ColorScheme.showMenu()
// display the UI dialog window
// -------------------------------------------------------
ColorScheme.prototype["showMenu"] = function(framePlacement) {
    var rc;

    if (this.winFrameLocation == null)
        this.winFrameLocation = framePlacement;
    this.buildMenu(framePlacement);        // create the window
    rc = this.menu.show();                  // show the dialog
    if (rc == 1)                           // OK
        this.rePop();                      // update selected global options
    return(rc);
}

// =======================================================
// LayerMenu Dialog Menu Routines
// =======================================================

// -------------------------------------------------------
// LayerMenu()
// Constructor: menu defaults from global configuration
// -------------------------------------------------------
function LayerMenu(useIcon) {
    this.strokeEffect;
    this.strokeColor;
    this.strokeSize;
    this.strokePosition;
    this.overlayEffect;
    this.overlayColor;
    this.overlayOpacity;
    this.dropShadowColor;
    this.dropShadowEffect;
    this.dropShadowAngle;
    this.dropShadowSize;
    this.dropShadowDistance;
    this.dropShadowSpread;
    this.embossEffect;
    this.embossDepth;
    this.embossSize;
    this.embossSoften;
    this.shadingAngle;
    this.shadingAltitude;
    this.glowEffect;
    this.glowInner;
    this.glowColor;
    this.glowOpacity;
    this.glowSize;
    this.glowContourName;
    this.isIconValid = useIcon;              // shuld we use the PNG icon
    this.winFrameLocation = null;            // current window placement
    this.menuActive = false;                 // initialization switch
    this.checkOptions = false;               // ok or cancel ?
    this.menu = undefined;                    // the dialog menu window
    return;
}

// -------------------------------------------------------
// LayerMenu.rePop()
// repopulate global variables
// -------------------------------------------------------
LayerMenu.prototype["rePop"] = function() {
    strokeEffect = this.strokeEffect;
    strokeColor = this.strokeColor;
    strokeSize = this.strokeSize;
    strokePosition = this.strokePosition;
    overlayEffect = this.overlayEffect;
    overlayColor = this.overlayColor;
    overlayOpacity = this.overlayOpacity;
    dropShadowColor = this.dropShadowColor;
    dropShadowEffect = this.dropShadowEffect;
    dropShadowAngle = this.dropShadowAngle;
    dropShadowSize = this.dropShadowSize;
    dropShadowDistance = this.dropShadowDistance;
    dropShadowSpread = this.dropShadowSpread;
    embossEffect = this.embossEffect;
    embossDepth = this.embossDepth;
    embossSize = this.embossSize;
    embossSoften = this.embossSoften;
    shadingAngle = this.shadingAngle;
    shadingAltitude = this.shadingAltitude;
    glowEffect = this.glowEffect;
    glowInner = this.glowInner;
    glowColor = this.glowColor;
    glowOpacity = this.glowOpacity;
    glowSize = this.glowSize;
    glowContourName = this.glowContourName;
    return;
}

// -------------------------------------------------------
// LayerMenu.createDialog()
// create the UI dialog window
// -------------------------------------------------------
LayerMenu.prototype["createDialog"] = function() {
    var listValues;

    //-----------------------
    // Refresh global options
    //-----------------------
    this.strokeEffect = strokeEffect;
    this.strokeColor = strokeColor;
    this.strokeSize = strokeSize;
    this.strokePosition = strokePosition;
    this.overlayEffect = overlayEffect;
    this.overlayColor = overlayColor;
    this.overlayOpacity = overlayOpacity;
    this.dropShadowColor = dropShadowColor;
    this.dropShadowEffect = dropShadowEffect;
    this.dropShadowAngle = dropShadowAngle;
    this.dropShadowSize = dropShadowSize;
    this.dropShadowDistance = dropShadowDistance;
    this.dropShadowSpread = dropShadowSpread;
    this.embossEffect = embossEffect;
    this.embossDepth = embossDepth;
    this.embossSize = embossSize;
    this.embossSoften = embossSoften;
    this.shadingAngle = shadingAngle;
    this.shadingAltitude = shadingAltitude;
    this.glowEffect = glowEffect;
    this.glowInner = glowInner;
    this.glowColor = glowColor;
    this.glowOpacity = glowOpacity;
    this.glowSize = glowSize;
    this.glowContourName = glowContourName;
    //--------------------------
    // Create the UI Dialog Menu
    //--------------------------
    this.menuActive = false;                 // initialization switch
    this.menu = new Window("dialog", "Chose Layer Effects");
    this.menu.frameLocation = this.winFrameLocation;
    //--------------------
    // OK & Cancel buttons
    //--------------------
    this.menu.mainGroup = this.menu.add("group");
    this.menu.mainGroup.orientation = "row";
    this.menu.mainGroup.alignChildren = "fill";
    this.menu.mainGroup.spacing = 25;
    this.menu.btnOk = this.menu.mainGroup.add("button", undefined, "OK");
    this.menu.btnOk.onClick = function() {this.parent.parent.close(1);};
    this.menu.btnOk.helpTip = "Accept changes";
    this.menu.btnCancel = this.menu.mainGroup.add("button", undefined, "Cancel");
    this.menu.btnCancel.onClick = function() {this.parent.parent.close(0);};
    this.menu.btnCancel.helpTip = "Dismiss changes";
    //-----------------------------
    // Add the stroke effects panel
    //-----------------------------
    this.menu.strokePanel = this.menu.add("panel", undefined, "Stroke Options");
    this.menu.strokePanel.orientation = "column";
    this.menu.strokePanel.alignChildren = "fill";
    this.menu.strokePanel.spacing = 10;
    //-----------------------------
    // Add the stroke effect groups
    //-----------------------------
    this.menu.stroke1Group = this.menu.strokePanel.add("group");
    this.menu.stroke1Group.orientation = "row";
    this.menu.stroke1Group.alignChildren = "fill";
    this.menu.stroke1Group.spacing = 15;
    this.menu.stroke2Group = this.menu.strokePanel.add("group");
    this.menu.stroke2Group.orientation = "row";
    this.menu.stroke2Group.alignChildren = "fill";
    this.menu.stroke2Group.spacing = 15;
    //-----------------------------
    // stroke effects panel options
    //-----------------------------
    this.menu.strokeEffectCb = this.menu.stroke1Group.add("checkbox", undefined, "Enable Stroke");
    this.menu.strokeEffectCb.preferredSize = [160,20];
    this.menu.strokeEffectCb.onClick = function() {layerMenu.tryUpdateMenu("EnableEffects");};
    this.menu.strokeEffectCb.helpTip = "Enable Layer Stroke Effect";
    if (this.strokeEffect)
       this.menu.strokeEffectCb.value = true;
    else
       this.menu.strokeEffectCb.value = false;
    this.menu.strokeColorBtn = this.menu.stroke1Group.add("button", undefined, "Color");
    this.menu.strokeColorBtn.onClick = function() {layerMenu.tryUpdateMenu("StrokeColor");};
    this.menu.strokeColorBtn.helpTip = "Stroke Color Dialog";
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.strokeColorIcon = this.menu.stroke1Group.add("image", undefined, iconURL);
    this.menu.strokeSizeTxt = this.menu.stroke2Group.add("statictext", undefined, "Stroke Size");
    this.menu.strokeSizeTxt.preferredSize = [115,20];
    this.menu.strokeSizeValue = this.menu.stroke2Group.add("edittext", undefined, this.strokeSize);
    this.menu.strokeSizeValue.preferredSize = [40,20];
    this.menu.strokeSizeValue.onChange = function() {layerMenu.tryUpdateMenu("StrokeSize");};
    this.menu.strokeSizeValue.helpTip = "Stroke Size, 1-250 pixels";
    listValues = new Array("outside", "inside", "center");
    this.menu.strokePositionTxtBx = this.menu.stroke2Group.add("statictext", undefined, "Stroke Position");
    this.menu.strokePositionTxtBx.preferredSize = [90,20];
    this.menu.strokePositionLstBx = this.menu.stroke2Group.add("dropdownlist", undefined, listValues);
    this.menu.strokePositionLstBx.helpTip = "Select a stroke position";
    this.menu.strokePositionLstBx.onChange = function() {layerMenu.tryUpdateMenu("StrokePosition");};
    switch(this.strokePosition) {
        case "InsF":
            this.menu.strokePositionLstBx.items[1].selected = true; break;
        case "CtrF":
            this.menu.strokePositionLstBx.items[2].selected = true; break;
        case "OutF":
        default:
            this.menu.strokePositionLstBx.items[0].selected = true; break;
    }
    //------------------------------------
    // Add the color overlay effects panel
    //------------------------------------
    this.menu.overlayPanel = this.menu.add("panel", undefined, "Color Overlay Options");
    this.menu.overlayPanel.orientation = "column";
    this.menu.overlayPanel.alignChildren = "fill";
    this.menu.overlayPanel.spacing = 10;
    //------------------------------------
    // Add the color overlay effect groups
    //------------------------------------
    this.menu.overlay1Group = this.menu.overlayPanel.add("group");
    this.menu.overlay1Group.orientation = "row";
    this.menu.overlay1Group.alignChildren = "fill";
    this.menu.overlay1Group.spacing = 15;
    this.menu.overlay2Group = this.menu.overlayPanel.add("group");
    this.menu.overlay2Group.orientation = "row";
    this.menu.overlay2Group.alignChildren = "fill";
    this.menu.overlay2Group.spacing = 15;
    //----------------------------
    // color overlay panel options
    //----------------------------
    this.menu.overlayEffectCb = this.menu.overlay1Group.add("checkbox", undefined, "Enable Color Overlay");
    this.menu.overlayEffectCb.preferredSize = [160,20];
    this.menu.overlayEffectCb.onClick = function() {layerMenu.tryUpdateMenu("EnableEffects");};
    this.menu.overlayEffectCb.helpTip = "Enable Layer Color Overlay Effect";
    if (this.overlayEffect)
       this.menu.overlayEffectCb.value = true;
    else
       this.menu.overlayEffectCb.value = false;
    this.menu.overlayColorBtn = this.menu.overlay1Group.add("button", undefined, "Color");
    this.menu.overlayColorBtn.onClick = function() {layerMenu.tryUpdateMenu("OverlayColor");};
    this.menu.overlayColorBtn.helpTip = "Overlay Color Dialog\nTry [43,2,2] for Sepia tone";
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.overlayColorIcon = this.menu.overlay1Group.add("image", undefined, iconURL);
    this.menu.overlayOpacityTxt = this.menu.overlay2Group.add("statictext", undefined, "Color Overlay Opacity");
    this.menu.overlayOpacityTxt.preferredSize = [115,20];
    this.menu.overlayOpacityValue = this.menu.overlay2Group.add("edittext", undefined, this.overlayOpacity);
    this.menu.overlayOpacityValue.preferredSize = [40,20];
    this.menu.overlayOpacityValue.onChange = function() {layerMenu.tryUpdateMenu("OverlayOpacity");};
    this.menu.overlayOpacityValue.helpTip = "Color Overlay Opacity, 0-100%";
    this.menu.overlayFillerTxt = this.menu.overlay2Group.add("statictext", undefined, "");
    this.menu.overlayFillerTxt.preferredSize = [170,20];
    //----------------------------------
    // Add the drop shadow effects panel
    //----------------------------------
    this.menu.dropShadowPanel = this.menu.add("panel", undefined, "Drop Shadow Options");
    this.menu.dropShadowPanel.orientation = "column";
    this.menu.dropShadowPanel.alignChildren = "fill";
    this.menu.dropShadowPanel.spacing = 10;
    //----------------------------------
    // Add the drop shadow effect groups
    //----------------------------------
    this.menu.shadow1Group = this.menu.dropShadowPanel.add("group");
    this.menu.shadow1Group.orientation = "row";
    this.menu.shadow1Group.alignChildren = "fill";
    this.menu.shadow1Group.spacing = 15;
    this.menu.shadow2Group = this.menu.dropShadowPanel.add("group");
    this.menu.shadow2Group.orientation = "row";
    this.menu.shadow2Group.alignChildren = "fill";
    this.menu.shadow2Group.spacing = 15;
    this.menu.shadow3Group = this.menu.dropShadowPanel.add("group");
    this.menu.shadow3Group.orientation = "row";
    this.menu.shadow3Group.alignChildren = "fill";
    this.menu.shadow3Group.spacing = 15;
    //--------------------------
    // drop shadow panel options
    //--------------------------
    this.menu.shadowEffectCb = this.menu.shadow1Group.add("checkbox", undefined, "Enable Drop Shadow");
    this.menu.shadowEffectCb.preferredSize = [160,20];
    this.menu.shadowEffectCb.onClick = function() {layerMenu.tryUpdateMenu("EnableEffects");};
    this.menu.shadowEffectCb.helpTip = "Enable Layer Drop Shadow Effect";
    if (this.dropShadowEffect)
       this.menu.shadowEffectCb.value = true;
    else
       this.menu.shadowEffectCb.value = false;
    this.menu.shadowColorBtn = this.menu.shadow1Group.add("button", undefined, "Color");
    this.menu.shadowColorBtn.onClick = function() {layerMenu.tryUpdateMenu("DropShadowColor");};
    this.menu.shadowColorBtn.helpTip = "Drop Shadow Color Dialog";
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.shadowColorIcon = this.menu.shadow1Group.add("image", undefined, iconURL);
    this.menu.shadowAngleTxt = this.menu.shadow2Group.add("statictext", undefined, "Drop Shadow Angle");
    this.menu.shadowAngleTxt.preferredSize = [115,20];
    this.menu.shadowAngleValue = this.menu.shadow2Group.add("edittext", undefined, this.dropShadowAngle);
    this.menu.shadowAngleValue.preferredSize = [40,20];
    this.menu.shadowAngleValue.onChange = function() {layerMenu.tryUpdateMenu("DropShadow");};
    this.menu.shadowAngleValue.helpTip = "Drop Shadow Angle, -180 - +180 �";
    this.menu.shadowSizeTxt = this.menu.shadow2Group.add("statictext", undefined, "Drop Shadow Size");
    this.menu.shadowSizeTxt.preferredSize = [115,20];
    this.menu.shadowSizeValue = this.menu.shadow2Group.add("edittext", undefined, this.dropShadowSize);
    this.menu.shadowSizeValue.preferredSize = [40,20];
    this.menu.shadowSizeValue.onChange = function() {layerMenu.tryUpdateMenu("DropShadow");};
    this.menu.shadowSizeValue.helpTip = "Drop Shadow Size, 0-250 pixels";
    this.menu.shadowDistanceTxt = this.menu.shadow3Group.add("statictext", undefined, "Drop Shadow Distance");
    this.menu.shadowDistanceTxt.preferredSize = [115,20];
    this.menu.shadowDistanceValue = this.menu.shadow3Group.add("edittext", undefined, this.dropShadowDistance);
    this.menu.shadowDistanceValue.preferredSize = [40,20];
    this.menu.shadowDistanceValue.onChange = function() {layerMenu.tryUpdateMenu("DropShadow");};
    this.menu.shadowDistanceValue.helpTip = "Drop Shadow Distance, 0-30,000 pixels";
    this.menu.shadowSpreadTxt = this.menu.shadow3Group.add("statictext", undefined, "Drop Shadow Spread");
    this.menu.shadowSpreadTxt.preferredSize = [115,20];
    this.menu.shadowSpreadValue = this.menu.shadow3Group.add("edittext", undefined, this.dropShadowSpread);
    this.menu.shadowSpreadValue.preferredSize = [40,20];
    this.menu.shadowSpreadValue.onChange = function() {layerMenu.tryUpdateMenu("DropShadow");};
    this.menu.shadowSpreadValue.helpTip = "Drop Shadow Spread, 0-100 pixels";
    //---------------------------------------
    // Add the bevel and emboss effects panel
    //---------------------------------------
    this.menu.embossPanel = this.menu.add("panel", undefined, "Bevel and Emboss Options");
    this.menu.embossPanel.orientation = "column";
    this.menu.embossPanel.alignChildren = "fill";
    this.menu.embossPanel.spacing = 10;
    //---------------------------------------
    // Add the bevel and emboss effect groups
    //---------------------------------------
    this.menu.emboss1Group = this.menu.embossPanel.add("group");
    this.menu.emboss1Group.orientation = "row";
    this.menu.emboss1Group.alignChildren = "fill";
    this.menu.emboss1Group.spacing = 15;
    this.menu.emboss2Group = this.menu.embossPanel.add("group");
    this.menu.emboss2Group.orientation = "row";
    this.menu.emboss2Group.alignChildren = "fill";
    this.menu.emboss2Group.spacing = 15;
    this.menu.emboss3Group = this.menu.embossPanel.add("group");
    this.menu.emboss3Group.orientation = "row";
    this.menu.emboss3Group.alignChildren = "fill";
    this.menu.emboss3Group.spacing = 15;
    //-------------------------------
    // bevel and emboss panel options
    //-------------------------------
    this.menu.embossEffectCb = this.menu.emboss1Group.add("checkbox", undefined, "Enable Bevel and Emboss");
    this.menu.embossEffectCb.preferredSize = [170,20];
    this.menu.embossEffectCb.onClick = function() {layerMenu.tryUpdateMenu("EnableEffects");};
    this.menu.embossEffectCb.helpTip = "Enable Layer Bevel and Emboss Effect";
    if (this.embossEffect)
       this.menu.embossEffectCb.value = true;
    else
       this.menu.embossEffectCb.value = false;
    this.menu.embossDepthTxt = this.menu.emboss1Group.add("statictext", undefined, "Emboss Depth");
    this.menu.embossDepthTxt.preferredSize = [115,20];
    this.menu.embossDepthValue = this.menu.emboss1Group.add("edittext", undefined, this.embossDepth);
    this.menu.embossDepthValue.preferredSize = [40,20];
    this.menu.embossDepthValue.onChange = function() {layerMenu.tryUpdateMenu("Emboss");};
    this.menu.embossDepthValue.helpTip = "Emboss Depth, 0 - 1000%";
    this.menu.embossSizeTxt = this.menu.emboss2Group.add("statictext", undefined, "Emboss Size");
    this.menu.embossSizeTxt.preferredSize = [115,20];
    this.menu.embossSizeValue = this.menu.emboss2Group.add("edittext", undefined, this.embossSize);
    this.menu.embossSizeValue.preferredSize = [40,20];
    this.menu.embossSizeValue.onChange = function() {layerMenu.tryUpdateMenu("Emboss");};
    this.menu.embossSizeValue.helpTip = "Emboss Size, 0 - 250 pixels";
    this.menu.embossSoftenTxt = this.menu.emboss2Group.add("statictext", undefined, "Emboss Soften");
    this.menu.embossSoftenTxt.preferredSize = [115,20];
    this.menu.embossSoftenValue = this.menu.emboss2Group.add("edittext", undefined, this.embossSoften);
    this.menu.embossSoftenValue.preferredSize = [40,20];
    this.menu.embossSoftenValue.onChange = function() {layerMenu.tryUpdateMenu("Emboss");};
    this.menu.embossSoftenValue.helpTip = "Emboss Soften, 0 - 16 pixels";
    this.menu.shadingAngleTxt = this.menu.emboss3Group.add("statictext", undefined, "Shading Angle");
    this.menu.shadingAngleTxt.preferredSize = [115,20];
    this.menu.shadingAngleValue = this.menu.emboss3Group.add("edittext", undefined, this.shadingAngle);
    this.menu.shadingAngleValue.preferredSize = [40,20];
    this.menu.shadingAngleValue.onChange = function() {layerMenu.tryUpdateMenu("Emboss");};
    this.menu.shadingAngleValue.helpTip = "Shading Angle, -180 to +180 �";
    this.menu.shadingAltitudeTxt = this.menu.emboss3Group.add("statictext", undefined, "Shading Altitude");
    this.menu.shadingAltitudeTxt.preferredSize = [115,20];
    this.menu.shadingAltitudeValue = this.menu.emboss3Group.add("edittext", undefined, this.shadingAltitude);
    this.menu.shadingAltitudeValue.preferredSize = [40,20];
    this.menu.shadingAltitudeValue.onChange = function() {layerMenu.tryUpdateMenu("Emboss");};
    this.menu.shadingAltitudeValue.helpTip = "Shading Altitude, 0 to 90 �";
    //---------------------------
    // Add the glow effects panel
    //---------------------------
    this.menu.glowPanel = this.menu.add("panel", undefined, "Glow Options");
    this.menu.glowPanel.orientation = "column";
    this.menu.glowPanel.alignChildren = "fill";
    this.menu.glowPanel.spacing = 10;
    //---------------------------
    // Add the glow effect groups
    //---------------------------
    this.menu.glow1Group = this.menu.glowPanel.add("group");
    this.menu.glow1Group.orientation = "row";
    this.menu.glow1Group.alignChildren = "fill";
    this.menu.glow1Group.spacing = 15;
    this.menu.glow2Group = this.menu.glowPanel.add("group");
    this.menu.glow2Group.orientation = "row";
    this.menu.glow2Group.alignChildren = "fill";
    this.menu.glow2Group.spacing = 15;
    this.menu.glow3Group = this.menu.glowPanel.add("group");
    this.menu.glow3Group.orientation = "row";
    this.menu.glow3Group.alignChildren = "fill";
    this.menu.glow3Group.spacing = 15;
    //-------------------
    // glow panel options
    //-------------------
    this.menu.glowEffectCb = this.menu.glow1Group.add("checkbox", undefined, "Enable Inner or Outer Glow");
    this.menu.glowEffectCb.preferredSize = [160,20];
    this.menu.glowEffectCb.onClick = function() {layerMenu.tryUpdateMenu("EnableEffects");};
    this.menu.glowEffectCb.helpTip = "Enable Inner or Outer Glow Effect";
    if (this.glowEffect)
       this.menu.glowEffectCb.value = true;
    else
       this.menu.glowEffectCb.value = false;
    this.menu.glowColorBtn = this.menu.glow1Group.add("button", undefined, "Color");
    this.menu.glowColorBtn.onClick = function() {layerMenu.tryUpdateMenu("GlowColor");};
    this.menu.glowColorBtn.helpTip = "Glow Effect Color Dialog";
    if (this.isIconValid)                        // add the PNG image icon
        this.menu.glowColorIcon = this.menu.glow1Group.add("image", undefined, iconURL);
    this.menu.glowInnerRb = this.menu.glow2Group.add("radiobutton", undefined, "In");
    this.menu.glowInnerRb.onClick = function() {layerMenu.tryUpdateMenu("GlowInOut");};
    this.menu.glowInnerRb.helpTip = "Inner Glow";
    this.menu.glowInnerRb.preferredSize = [40,20];
    this.menu.glowOuterRb = this.menu.glow2Group.add("radiobutton", undefined, "Out");
    this.menu.glowOuterRb.onClick = function() {layerMenu.tryUpdateMenu("GlowInOut");};
    this.menu.glowOuterRb.helpTip = "Outer Glow";
    this.menu.glowOuterRb.preferredSize = [40,20];
    if (this.glowInner)
        this.menu.glowInnerRb.value = true;
    else
        this.menu.glowOuterRb.value = true;
    this.menu.glowFillerTxt = this.menu.glow2Group.add("statictext", undefined, "");
    this.menu.glowFillerTxt.preferredSize = [60,20];
    listValues = new Array("linear", "ring", "double ring");
    this.menu.glowContourTxtBx = this.menu.glow2Group.add("statictext", undefined, "Contour Shape");
    this.menu.glowContourTxtBx.preferredSize = [75,20];
    this.menu.glowContourLstBx = this.menu.glow2Group.add("dropdownlist", undefined, listValues);
    this.menu.glowContourLstBx.helpTip = "Select a glow shape contour";
    this.menu.glowContourLstBx.onChange = function() {layerMenu.tryUpdateMenu("GlowContour");};
    this.menu.glowContourLstBx.preferredSize = [80,20];
    switch(this.glowContourName) {
        case "Ring":
            this.menu.glowContourLstBx.items[1].selected = true; break;
        case "Ring - Double":
            this.menu.glowContourLstBx.items[2].selected = true; break;
        case "Linear":
        default:
            this.menu.glowContourLstBx.items[0].selected = true; break;
    }
    this.menu.glowSizeTxt = this.menu.glow3Group.add("statictext", undefined, "Glow Size");
    this.menu.glowSizeTxt.preferredSize = [115,20];
    this.menu.glowSizeValue = this.menu.glow3Group.add("edittext", undefined, this.glowSize);
    this.menu.glowSizeValue.preferredSize = [40,20];
    this.menu.glowSizeValue.onChange = function() {layerMenu.tryUpdateMenu("GlowSize");};
    this.menu.glowSizeValue.helpTip = "Glow Size, 0-250 pixels";
    this.menu.glowOpacityTxt = this.menu.glow3Group.add("statictext", undefined, "Glow Opacity");
    this.menu.glowOpacityTxt.preferredSize = [115,20];
    this.menu.glowOpacityValue = this.menu.glow3Group.add("edittext", undefined, this.glowOpacity);
    this.menu.glowOpacityValue.preferredSize = [40,20];
    this.menu.glowOpacityValue.onChange = function() {layerMenu.tryUpdateMenu("GlowOpacity");};
    this.menu.glowOpacityValue.helpTip = "Glow Opacity, 0-100%";
    this.menu.onMove = function() {layerMenu.tryUpdateMenu("Move");};
    this.menu.onShow = function() {layerMenu.tryUpdateMenu("Show");};
    return(this.menu);
}

// -------------------------------------------------------
// LayerMenu.tryUpdateMenu()
// -------------------------------------------------------
LayerMenu.prototype["tryUpdateMenu"] = function(caller) {
    var ex;

    try {
        if (this.menuActive || caller == "Move" || caller == "Show")
            this.updateMenu(caller);
    } catch(ex) {
        alert(scriptName + " LayerMenu.updateMenu(" + caller +
                           ") exception caught? line[" + ex.line + "]\n"  + ex);
        if (this.menuActive)
            this.menu.close(0); // there is no point in re-throwing the exception
    }
    return;
}

// -------------------------------------------------------
// LayerMenu.updateMenu()
// -------------------------------------------------------
LayerMenu.prototype["updateMenu"] = function(caller) {
    var selectItem, testNum;
    var testColor;

    switch(caller) {
        case "Move":
            this.winFrameLocation = this.menu.frameLocation;
            if (this.menuActive)
                waitForRedraw();
            break;
        case "EnableEffects":
            if (this.menu.strokeEffectCb.value)
                this.strokeEffect = true;
            else
                this.strokeEffect = false;
            if (this.menu.overlayEffectCb.value)
                this.overlayEffect = true;
            else
                this.overlayEffect = false;
            if (this.menu.shadowEffectCb.value)
                this.dropShadowEffect = true;
            else
                this.dropShadowEffect = false;
            if (this.menu.embossEffectCb.value)
                this.embossEffect = true;
            else
                this.embossEffect = false;
            if (this.menu.glowEffectCb.value)
                this.glowEffect = true;
            else
                this.glowEffect = false;
            break;
        case "StrokeColor":
            testColor = colorMenu.showDialog(this.strokeColor, this.winFrameLocation);
            if (testColor != undefined) {
                this.strokeColor = testColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.strokeColor, true);
                    this.menu.strokeColorIcon.icon = "Step1Icon";
                    this.menu.strokeColorIcon.icon = iconURL;
                }
            }
            this.menu.active = true;  // lost focus due to icon update?
            break;
        case "StrokeSize":
            testNum = Number(this.menu.strokeSizeValue.text);
            if (isNaN(testNum) || testNum < 1 || testNum > 250) {
                alert(scriptName + " Stroke Size=" + testNum + ", must be a number, 1-250 pixels");
                this.menu.strokeSizeValue.text = this.strokeSize;
            } else
                this.strokeSize = testNum;
            break;
        case "StrokePosition":
            if (this.menu.strokePositionLstBx.items[1].selected)
                this.strokePosition = "InsF";
            else if (this.menu.strokePositionLstBx.items[2].selected)
                this.strokePosition = "CtrF";
            else
                this.strokePosition = "OutF";
            break;
        case "OverlayColor":
            testColor = colorMenu.showDialog(this.overlayColor, this.winFrameLocation);
            if (testColor != undefined) {
                this.overlayColor = testColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.overlayColor, true);
                    this.menu.overlayColorIcon.icon = "Step1Icon";
                    this.menu.overlayColorIcon.icon = iconURL;
                }
            }
            this.menu.active = true;  // lost focus due to icon update?
            break;
        case "OverlayOpacity":
            testNum = Number(this.menu.overlayOpacityValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 100) {
                alert(scriptName + " Color Overlay Opacity=" + testNum + ", must be a number, 0-100%");
                this.menu.overlayOpacityValue.text = this.overlayOpacity;
            } else
                this.overlayOpacity = testNum;
            break;
        case "DropShadowColor":
            testColor = colorMenu.showDialog(this.dropShadowColor, this.winFrameLocation);
            if (testColor != undefined) {
                this.dropShadowColor = testColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.dropShadowColor, true);
                    this.menu.shadowColorIcon.icon = "Step1Icon";
                    this.menu.shadowColorIcon.icon = iconURL;
                }
            }
            this.menu.active = true;  // lost focus due to icon update?
            break;
        case "GlowColor":
            testColor = colorMenu.showDialog(this.glowColor, this.winFrameLocation);
            if (testColor != undefined) {
                this.glowColor = testColor;
                if (this.isIconValid) {   // update the PNG image icon
                    this.updatePNGicon(this.glowColor, true);
                    this.menu.glowColorIcon.icon = "Step1Icon";
                    this.menu.glowColorIcon.icon = iconURL;
                }
            }
            this.menu.active = true;  // lost focus due to icon update?
            break;
        case "DropShadow":
            testNum = Number(this.menu.shadowAngleValue.text);
            if (isNaN(testNum) || testNum < -180 || testNum > +180) {
                alert(scriptName + " Drop Shadow Angle=" + testNum + ", must be a number, -180 to +180 �");
                this.menu.shadowAngleValue.text = this.dropShadowAngle;
            } else
                this.dropShadowAngle = testNum;
            testNum = Number(this.menu.shadowSizeValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 250) {
                alert(scriptName + " Drop Shadow Size=" + testNum + ", must be a number, 0 - 250 pixels");
                this.menu.shadowSizeValue.text = this.dropShadowSize;
            } else
                this.dropShadowSize = testNum;
            testNum = Number(this.menu.shadowDistanceValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 30000) {
                alert(scriptName + " Drop Shadow Distance=" + testNum + ", must be a number, 0 - 30,000 pixels");
                this.menu.shadowDistanceValue.text = this.dropShadowDistance;
            } else
                this.dropShadowDistance = testNum;
            testNum = Number(this.menu.shadowSpreadValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 100) {
                alert(scriptName + " Drop Shadow Spread=" + testNum + ", must be a number, 0 - 100 pixels");
                this.menu.shadowSpreadValue.text = this.dropShadowSpread;
            } else
                this.dropShadowSpread = testNum;
            break;
        case "Emboss":
            testNum = Number(this.menu.embossDepthValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 1000) {
                alert(scriptName + " Emboss Depth=" + testNum + ", must be a number, 0 - 1000 percent");
                this.menu.embossDepthValue.text = this.embossDepth;
            } else
                this.embossDepth = testNum;
            testNum = Number(this.menu.embossSizeValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 250) {
                alert(scriptName + " Emboss Size=" + testNum + ", must be a number, 0 - 250 pixels");
                this.menu.embossSizeValue.text = this.embossSize;
            } else
                this.embossSize = testNum;
            testNum = Number(this.menu.embossSoftenValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 16) {
                alert(scriptName + " Emboss Soften=" + testNum + ", must be a number, 0 - 16 pixels");
                this.menu.embossSoftenValue.text = this.embossSoften;
            } else
                this.embossSoften = testNum;
            testNum = Number(this.menu.shadingAngleValue.text);
            if (isNaN(testNum) || testNum < -180 || testNum > +180) {
                alert(scriptName + " Shading Angle=" + testNum + ", must be a number, -180 to +180 �");
                this.menu.shadingAngleValue.text = this.shadingAngle;
            } else
                this.shadingAngle = testNum;
            testNum = Number(this.menu.shadingAltitudeValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 90) {
                alert(scriptName + " Shading Altitude=" + testNum + ", must be a number, 0 to 90 �");
                this.menu.shadingAltitudeValue.text = this.shadingAltitude;
            } else
                this.shadingAltitude = testNum;
            break;
        case "GlowInOut":
            if (this.menu.glowInnerRb.value)
                this.glowInner = true;
            else
                this.glowInner = false;
            break;
        case "GlowOpacity":
            testNum = Number(this.menu.glowOpacityValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 100) {
                alert(scriptName + " Glow Opacity=" + testNum + ", must be a number, 0-100%");
                this.menu.glowOpacityValue.text = this.glowOpacity;
            } else
                this.glowOpacity = testNum;
            break;
        case "GlowSize":
            testNum = Number(this.menu.glowSizeValue.text);
            if (isNaN(testNum) || testNum < 1 || testNum > 250) {
                alert(scriptName + " Glow Size=" + testNum + ", must be a number, 1-250 pixels");
                this.menu.glowSizeValue.text = this.glowSize;
            } else
                this.glowSize = testNum;
            break;
        case "GlowContour":
            if (this.menu.glowContourLstBx.items[1].selected)
                this.glowContourName = "Ring";
            else if (this.menu.glowContourLstBx.items[2].selected)
                this.glowContourName = "Ring - Double";
            else
                this.glowContourName = "Linear";
            break;
        case "Show":
            if (this.isIconValid) {    // update the PNG image icon colors
                this.updatePNGicon(this.strokeColor, false);
                this.menu.strokeColorIcon.icon = "Step1Icon";
                this.menu.strokeColorIcon.icon = iconURL;
                this.updatePNGicon(this.overlayColor, false);
                this.menu.overlayColorIcon.icon = "Step1Icon";
                this.menu.overlayColorIcon.icon = iconURL;
                this.updatePNGicon(this.dropShadowColor, false);
                this.menu.shadowColorIcon.icon = "Step1Icon";
                this.menu.shadowColorIcon.icon = iconURL;
                this.updatePNGicon(this.glowColor, true);
                this.menu.glowColorIcon.icon = "Step1Icon";
                this.menu.glowColorIcon.icon = iconURL;
            }
            this.menuActive = true;
            break;
        default:
            alert("LayerMenu.updateMenu() Invalid caller=" + caller);
            break;
    }
    return;
}

// -------------------------------------------------------
// LayerMenu.updatePNGicon()
// -------------------------------------------------------
LayerMenu.prototype["updatePNGicon"] = function(color, closeOpt) {
    var ex;

    if (docRefIcon == null) {
        try {
            app.open(File(iconURL));
            docRefIcon = app.activeDocument;
            docRefIcon.activeLayer = docRefIcon.layers[docRefIcon.layers.length-1];
        } catch(ex) {
            alert("LayerMenu.updatePNGicon() Failed to open icon: " + iconURL +
                  "\n Line(" + ex.line + ") " + ex);
            return;
        }
    }
    try {
        app.activeDocument = docRefIcon;
        docRefIcon.selection.selectAll();
        docRefIcon.selection.fill(color);       // fill selection with solid color
        docRefIcon.selection.deselect();
        if (closeOpt) {
            docRefIcon.close(SaveOptions.SAVECHANGES);
            docRefIcon = null;                  // close the PS document
        } else {
            docRefIcon.save();                  // save changes for icon display update
        }
    } catch(ex) {
        alert("LayerMenu.updatePNGicon() exception caught? line[" + ex.line + "] "  + ex);
        this.menu.close(0); // there is no point in re-throwing the exception
    }
    return;
}


// -------------------------------------------------------
// LayerMenu.showDialog()
// display the UI dialog window
// -------------------------------------------------------
LayerMenu.prototype["showDialog"] = function(framePlacement) {
    var rc;

    if (this.winFrameLocation == null)
        this.winFrameLocation = framePlacement;
    this.createDialog();                   // create the window
    rc = this.menu.show();                  // show the dialog
    if (rc == 1)                           // OK
        this.rePop();                      // update user selected global options
    return(rc);
}

// =======================================================
// ColorMenu Dialog Routines
// Rags Gardner from a sample by Larry B. Ligon
// =======================================================

// -------------------------------------------------------
// ColorMenu constructor
// -------------------------------------------------------
ColorMenu = function(useIcon) {
    this.winFrameLocation = null;            // the window location
    this.selectedColor = undefined;          // the new color
    this.isIconValid = useIcon;              // shuld we use the PNG icon
    this.menuActive = false;                 // initialization switch
    this.cdlg = undefined;                   // the dialog menu window
    return;
}

// -------------------------------------------------------
// ColorMenu.createDialog()
// -------------------------------------------------------
ColorMenu.prototype["createDialog"] = function(defaultColor) {
    var sliderSize = 256;

    this.menuActive = false;
    //-------------------------------
    // Set the location of the dialog
    //-------------------------------
    this.cdlg = new Window("dialog", "Color Chooser");
    this.cdlg.frameLocation = this.winFrameLocation;
    this.cdlg.orientation = "column";
    this.cdlg.newColor = new SolidColor();
    this.cdlg.newColor.rgb = defaultColor.rgb;
    //--------------------------------------
    // Add the default OK and Cancel buttons
    //--------------------------------------
    this.cdlg.mainGroup = this.cdlg.add("group");
    this.cdlg.mainGroup.orientation = "row";
    this.cdlg.mainGroup.alignChildren = "fill";
    this.cdlg.mainGroup.spacing = 25;
    this.cdlg.okBtn = this.cdlg.mainGroup.add("button", undefined, "OK", {name:"ok"});
    this.cdlg.okBtn.helpTip = "Accept the new color";
    if (this.isIconValid) {                       // add the PNG image icon
        this.updatePNGicon(defaultColor);
        this.cdlg.imageIcon = this.cdlg.mainGroup.add("image", undefined, iconURL);
    }
    this.cdlg.cancelBtn = this.cdlg.mainGroup.add("button", undefined, "Cancel", {name:"cancel"});
    this.cdlg.cancelBtn.helpTip = "Dismiss the new color";
    //---------------------------
    // Add the color choser panel
    //---------------------------
    this.cdlg.colorPanel = this.cdlg.add("panel", undefined, "New Color");
    this.cdlg.colorPanel.orientation = "column";
    this.cdlg.colorPanel.alignChildren = "fill";
    this.cdlg.colorPanel.spacing = 10;
    //---------------------
    // Add the color groups
    //---------------------
    this.cdlg.redGroup = this.cdlg.colorPanel.add("group");
    this.cdlg.redGroup.orientation = "row";
    this.cdlg.redGroup.alignChildren = "fill";
    this.cdlg.redGroup.spacing = 15;
    this.cdlg.greenGroup = this.cdlg.colorPanel.add("group");
    this.cdlg.greenGroup.orientation = "row";
    this.cdlg.greenGroup.alignChildren = "fill";
    this.cdlg.greenGroup.spacing = 15;
    this.cdlg.blueGroup = this.cdlg.colorPanel.add("group");
    this.cdlg.blueGroup.orientation = "row";
    this.cdlg.blueGroup.alignChildren = "fill";
    this.cdlg.blueGroup.spacing = 15;
    //---------------------
    // Add the red controls
    //---------------------
    this.cdlg.redColorTxt = this.cdlg.redGroup.add("statictext", undefined, "Red");
    this.cdlg.redColorTxt.preferredSize = [40,20];
    this.cdlg.redSlider = this.cdlg.redGroup.add("scrollbar", undefined, defaultColor.rgb.red, 0, 255);
    this.cdlg.redSlider.preferredSize = [sliderSize,20];
    this.cdlg.redSlider.onChange = function() {colorMenu.tryUpdateMenu("Slider");};
    this.cdlg.redSlider.onChanging = function() {colorMenu.tryUpdateMenu("Changing");};
    this.cdlg.redSlider.helpTip = "Adjust the red cannnel value";
    this.cdlg.redValue = this.cdlg.redGroup.add("edittext");
    this.cdlg.redValue.preferredSize = [40,20];
    this.cdlg.redValue.onChange = function() {colorMenu.tryUpdateMenu("Value");};
    this.cdlg.redValue.text = Math.round(this.cdlg.redSlider.value);
    this.cdlg.redValue.helpTip = "Set the red cannnel value, 0 to 255";
    //-----------------------
    // Add the green controls
    //-----------------------
    this.cdlg.greenColorTxt = this.cdlg.greenGroup.add("statictext", undefined, "Green");
    this.cdlg.greenColorTxt.preferredSize = [40,20];
    this.cdlg.greenSlider = this.cdlg.greenGroup.add("scrollbar", undefined, defaultColor.rgb.green, 0, 255);
    this.cdlg.greenSlider.preferredSize = [sliderSize,20];
    this.cdlg.greenSlider.onChange = function() {colorMenu.tryUpdateMenu("Slider");};
    this.cdlg.greenSlider.onChanging = function() {colorMenu.tryUpdateMenu("Changing");};
    this.cdlg.greenSlider.helpTip = "Adjust the green cannnel value";
    this.cdlg.greenValue = this.cdlg.greenGroup.add("edittext");
    this.cdlg.greenValue.preferredSize = [40,20];
    this.cdlg.greenValue.onChange = function() {colorMenu.tryUpdateMenu("Value");};
    this.cdlg.greenValue.text = Math.round(this.cdlg.greenSlider.value);
    this.cdlg.greenValue.helpTip = "Set the green cannnel value, 0 to 255";
    //----------------------
    // Add the blue controls
    //----------------------
    this.cdlg.blueColorTxt = this.cdlg.blueGroup.add("statictext", undefined, "Blue");
    this.cdlg.blueColorTxt.preferredSize = [40,20];
    this.cdlg.blueSlider = this.cdlg.blueGroup.add("scrollbar", undefined, defaultColor.rgb.blue, 0, 255);
    this.cdlg.blueSlider.preferredSize = [sliderSize,20];
    this.cdlg.blueSlider.onChange = function() {colorMenu.tryUpdateMenu("Slider");};
    this.cdlg.blueSlider.onChanging = function() {colorMenu.tryUpdateMenu("Changing");};
    this.cdlg.blueSlider.helpTip = "Adjust the blue cannnel value";
    this.cdlg.blueValue = this.cdlg.blueGroup.add("edittext");
    this.cdlg.blueValue.preferredSize = [40,20];
    this.cdlg.blueValue.onChange = function() {colorMenu.tryUpdateMenu("Value");};
    this.cdlg.blueValue.text = Math.round(this.cdlg.blueSlider.value);
    this.cdlg.blueValue.helpTip = "Set the blue cannnel value, 0 to 255";
    //---------------------
    // Add the text message
    //---------------------
    if (! this.isIconValid) {
        this.cdlg.previewColorTxt = this.cdlg.add("statictext", undefined,
            " Preview selected color in Photoshop Foreground Color");
        app.foregroundColor = defaultColor;   // the starting color
    }
    this.cdlg.onMove = function() {colorMenu.tryUpdateMenu("Move");};
    this.cdlg.onShow = function() {colorMenu.tryUpdateMenu("Show");};
    return(this.cdlg);
}

// -------------------------------------------------------
// ColorMenu.tryUpdateMenu()
// -------------------------------------------------------
ColorMenu.prototype["tryUpdateMenu"] = function(caller) {
    var ex;

    try {
        if (this.menuActive || caller == "Move" || caller == "Show")
            this.updateMenu(caller);
    } catch(ex) {
        alert(scriptName + " ColorMenu.updateMenu(" + caller +
                           ") exception caught? line[" + ex.line + "]\n"  + ex);
        if (this.menuActive)
            this.menu.close(0); // there is no point in re-throwing the exception
    }
    return;
}

// -------------------------------------------------------
// ColorMenu.updateMenu()
// -------------------------------------------------------
ColorMenu.prototype["updateMenu"] = function(caller) {
    var testNum;

    switch(caller) {
        case "Move":
            this.winFrameLocation = this.cdlg.frameLocation;
            if (this.menuActive)
                waitForRedraw();
            break;
        case "Value":
            testNum = Number(this.cdlg.redValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 255) {
                alert("Red" + testNum + ", must be a number 0-255");
                this.cdlg.redValue.text = this.cdlg.newColor.rgb.red;
            }
            this.cdlg.redSlider.value = Number(this.cdlg.redValue.text);
            testNum = Number(this.cdlg.greenValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 255) {
                alert("Green=" + testNum + ", must be a number 0-255");
                this.cdlg.greenValue.text = this.cdlg.newColor.rgb.green;
            }
            this.cdlg.greenSlider.value = Number(this.cdlg.greenValue.text);
            testNum = Number(this.cdlg.blueValue.text);
            if (isNaN(testNum) || testNum < 0 || testNum > 255) {
                alert("Blue=" + testNum + ", must be a number 0-255");
                this.cdlg.blueValue.text = this.cdlg.newColor.rgb.blue;
            }
            this.cdlg.blueSlider.value = Number(this.cdlg.blueValue.text);
            break;
        case "Changing":
        case "Slider":
            this.cdlg.redValue.text = Math.round(this.cdlg.redSlider.value);
            this.cdlg.greenValue.text = Math.round(this.cdlg.greenSlider.value);
            this.cdlg.blueValue.text = Math.round(this.cdlg.blueSlider.value);
            break;
        case "Show":
            this.menuActive = true;
            break;
        default:
            alert("ColorMenu.updateMenu() Invalid caller=" + caller);
            break;
    }
    if (caller == "Value" || caller == "Slider") {
        this.cdlg.newColor.rgb.red = Math.round(this.cdlg.redValue.text);
        this.cdlg.newColor.rgb.green = Math.round(this.cdlg.greenValue.text);
        this.cdlg.newColor.rgb.blue =  Math.round(this.cdlg.blueValue.text);
        if (this.isIconValid) {
            this.updatePNGicon(this.cdlg.newColor);
            this.cdlg.active = true;                           // lost focus due to icon update?
            this.cdlg.imageIcon.icon = "Step1Icon";            // just to force an icon change
            this.cdlg.imageIcon.icon = iconURL;           // the updated PNG file
        } else {
            app.foregroundColor = this.cdlg.newColor;          // show change in FG color
        }
    }
    return;
}

// -------------------------------------------------------
// ColorMenu.updatePNGicon()
// -------------------------------------------------------
ColorMenu.prototype["updatePNGicon"] = function(color) {
    var ex;

    if (docRefIcon == null) {
        try {
            app.open(File(iconURL));
            docRefIcon = app.activeDocument;
            docRefIcon.activeLayer = docRefIcon.layers[docRefIcon.layers.length-1];
        } catch(ex) {
            alert("updatePNGicon() Failed to open icon: " + iconURL + "\n Line(" + ex.line + ") " + ex);
            return;
        }
    }
    try {
        app.activeDocument = docRefIcon;
        docRefIcon.selection.selectAll();
        docRefIcon.selection.fill(color);       // fill selection with solid color
        docRefIcon.selection.deselect();
        docRefIcon.save();                      // save changes for icon display update
    } catch(ex) {
        alert(scriptName + " ColorMenu.updatePNGicon() exception caught? line[" + ex.line + "] "  + ex);
        this.cdlg.close(0); // there is no point in re-throwing the exception
    }
    return;
}

// -------------------------------------------------------
// ColorMenu.showDialog()
// -------------------------------------------------------
ColorMenu.prototype["showDialog"] = function(color, framePlacement) {
    var fgSaveColor = app.foregroundColor;
    var rc;

    this.selectedColor = undefined;              // if dialog cancelled
    if (this.winFrameLocation == null)
        this.winFrameLocation = framePlacement;  // initial window position
    this.createDialog(color);                    // create the window
    rc = this.cdlg.show();                       // show it
    if (rc == 1)  // OK
        this.selectedColor = this.cdlg.newColor; // the new color
    else          // Cancel
        app.foregroundColor = fgSaveColor;       // restore
    if (docRefIcon != null) {
        docRefIcon.close(SaveOptions.DONOTSAVECHANGES);
        docRefIcon = null;
    }
    return(this.selectedColor);
}

// =======================================================
// ImgAnchor object functions
// =======================================================

// -----------------------------------------
// ImgAnchor() constructor
// -----------------------------------------
function ImgAnchor(pH, pV, sH, sV) {
    this.pH = Math.round(pH);  // anchor point horizontal
    this.pV = Math.round(pV);  // anchor point vertical
    this.sH = Math.round(sH);  // size horizontal
    this.sV = Math.round(sV);  // size vertical
    this.bH = 0;               // boundry size horizontal
    this.bV = 0;               // boundry size vertical
    return;
}

// -------------------------------------------
// ImgAnchor.FmtStr() format diagnostic string
// -------------------------------------------
ImgAnchor.prototype["FmtStr"] = function() {
    var msgStr = "";

    if (this.pH != 0 || this.pV != 0)
        msgStr += "AnchorHV[" + px2in(this.pH) + ", " + px2in(this.pV) + "], ";
    msgStr += "SizeHV[" + px2in(this.sH) + ", " +  px2in(this.sV)  + "]";
    if (this.bH != 0 || this.bV != 0)
        msgStr += ", EdgeHV[" + px2in(this.bH) + ", " + px2in(this.bV) + "]";
    return(msgStr);
}

// =======================================================
// Static Functions
// =======================================================

// -----------------------------------------
// makeSelection()
// trim to canvas border to handle image
// edge rounding when canvas edge = 0%
// pointTL = (horizontal, vertical)
// -----------------------------------------
function makeSelection(docRef, pointTL, width, height) {
    var selRegion;
    var pointTR, pointBR, pointBL;

    if (pointTL[0] < 0) pointTL[0] = 0;
    if (pointTL[1] < 0) pointTL[1] = 0;
    pointTR = new Array(pointTL[0] + width, pointTL[1]);
    pointBR = new Array(pointTR[0], pointTL[1] + height);
    pointBL = new Array(pointTL[0], pointBR[1]);
    if (pointBR[0] > docCanvas.sH) pointBR[0] = docCanvas.sH;
    if (pointBR[1] > docCanvas.sV) pointBR[1] = docCanvas.sV;
    selRegion = new Array(pointTL, pointTR, pointBR, pointBL, pointTL);
    if (1 == 0 && (pointTL[0] < 0 || pointTL[1] < 0 || pointBR[0] > docCanvas.sH || pointBR[1] > docCanvas.sV))
        alert("makeSelection() Exceeds canvas size\nTL[" +
              Math.round(pointTL[0]) +  ", " + Math.round(pointTL[1]) + "], BR[" +
              Math.round(pointBR[0]) +  ", " + Math.round(pointBR[1]) + "]\nCanvas[" +
              docCanvas.sH +  ", " + docCanvas.sV + "]");
    docRef.selection.select(selRegion);
    return;
}

// -----------------------------------------
// mergeVisible()
// -----------------------------------------
function mergeVisible() {
    executeAction(charIDToTypeID("MrgV"), undefined, DialogModes.NO);
    return;
}

// -----------------------------------------
// showLayerStyles()
// -----------------------------------------
function showLayerStyles(tfSwitch) {
    var refr1 = new ActionReference();
    var desc1 = new ActionDescriptor();
    var desc2 = new ActionDescriptor();

    refr1.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("lfxv"));
    refr1.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    desc1.putReference(charIDToTypeID("null"), refr1);
    desc2.putBoolean(charIDToTypeID("lfxv"), tfSwitch);
    desc1.putObject(charIDToTypeID("T   "), charIDToTypeID("lfxv"), desc2);
    executeAction(charIDToTypeID("setd"), desc1, DialogModes.NO);
    return;
}

// -----------------------------------------
// applyLayerStyle()
// -----------------------------------------
function applyLayerStyle(newStyle) {
    var thisStyle = "";

    if (styleInvalid)
        return;
    try {
        thisStyle = newStyle;  // default name for exception alerts
        switch(newStyle) {
            case "DoubleRing":
                thisStyle = "Double Ring Glow (Button)";
                docRefBase.activeLayer.applyStyle(thisStyle);
                break;
            case "CollageStyle1":
            case "CollageStyle2":
            case "CollageStyle3":
            case "CollageStyle4":
                docRefBase.activeLayer.applyStyle(thisStyle);
                break;
            case "none":
            default:
                alert{"applyLayerStyle() invalid style=" + newStyle};
                break;
        }
    } catch(e) {
        alert("applyLayerStyle() " + thisStyle + " is not available!");
        styleInvalid = true;   // layer style not found
    }
    //------------------------------------------------
    // scaled named styles to current small image size
    //------------------------------------------------
    if (styleScalePct != 100.0 && !styleInvalid)
        scaleLayerEffects(styleScalePct);
    return;
}

// -----------------------------------------
// scaleLayerEffects() 0-1000%
// -----------------------------------------
function scaleLayerEffects(scale) {
    var desc = new ActionDescriptor();

    try {
        desc.putUnitDouble(charIDToTypeID("Scl "), charIDToTypeID("#Prc"), scale);
        executeAction(stringIDToTypeID("scaleEffectsEvent"), desc, DialogModes.NO);
        waitForRedraw();
    } catch(e) {
        alert(scriptName + " scaleLayerEffects(" + scale + "%) exception caught? line[" + e.line + "] "  + e);
    }
    return;
}

// -----------------------------------------
// addText()
// -----------------------------------------
function addText(textStr, textSize, textPosH, textPosV) {
    var textPos;

    textPos = new Array(textPosH, textPosV);                              // text position
    makeTextLayer(textPos, textSize, textColor, textStr, "center");       // build the text layer
    strokeText(textSize/8, textStrokeColor);                              // add an outline stroke
    docRefBase.activeLayer.merge();                                       // merge the text layer
    return;
}

// =========================================================
// makeTextLayer()
// Note: if the font name is invalid, PS defaults to Myriad?
// =========================================================
function makeTextLayer(textPos, textSize, textColor, textStr, lmr) {
    var newTxtLayer;
    var textFontName = "ArialMT";  // PS needs the Postscript Nmme ???
    var justify;

    switch(lmr) {
        case "center":  justify = Justification.CENTER; break;
        case "right":   justify = Justification.RIGHT; break;
        case "left":
        default:        justify = Justification.LEFT; break;
    }
    //-----------------------------
    // for font selection debugging
    //-----------------------------
    if (1 == 0) {
       var i = 0;
       var fontListStr = "";
       for (i=0; i<app.fonts.length; i++) {
          fontListStr = fontListStr + "(" + i + ")" + app.fonts[i].postScriptName;
          if (i > 0 && i%4 == 0) fontListStr = fontListStr + "\n";
          else fontListStr = fontListStr + ",  ";
       }
       alert("Font List:\n" + fontListStr);
    }
    //------------------------
    // create a new text layer
    //------------------------
    newTxtLayer = docRefBase.artLayers.add();
    newTxtLayer.kind = LayerKind.TEXT;
    newTxtLayer.textItem.justification = justify;
    newTxtLayer.textItem.size = textSize;
    newTxtLayer.textItem.position = textPos;
    newTxtLayer.textItem.contents = textStr;
    newTxtLayer.textItem.color = textColor;
    newTxtLayer.textItem.font = textFontName;
    return;
}

// ======================================
// function strokeText()
// add a stroke outline to a text layer
// ======================================
function strokeText(outlineSize, strokeColor) {
    var prc = 0.0; // 416.666667 ???
    var refr01 = new ActionReference();
    var desc01 = new ActionDescriptor();
    var desc02 = new ActionDescriptor();
    var desc03 = new ActionDescriptor();
    var desc04 = new ActionDescriptor();

    refr01.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("Lefx"));
    refr01.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    desc01.putReference(charIDToTypeID("null"), refr01);
    desc02.putUnitDouble(charIDToTypeID("Scl "), charIDToTypeID("#Prc"), prc);
    desc03.putBoolean(charIDToTypeID("enab"), true);
    desc03.putEnumerated(charIDToTypeID("Styl"), charIDToTypeID("FStl"), charIDToTypeID("OutF"));
    desc03.putEnumerated(charIDToTypeID("PntT"), charIDToTypeID("FrFl"), charIDToTypeID("SClr"));
    desc03.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));
    desc03.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("BlnM"), 100.0);
    desc03.putUnitDouble(charIDToTypeID("Sz  "), charIDToTypeID("#Pxl"), outlineSize);
    desc04.putDouble(charIDToTypeID("Rd  "), strokeColor.rgb.red);
    desc04.putDouble(charIDToTypeID("Grn "), strokeColor.rgb.green);
    desc04.putDouble(charIDToTypeID("Bl  "), strokeColor.rgb.blue);
    desc03.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), desc04);
    desc02.putObject(charIDToTypeID("FrFX"), charIDToTypeID("FrFX"), desc03);
    desc01.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), desc02);
    executeAction(charIDToTypeID("setd"), desc01, DialogModes.NO);
   return;
}

// -------------------------------------------------------
// previewTemplate()
// -------------------------------------------------------
function previewTemplate() {
    var startTime;
    var previewTime;
    var imageCount;
    var selRegion;
    var anchorTL;
    var previewMsg;
    var alertB4 = true;
    var useFrameEffects = false;
    var docName;
    var i;

    startTime = new Date();
    initializeTemplate();
    if (strokeEffect || overlayEffect || dropShadowEffect || embossEffect|| glowEffect)
        useFrameEffects = true;
    //--------------------------------
    // build the preview alert message
    //--------------------------------
    previewMsg  = "previewTemplate(H,V) Image Scale(" + Math.round(imageScale*1000)/1000 + ")";
    previewMsg += "\nAlign=" + mainImageAlign + ", rows(" + smallImageRows + "), Cols(" + smallImageCols + ")";
    previewMsg += "\nCanvas: " + docCanvas.FmtStr();
    previewMsg += "\nImage Area: " + imgArea.FmtStr();
    if (mainImage.sV != 0 || mainImage.sH != 0)
        previewMsg += "\nMain Image: " + mainImage.FmtStr();
    previewMsg += "\nSmall Image: " + smallImage.FmtStr();
    if (previewAlert && alertB4)
        alert(previewMsg);
    if (isNaN(docCanvas.sH) || isNaN(docCanvas.sV) || docCanvas.sH < 768 || docCanvas.sV < 768 ||
        isNaN(imgArea.sH) || isNaN(imgArea.sV) || imgArea.sH < 16 || imgArea.sV < 16 ||
        isNaN(mainImage.sH) || isNaN(mainImage.sV) || mainImage.sH < 0 || mainImage.sV < 0 ||
        isNaN(smallImage.sH) || isNaN(smallImage.sV) || smallImage.sH < 16 || smallImage.sV < 16)
        throw(previewMsg + "\n\nException:    Invalid canvas!!!");
    //----------------------------------
    // build the collage document canvas
    //----------------------------------
    app.backgroundColor = bgColor;
    docName = "previewTemplate(" + smallImageRows + "x" + smallImageCols + ")" + mainImageAlign;
    app.documents.add(docCanvas.sH, docCanvas.sV, canvasPPI, docName,
                      NewDocumentMode.RGB, DocumentFill.BACKGROUNDCOLOR);
    docRefBase = app.activeDocument;
    newGuide(true, 50);
    newGuide(false, 50);
    if (docCanvas.bH != 0 || docCanvas.bV != 0) {
        makeSelection(docRefBase, new Array(imgArea.pH, imgArea.pV), imgArea.sH, imgArea.sV);
        docRefBase.selection.stroke(canvasEdgeColor, imageEdgeSize, StrokeLocation.OUTSIDE);
    }
    //-----------------------------
    // build the main image preview
    //-----------------------------
    if (mainImageAlign != "none" && !mainIsBg) {
        mainAnchor = getMainAnchor();
        makeSelection(docRefBase, mainAnchor, mainImage.sH, mainImage.sV);  // new selection
        if (frameStyles != "none" || useFrameEffects) {
            docRefBase.artLayers.add();               // add an empty layer
            docRefBase.selection.fill(mainColor);     // fill selection with solid color
            if (frameStyles != "none")
                applyLayerStyle(frameStyles);         // apply a layer style
            else
                newLayerEffects();                    // apply a layer effect
            docRefBase.activeLayer.merge();           // eliminate the current layer
        } else {
            docRefBase.selection.fill(mainColor);     // fill selection with solid color
        }
        //-----------------------------
        // stroke the main image border
        //-----------------------------
        if (mainImage.bH != 0 || mainImage.bV != 0) {
            makeSelection(docRefBase,
                          new Array(mainAnchor[0]-(mainImage.bH/2), mainAnchor[1]-(mainImage.bV/2)),
                          mainImage.sH+(mainImage.bH), mainImage.sV+(mainImage.bV));
            docRefBase.selection.stroke(imageEdgeColor, imageEdgeSize, StrokeLocation.INSIDE);
        }
    }
    waitForRedraw();
    //-------------------------------
    // build the small image previews
    //-------------------------------
    smallAnchors = getSmallAnchors();
    for (i=0; i<smallAnchors.length; i++) {
        makeSelection(docRefBase, smallAnchors[i], smallImage.sH, smallImage.sV);  // new selection
        if (frameStyles != "none" || useFrameEffects) {
            docRefBase.artLayers.add();               // add an empty layer
            docRefBase.selection.fill(smallColor);    // fill selection with solid color
            if (frameStyles != "none")
                applyLayerStyle(frameStyles);         // apply a layer style
            else
                newLayerEffects();                    // apply a layer effect
            docRefBase.activeLayer.merge();           // eliminate the current layer
        } else {
            docRefBase.selection.fill(smallColor);    // fill selection with solid color
        }
        //------------------------------
        // stroke the small image border
        //------------------------------
        if (smallImage.bH != 0 || smallImage.bV != 0) {
            makeSelection(docRefBase,
                          new Array(smallAnchors[i][0]-(smallImage.bH/2), smallAnchors[i][1]-(smallImage.bV/2)),
                          smallImage.sH+(smallImage.bH), smallImage.sV+(smallImage.bV));
            docRefBase.selection.stroke(imageEdgeColor, imageEdgeSize, StrokeLocation.INSIDE);
        }
        waitForRedraw();
    }
    //-----------------------------
    // display the preview document
    //-----------------------------
    docRefBase.selection.deselect();
    imageCount = smallAnchors.length;
    if (mainImageAlign != "none") imageCount++;
    previewTime = "Image Count(" + imageCount +  "), Preview Time: " + getElapsedTime(startTime);
    previewMsg += "\n" + previewTime;
    if (previewAlert && ! alertB4)
        alert(previewMsg);
    return(previewTime);
}

// -------------------------------------------------------
// buildTemplate()
// -------------------------------------------------------
function buildTemplate() {
    var startTime;
    var createTime;
    var imageCount;
    var useFrameEffects = false;
    var selRegion;
    var anchorTL;
    var i;

    startTime = new Date();
    if (strokeEffect || overlayEffect || dropShadowEffect || embossEffect || glowEffect)
        useFrameEffects = true;
    initializeTemplate();
    //----------------------------------
    // build the collage document canvas
    //----------------------------------
    app.backgroundColor = bgColor;
    app.documents.add(docCanvas.sH, docCanvas.sV, canvasPPI, newDocName,
                      NewDocumentMode.RGB, DocumentFill.BACKGROUNDCOLOR);
    docRefBase = app.activeDocument;
    if (frameStyles != "none")
        docRefBase.info.caption = frameStyles;
    if (canvasBitDepth == 16)
        docRefBase.bitsPerChannel = BitsPerChannelType.SIXTEEN;
    else
        docRefBase.bitsPerChannel = BitsPerChannelType.EIGHT;
    //-----------------------------
    // build the main image layer
    //-----------------------------
    if (mainIsBg) {
        docRefBase.activeLayer.name = "MainImage1";               // name it
        mainAnchor = getMainAnchor();
        if (mainImageAlign != "none")
             addText("MainImage1", mainImage.sH/36, mainImage.pH + (mainImage.sH/2), mainImage.pV + (mainImage.sV/2));
        if (mainImageAlign == "none" )				      
             addText("MainImage1", docCanvas.sH/36, docCanvas.sH/2, docCanvas.sV/2); // JJMack mod
    } else {
        if (mainImageAlign != "none") {
            mainAnchor = getMainAnchor();
            docRefBase.selection.selectAll();                         // select canvas
            docRefBase.selection.copy();                              // to clipboard
            docRefBase.paste();                                       // create a new layer
            docRefBase.selection.selectAll();                         // select new layer
            docRefBase.selection.clear();                             // erase all pixels
            makeSelection(docRefBase, mainAnchor, mainImage.sH, mainImage.sV);  // new selection
            docRefBase.selection.fill(mainColor);                     // fill with solid color
            docRefBase.activeLayer.name = "MainImage1";               // name it
            if (frameStyles != "none") {
                applyLayerStyle(frameStyles);                         // apply a layer style
            } else if (useFrameEffects) {
                newLayerEffects();                                    // apply a layer effect
            }
            addText("MainImage1", mainImage.sH/36, mainImage.pH + (mainImage.sH/2), mainImage.pV + (mainImage.sV/2));
        }
    }
    //-----------------------------
    // build the small image layers
    //-----------------------------
    smallAnchors = getSmallAnchors();
    for (i=0; i<smallAnchors.length; i++) {
        docRefBase.selection.selectAll();                                // select canvas
        docRefBase.selection.copy();                                     // to clipboard
        docRefBase.paste();                                              // create a new layer
        docRefBase.selection.selectAll();                                // select new layer
        docRefBase.selection.clear();                                    // erase all pixels
        makeSelection(docRefBase, smallAnchors[i], smallImage.sH, smallImage.sV);  // new selection
        docRefBase.selection.fill(smallColor);                           // fill with solid color
        docRefBase.activeLayer.name = "smImage" + (i+1);                 // name it
        if (frameStyles != "none") {
            applyLayerStyle(frameStyles);                                // apply a layer style
        } else if (useFrameEffects) {
            newLayerEffects();                                           // apply a layer effect
        }
        //---------------------
        // add descriptive text
        //---------------------
        addText("smImage" + (i+1), smallImage.sH/36,
                 smallAnchors[i][0] + (smallImage.sH/2),
                 smallAnchors[i][1] + (smallImage.sV/2));
    }
    //------------------------------
    // display the template document
    //------------------------------
    docRefBase.selection.deselect();
    showLayerStyles(true); // display layer effects
    imageCount = smallAnchors.length;
    if (mainImageAlign != "none") imageCount++;

    if (imageCount <= 53) {
       if (!protoType) {
          // JJMack Mods Create Alpha Channels for Layers named Image 1 through Image n
          // Then Flatten Image 
          var layers = activeDocument.layers;
          if (!mainIsBg ) activeDocument.activeLayer = layers[layers.length-1] // Target Bottom Layer; 
          for (i=1; i<imageCount +1; i++) {		// Create Image n Alpha Channels
             layerForward();
             selectTranparency(); 
             saveAlpha("Image " + i);
             }
          activeDocument.selection.deselect();		// Deselect
          activeDocument.flatten()			// Flatten Template
          if (!mainIsBg ) { 				// If Background not compleatly Covered
             makeLayer("Mat");				// Add Layer for mat
             fillColor();				// Fill with light gray
             addTexture();				// add texture
             addStyle("Mat");				// add Mat Layer Style
             selectChannelTrans("Image 1");		// Select Image locations
             for (i=2; i<imageCount +1; i++) addChannelTrans("Image " + i);
                activeDocument.selection.clear();	// cut Mat for images
                activeDocument.selection.deselect();	// deselect
                addClipHueAdj();				// add a clipped hue and saturation adjustment layer
                targetCont("Mat");			// Target layers continiously to Mat Layer
                makeGroup("Mat");			// Make Mat Layer Group
                hideGroup();				// Hide Group
                }
          }
          SetViewFitonScreen()
       } else alert(imageCount + " images exceed the maximum allowed limit of 53"); 
       // End Mods JJMack
    createTime = "Image Count(" + imageCount +  "), Build Time: " + getElapsedTime(startTime);
    return(createTime);
}

// -------------------------------------------------------
// initializeTemplate()
// -------------------------------------------------------
function initializeTemplate() {
    var mainImageVpix;                           // main image size (pixels)
    var mainImageHpix;                           // main image size (pixels)
    var tempStroke;

    app.preferences.rulerUnits = Units.PIXELS;
    //-----------------------------
    // convert menu sizes to pixels
    //-----------------------------
    docCanvas = new ImgAnchor(0, 0, in2px(canvasSizeH), in2px(canvasSizeV));
    docCanvas.bH = Math.round(docCanvas.sH * canvasEdgePct * 0.01);
    docCanvas.bV = Math.round(docCanvas.sV * canvasEdgePct * 0.01);
    imgArea = new ImgAnchor(docCanvas.bH, docCanvas.bV, docCanvas.sH-(2*docCanvas.bH),
                            docCanvas.sV-(2*docCanvas.bV));
    if(mainImageAlign == "none") {
        mainImageHpix = 0;
        mainImageVpix = 0;
    } else {
        mainImageHpix = in2px(mainImageH);
        mainImageVpix = in2px(mainImageV);
    }
    mainImage = new ImgAnchor(0, 0, mainImageHpix, mainImageVpix);
    mainImage.bH = Math.round(mainEdgePct * 0.01 * mainImage.sH);
    mainImage.bV = Math.round(mainEdgePct * 0.01 * mainImage.sV);
    smallImage = new ImgAnchor(0, 0, in2px(smallImageH), in2px(smallImageV));
    smallImage.bH = Math.round(smallEdgePct * 0.01 * smallImage.sH);
    smallImage.bV = Math.round(smallEdgePct * 0.01 * smallImage.sV);
    //--------------------------------------------------
    // scale canvas or images and calculate edge spacing
    //--------------------------------------------------
    if (canvasScale)
        calculateCanvas();
    else
        calculateImages();
    //----------------------------------------------
    // calculate a reasonable image edge stroke size
    //----------------------------------------------
    tempStroke = Math.min(docCanvas.sV, docCanvas.sH) / 480;
    imageEdgeSize = Math.min(20, Math.max(3, Math.round(tempStroke)));
    //-----------------------
    // select the text colors
    //-----------------------
    textColor = newRGBColor(0, 0, 0);                     // black
    textStrokeColor = newRGBColor(255, 255, 255);         // white
    return;
}

// -----------------------------------------
// calculateCanvas()
// -----------------------------------------
function calculateCanvas() {
    var vCanvasH, vCanvasV;
    var CH, CV, EH, EV;

    imageScale = 1;
    //----------------------------
    // precompute a virtual layout
    //----------------------------
    vCanvasH  = smallImageCols * (smallImage.sH + smallImage.bH);
    vCanvasV  = smallImageRows * (smallImage.sV + smallImage.bV);
    switch(mainImageAlign) {
        case "left":
        case "right":
        case "hcenter":
            vCanvasH += mainImage.sH + mainImage.bH;
            break;
        case "top":
        case "bottom":
        case "vcenter":
            vCanvasV += mainImage.sV + mainImage.bV;
            break;
        case "middle":
            vCanvasH += mainImage.sH + mainImage.bH;
            vCanvasV += mainImage.sV + mainImage.bV;
            break;
        default:
            break;
    }
    if (mainImage.sH + mainImage.bH > vCanvasH)
        vCanvasH = mainImage.sH + mainImage.bH;
    if (mainImage.sV + mainImage.bV > vCanvasV)
        vCanvasV = mainImage.sV + mainImage.bV;
    //---------------------------
    // calculate new canvas edges
    //    C = V / (1 - (P * 2))
    //---------------------------
    CH = vCanvasH / (1 - (2 * canvasEdgePct * 0.01));
    CV = vCanvasV / (1 - (2 * canvasEdgePct * 0.01));
    EH = CH * (canvasEdgePct * 0.01);
    EV = CV * (canvasEdgePct * 0.01);
    docCanvas = new ImgAnchor(0, 0, vCanvasH + (EH*2), vCanvasV +  + (EV*2));
    docCanvas.bH = EH;
    docCanvas.bV = EV;
    imgArea = new ImgAnchor(docCanvas.bH, docCanvas.bV, vCanvasH, vCanvasV);
    //-------------------------------------
    // recompute small image edges based on
    // new image area size and rows/cols
    //-------------------------------------
    calculateSmallEdges();
    //--------------------------------------
    // save this canvas as new menu defaults
    //--------------------------------------
    canvasSizeH = px2in(docCanvas.sH);
    canvasSizeV = px2in(docCanvas.sV);
    return;
}

// -----------------------------------------
// calculateImages()
// -----------------------------------------
function calculateImages() {
    var vCanvasH, vCanvasV;
    var scalev, scaleh;

    //--------------------------------------
    // precompute a virtual imageArea layout
    //--------------------------------------
    vCanvasH = smallImageCols * (smallImage.sH + smallImage.bH);
    vCanvasV = smallImageRows * (smallImage.sV + smallImage.bV);
    switch(mainImageAlign) {
        case "left":
        case "right":
        case "hcenter":
            vCanvasH += mainImage.sH + mainImage.bH;
            if (mainImage.sV + mainImage.bV > vCanvasV)
                vCanvasV = mainImage.sV + mainImage.bV;
            break;
        case "top":
        case "bottom":
        case "vcenter":
            vCanvasV += mainImage.sV + mainImage.bV;
            if (mainImage.sH + mainImage.bH > vCanvasH)
                vCanvasH = mainImage.sH + mainImage.bH;
            break;
        case "middle":
            vCanvasH += mainImage.sH + mainImage.bH;
            vCanvasV += mainImage.sV + mainImage.bV;
            break;
        case "none":
        default:
            break;
    }
    //------------------------------
    // scale images if > canvas size
    //------------------------------
    imageScale = 1;
    if (vCanvasH > imgArea.sH || vCanvasV > imgArea.sV) {
        scaleh = imgArea.sH / vCanvasH;
        scalev = imgArea.sV / vCanvasV;
        if (scaleh < scalev) imageScale = scaleh;
        else                 imageScale = scalev;
        mainImage.sH *= imageScale;
        mainImage.sV *= imageScale;
        mainImage.bH *= imageScale;
        mainImage.bV *= imageScale;
        smallImage.sH *= imageScale;
        smallImage.sV *= imageScale;
    }
    //-------------------------
    // round to a pixel boundry
    //-------------------------
    mainImage.sH = Math.round(mainImage.sH);
    mainImage.sV = Math.round(mainImage.sV);
    mainImage.bH = Math.round(mainImage.bH);
    mainImage.bV = Math.round(mainImage.bV);
    smallImage.sH = Math.round(smallImage.sH);
    smallImage.sV = Math.round(smallImage.sV);
    //-------------------------------------
    // recompute small image edges based on
    // new image area size and rows/cols
    //-------------------------------------
    calculateSmallEdges();
    //--------------------------------------------
    // save these image sizes as new menu defaults
    //--------------------------------------------
    mainImageH = px2in(mainImage.sH);
    mainImageV = px2in(mainImage.sV);
    smallImageH = px2in(smallImage.sH);
    smallImageV = px2in(smallImage.sV);
    return;
}

// -----------------------------------------
// calculateSmallEdges()
// -----------------------------------------
function calculateSmallEdges() {

    //-------------------------------------
    // recompute small image edges based on
    // new image area size and rows/cols
    //-------------------------------------
    smallImage.bH = imgArea.sH - (smallImage.sH * smallImageCols);
    smallImage.bV = imgArea.sV - (smallImage.sV * smallImageRows);
    switch(mainImageAlign) {
        case "left":
        case "right":
        case "hcenter":
            smallImage.bH -= mainImage.sH + mainImage.bH;
        case "none":
            smallImage.bH /= smallImageCols;
            smallImage.bV /= smallImageRows;
            break;
        case "top":
        case "bottom":
        case "vcenter":
            smallImage.bH /= smallImageCols;
            smallImage.bV -= mainImage.sV + mainImage.bV;
            smallImage.bV /= smallImageRows;
            break;
        case "middle":
            smallImage.bH -= mainImage.sH + mainImage.bH;
            smallImage.bH /= smallImageCols;
            smallImage.bV -= mainImage.sV + mainImage.bV;
            smallImage.bV /= smallImageRows;
            break;
        default:
            throw("calculateSmallEdges() Invalid alignment[" + mainImageAlign + "]");
            break;
    }
    smallImage.bH = Math.round(smallImage.bH);
    smallImage.bV = Math.round(smallImage.bV);
    return;
}

// -----------------------------------------
// getMainAnchor()
// anchor = (horizontal, vertical)
// -----------------------------------------
function getMainAnchor() {
    var anchorTL;
    var vBorder, hBorder;

    switch(mainImageAlign) {
        case "left":
            vBorder = (docCanvas.sV - mainImage.sV) / 2;
            hBorder = imgArea.pH + (mainImage.bH/2);
            break;
        case "right":
            vBorder = (docCanvas.sV - mainImage.sV) / 2;
            hBorder = docCanvas.sH - docCanvas.bH - mainImage.sH - (mainImage.bH/2);
            break;
        case "top":
            vBorder = docCanvas.bV + (mainImage.bV/2);
            hBorder = (docCanvas.sH - mainImage.sH) / 2;
            break;
        case "bottom":
            vBorder = docCanvas.sV - docCanvas.bV - mainImage.sV - (mainImage.bV/2);
            hBorder = (docCanvas.sH - mainImage.sH) / 2;
            break;
        case "hcenter":
        case "vcenter":
            vBorder = (docCanvas.sV - mainImage.sV) / 2;
            hBorder = (docCanvas.sH - mainImage.sH) / 2;
            break;
        case "middle":
            vBorder = (docCanvas.sV - mainImage.sV) / 2;
            hBorder = (docCanvas.sH - mainImage.sH) / 2;
            break;
        default:
            //throw("getMainAnchor() Invalid alignment[" + mainImageAlign + "]");		// JJMack
            if (!mainIsBg ) throw("getMainAnchor() Invalid alignment[" + mainImageAlign + "]");	// JJMack
            break;
    }
    anchorTL = new Array(hBorder, vBorder);
    mainImage.pH = hBorder;
    mainImage.pV = vBorder;
    return(anchorTL);
}

// -----------------------------------------
// getSmallAnchors()
// anchor = (horizontal, vertical)
// -----------------------------------------
function getSmallAnchors() {
    var anchorTL;
    var midAnchors;
    var hBorder, vBorder;
    var hFirstRow, vFirstCol;
    var i, j, k, c;
    var smAnchors = new Array();

    //---------------------------
    // set anchor for first image
    //---------------------------
    switch(mainImageAlign) {
        case "none":
        case "bottom":
        case "right":
        case "hcenter":
        case "vcenter":
        case "middle":
            hBorder = docCanvas.bH + (smallImage.bH/2);
            vBorder = docCanvas.bV + (smallImage.bV/2);
            break;
        case "left":
            hBorder = docCanvas.bH + mainImage.sH + mainImage.bH + (smallImage.bH/2);
            vBorder = docCanvas.bV + (smallImage.bV/2);
            break;
        case "top":
            hBorder = docCanvas.bH + (smallImage.bH/2);
            vBorder = docCanvas.bV + mainImage.sV + mainImage.bV + (smallImage.bV/2);
            break;
        default:
            throw("getSmallAnchors() Invalid alignment[" + mainImageAlign + "]");
            break;
    }
    vFirstRow = vBorder;
    hFirstCol = hBorder;
    //---------------------------
    // build the rest
    //---------------------------
    for (i=0; i<smallImageRows; i++) {       // each row
        hBorder = hFirstCol;                 // first column
        for (j=0; j<smallImageCols; j++) {   // each column
            anchorTL = new Array(hBorder, vBorder);
            smAnchors[smAnchors.length] = anchorTL;
            hBorder += smallImage.sH + smallImage.bH;
            if ((mainImageAlign == "hcenter") && (j+1 == smallImageCols/2))  // at hcenter col?
                hBorder += mainImage.sH + mainImage.bH;
            if ((mainImageAlign == "middle") && (j+1 == smallImageCols/2)) { // at middle col?
                midAnchors = insertMiddleImage(true, hBorder, vBorder);
                for (k=0; k<midAnchors.length; k++)
                    smAnchors[smAnchors.length] = midAnchors[k];
                hBorder += mainImage.sH + mainImage.bH;
            }
        }
        vBorder += smallImage.sV + smallImage.bV;
        if ((mainImageAlign == "vcenter") && (i+1 == smallImageRows/2))      // at vcenter row?
            vBorder += mainImage.sV + mainImage.bV;
        if ((mainImageAlign == "middle") && (i+1 == smallImageRows/2)) {     // at middle row?
            midAnchors = insertMiddleImage(false, hFirstCol, vBorder);
            for (k=0; k<midAnchors.length; k++)
                smAnchors[smAnchors.length] = midAnchors[k];
            vBorder += mainImage.sV + mainImage.bV;
        }
    }
    return(smAnchors);
}

// -------------------------------------------------------
// insertMiddleImage()
// -------------------------------------------------------
function insertMiddleImage(rowFlg, hThisCol, vThisRow) {
    var anchorTL;
    var hBorder, vBorder;
    var midAnchors = new Array();
    var rows, cols, i, j;
    var iRows, iCols;

    hBorder = hThisCol;
    vBorder = vThisRow;
    rows = smallImageRows/2;
    cols = smallImageCols/2;
    if (rowFlg) {   // add small images at the center of the row, above and below the main image
        iRows = parseInt((mainImage.sH + mainImage.bH) / (smallImage.sH + smallImage.bH));
        hBorder  = docCanvas.sH / 2;
        hBorder -= (iRows * smallImage.sH / 2) + ((iRows-1) * (smallImage.bH/2));
        for (i=0; i<iRows; i++) {       // add rows above or below main image
            anchorTL = new Array(Math.round(hBorder), Math.round(vBorder));
            midAnchors[midAnchors.length] = anchorTL;
            hBorder += smallImage.sH + smallImage.bH;
        }
    } else {       // add small images at the left and right of the main image
        iCols = parseInt((mainImage.sV + mainImage.bV) / (smallImage.sV + smallImage.bV));
        vBorder  = docCanvas.sV / 2;
        vBorder -= (iCols * smallImage.sV / 2) + ((iCols-1) * (smallImage.bV/2));
        for (i=0; i<iCols; i++) {       // add cols surrounding main image
            hBorder = docCanvas.bH + (smallImage.bH/2);
            for (j=0; j<rows; j++) {    // add rows to left of main image
                anchorTL = new Array(Math.round(hBorder), Math.round(vBorder));
                midAnchors[midAnchors.length] = anchorTL;
                hBorder += smallImage.sH + smallImage.bH;
            }
            hBorder  = docCanvas.sH - docCanvas.bH;
            hBorder -= (rows * smallImage.sH) + ((rows-1) * smallImage.bH) + (smallImage.bH/2);
            for (j=0; j<rows; j++) {    // add rows to right of main image
                anchorTL = new Array(Math.round(hBorder), Math.round(vBorder));
                midAnchors[midAnchors.length] = anchorTL;
                hBorder += smallImage.sH + smallImage.bH;
            }
            vBorder += smallImage.sV + (smallImage.bV*2); 
        }
    }
    return(midAnchors);
}

//---------------------------------------------------------------
// newLayerEffects()
// creates multiple effects in a Layer Style
//---------------------------------------------------------------
function newLayerEffects() {
    var effectsArray = new Array();
    var refr01 = new ActionReference();
    var layerProperties = new ActionDescriptor();
    var layerOptions = new ActionDescriptor();
    var layerScale = 400.0;
    var useGlobalLight = false;
    var globalLightDesc = null;
    var layerEffects;
    var i;

    //----------------------------
    // Which custom layer effects?
    //----------------------------
    if (strokeEffect)
        effectsArray[effectsArray.length] = "Stroke";
    if (overlayEffect)
        effectsArray[effectsArray.length] = "ColorOverlay";
    if (dropShadowEffect)
        effectsArray[effectsArray.length] = "DropShadow";
    if (embossEffect)
        effectsArray[effectsArray.length] = "Emboss";
    if (glowEffect)
        effectsArray[effectsArray.length] = "Glow";
    if (effectsArray.length < 1)
        return;  // none
    //--------------
    // layer scaling
    //--------------
    layerOptions.putUnitDouble(charIDToTypeID("Scl "), charIDToTypeID("#Prc"), layerScale);
    if (useGlobalLight)
        globalLightDesc = layerOptions;
    //--------------
    // layer effects
    //--------------
    for (i=0; i<effectsArray.length; i++) {
        switch(effectsArray[i]) {
            case "Stroke":
                layerEffects = newStrokeEffect(strokeSize, strokeColor, strokePosition);
                layerOptions.putObject(charIDToTypeID("FrFX"), charIDToTypeID("FrFX"), layerEffects);
                break;
            case "ColorOverlay":
                layerEffects = newColorOverlayEffect(overlayOpacity, overlayColor);
                layerOptions.putObject(charIDToTypeID("SoFi"), charIDToTypeID("SoFi"), layerEffects);
                break;
            case "Emboss":
                layerEffects = newBevelEmbossEffect(globalLightDesc, embossDepth, embossSize, embossSoften,
                                                    shadingAngle, shadingAltitude);
                layerOptions.putObject(charIDToTypeID("ebbl"), charIDToTypeID("ebbl"), layerEffects);
                break;
            case "DropShadow":
                layerEffects = newDropShadowEffect(globalLightDesc, dropShadowColor, dropShadowAngle,
                                               dropShadowSize, dropShadowDistance, dropShadowSpread);
                layerOptions.putObject(charIDToTypeID("DrSh"), charIDToTypeID("DrSh"), layerEffects);
                break;
            case "Glow":
                layerEffects = newGlowEffect(glowColor, glowOpacity, glowSize, glowContourName);
                if (glowInner)
                    layerOptions.putObject(charIDToTypeID("IrGl"), charIDToTypeID("IrGl"), layerEffects);
                else
                    layerOptions.putObject(charIDToTypeID("OrGl"), charIDToTypeID("OrGl"), layerEffects);
                break;
            default:
                throw("newLayerEffects() Invalid effect=" + effectsArray[i]);
                break;
        }
    }
    //-----------------
    // layer properties
    //-----------------
    refr01.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("Lefx"));
    refr01.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    layerProperties.putReference(charIDToTypeID("null"), refr01);
    layerProperties.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), layerOptions);
    try {
        executeAction(charIDToTypeID("setd"), layerProperties, dialogMenu);
        waitForRedraw();
    } catch(e) {
        alert(scriptName + " newLayerEffects() exception caught? line[" + e.line + "] "  + e);
    }
    return;
}

// -----------------------------------------
// newStrokeEffect()
//   strokeSize:           // 0 - 250 px
//   strokeColor:          // SolidColor()
//   strokePosition:       // Outside[OutF], Inside[InsF], Center[CtrF]
// -----------------------------------------
function newStrokeEffect(strokeSize, strokeColor, strokePosition) {
    var effectDescriptor = new ActionDescriptor();
    var effectColor = new ActionDescriptor();
    var strokeOpacity = 100.0;      // 0 - 100 %
    var strokeBlend = "Nrml";       // Normal[Nrml], ColorBurn[CBrn], SoftLight[SftL}, Color[Clr ]

    effectDescriptor.putBoolean(charIDToTypeID("enab"), true);
    effectDescriptor.putEnumerated(charIDToTypeID("Styl"), charIDToTypeID("FStl"), charIDToTypeID(strokePosition));
    effectDescriptor.putEnumerated(charIDToTypeID("PntT"), charIDToTypeID("FrFl"), charIDToTypeID("SClr"));
    effectDescriptor.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID(strokeBlend));
    effectDescriptor.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), strokeOpacity);
    effectDescriptor.putUnitDouble(charIDToTypeID("Sz  "), charIDToTypeID("#Pxl"), strokeSize);
    effectColor.putDouble(charIDToTypeID("Rd  "), strokeColor.rgb.red);
    effectColor.putDouble(charIDToTypeID("Grn "), strokeColor.rgb.green);
    effectColor.putDouble(charIDToTypeID("Bl  "), strokeColor.rgb.blue);
    effectDescriptor.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), effectColor);
    return(effectDescriptor);
}

// -----------------------------------------
// newColorOverlayEffect()
//   overlayOpacity:       // 0 - 100 %
//   overlayColor:         // SolidColor()
// -----------------------------------------
function newColorOverlayEffect(overlayOpacity, overlayColor) {
    var effectDescriptor = new ActionDescriptor();
    var effectColor = new ActionDescriptor();

    effectDescriptor.putBoolean(charIDToTypeID("enab"), true);
    effectDescriptor.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Clr "));
    effectDescriptor.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), overlayOpacity);
    effectColor.putDouble(charIDToTypeID("Rd  "), overlayColor.rgb.red);
    effectColor.putDouble(charIDToTypeID("Grn "), overlayColor.rgb.green);
    effectColor.putDouble(charIDToTypeID("Bl  "), overlayColor.rgb.blue);
    effectDescriptor.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), effectColor);
    return(effectDescriptor);
}

// -----------------------------------------
// newDropShadowEffect()
//   dropShadowColor:      // SolidColor()
//   dropShadowDistance:   // 0 - 30000 px
//   dropShadowSpread:     // 0 - 100 px
//   dropShadowSize:       // 0 - 250 px
//   dropShadowAngle:      // -180 - +180 �
// -----------------------------------------
function newDropShadowEffect(globalLightDesc, dropShadowColor, dropShadowAngle,
                             dropShadowSize, dropShadowDistance, dropShadowSpread) {
    var effectDescriptor = new ActionDescriptor();
    var effectColor = new ActionDescriptor();
    var effectContour = new ActionDescriptor();
    var dropShadowOpacity = 100.0;          // 0 - 100 %
    var dropShadowNoise = 0.0;              // 0 - 100 %

    //------------------------------------
    // insert the global light description
    //------------------------------------
    if (globalLightDesc != null)
        globalLightDesc.putUnitDouble(charIDToTypeID("gagl"), charIDToTypeID("#Ang"), dropShadowAngle);
    //----------------------------------
    // build the drop shadow description
    //----------------------------------
    effectDescriptor.putBoolean(charIDToTypeID("enab"), true);
    effectDescriptor.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Mltp"));
    effectColor.putDouble(charIDToTypeID("Rd  "), dropShadowColor.rgb.red);
    effectColor.putDouble(charIDToTypeID("Grn "), dropShadowColor.rgb.green);
    effectColor.putDouble(charIDToTypeID("Bl  "), dropShadowColor.rgb.blue);
    effectDescriptor.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), effectColor);
    effectDescriptor.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), dropShadowOpacity);
    if (globalLightDesc != null) {
        effectDescriptor.putBoolean(charIDToTypeID("uglg"), true);
    } else {
        effectDescriptor.putBoolean(charIDToTypeID("uglg"), false);
        effectDescriptor.putUnitDouble(charIDToTypeID("lagl"), charIDToTypeID("#Ang"), dropShadowAngle);
    }
    effectDescriptor.putUnitDouble(charIDToTypeID("Dstn"), charIDToTypeID("#Pxl"), dropShadowDistance);
    effectDescriptor.putUnitDouble(charIDToTypeID("Ckmt"), charIDToTypeID("#Pxl"), dropShadowSize);
    effectDescriptor.putUnitDouble(charIDToTypeID("blur"), charIDToTypeID("#Pxl"), dropShadowSpread);
    effectDescriptor.putUnitDouble(charIDToTypeID("Nose"), charIDToTypeID("#Prc"), dropShadowNoise);
    effectDescriptor.putBoolean(charIDToTypeID("AntA"), false);
    effectContour.putString(charIDToTypeID("Nm  "), "Linear");
    effectDescriptor.putObject(charIDToTypeID("TrnS"), charIDToTypeID("ShpC"), effectContour);
    effectDescriptor.putBoolean(stringIDToTypeID("layerConceals"), true);
    return(effectDescriptor);
}

// -----------------------------------------
// newBevelEmbossEffect()
//   embossDepth:          // 0 - 1000 %
//   embossSize:           // 0 - 250 px
//   embossSoften:         // 0 - 16 px
//   shadingAngle:         // -180 - +180 �
//   shadingAltitude:      // 0 - 90 �
// -----------------------------------------
function newBevelEmbossEffect(globalLightDesc, embossDepth, embossSize, embossSoften,
                              shadingAngle, shadingAltitude) {
    var effectDescriptor = new ActionDescriptor();
    var effectHighlightColor = new ActionDescriptor();
    var effectShadowColor = new ActionDescriptor();
    var effectShadingContour = new ActionDescriptor();
    var effectContour = new ActionDescriptor();
    var shadingHighlightOpacity = 85.0;                           // 0 - 100 %
    var shadingShadowOpacity = 85.0;                              // 0 - 100 %
    var shadingHighlightColor = new newRGBColor(255, 255, 255);   // white
    var shadingShadowColor = new newRGBColor(0, 0, 0);            // black
    var contourRange = 50.0;                                      // 0 - 100 %

    //------------------------------------
    // insert the global light description
    //------------------------------------
    if (globalLightDesc != null) {
        globalLightDesc.putUnitDouble(charIDToTypeID("gagl"), charIDToTypeID("#Ang"), shadingAngle);
        globalLightDesc.putUnitDouble(stringIDToTypeID("globalAltitude"),
                                      charIDToTypeID("#Ang"), shadingAltitude);
    }
    //-------------------------------------
    // build the bevel & emboss description
    //-------------------------------------
    effectDescriptor.putBoolean(charIDToTypeID("enab"), true);
    effectDescriptor.putEnumerated(charIDToTypeID("hglM"), charIDToTypeID("BlnM"), charIDToTypeID("Scrn"));
    effectHighlightColor.putDouble(charIDToTypeID("Rd  "), shadingHighlightColor.rgb.red);
    effectHighlightColor.putDouble(charIDToTypeID("Grn "), shadingHighlightColor.rgb.green);
    effectHighlightColor.putDouble(charIDToTypeID("Bl  "), shadingHighlightColor.rgb.blue);
    effectDescriptor.putObject(charIDToTypeID("hglC"), charIDToTypeID("RGBC"), effectHighlightColor);
    effectDescriptor.putUnitDouble(charIDToTypeID("hglO"), charIDToTypeID("#Prc"), shadingHighlightOpacity);
    effectDescriptor.putEnumerated(charIDToTypeID("sdwM"), charIDToTypeID("BlnM"), charIDToTypeID("Mltp"));
    effectShadowColor.putDouble(charIDToTypeID("Rd  "), shadingShadowColor.rgb.red);
    effectShadowColor.putDouble(charIDToTypeID("Grn "), shadingShadowColor.rgb.green);
    effectShadowColor.putDouble(charIDToTypeID("Bl  "), shadingShadowColor.rgb.blue);
    effectDescriptor.putObject(charIDToTypeID("sdwC"), charIDToTypeID("RGBC"), effectShadowColor);
    effectDescriptor.putUnitDouble(charIDToTypeID("sdwO"), charIDToTypeID("#Prc"), shadingShadowOpacity);
    effectDescriptor.putEnumerated(charIDToTypeID("bvlT"), charIDToTypeID("bvlT"), charIDToTypeID("SfBL"));
    effectDescriptor.putEnumerated(charIDToTypeID("bvlS"), charIDToTypeID("BESl"), charIDToTypeID("InrB"));
    if (globalLightDesc != null) {
        effectDescriptor.putBoolean(charIDToTypeID("uglg"), true);
    } else {
        effectDescriptor.putBoolean(charIDToTypeID("uglg"), false);
        effectDescriptor.putUnitDouble(charIDToTypeID("lagl"), charIDToTypeID("#Ang"), shadingAngle);
        effectDescriptor.putUnitDouble(charIDToTypeID("Lald"), charIDToTypeID("#Ang"), shadingAltitude);
    }
    effectDescriptor.putUnitDouble(charIDToTypeID("srgR"), charIDToTypeID("#Prc"), embossDepth);
    effectDescriptor.putUnitDouble(charIDToTypeID("blur"), charIDToTypeID("#Pxl"), embossSize);
    effectDescriptor.putEnumerated(charIDToTypeID("bvlD"), charIDToTypeID("BESs"), charIDToTypeID("Out "));
    effectShadingContour.putString(charIDToTypeID("Nm  "), "Linear");
    effectDescriptor.putObject(charIDToTypeID("TrnS"), charIDToTypeID("ShpC"), effectShadingContour);
    effectDescriptor.putBoolean(stringIDToTypeID("antialiasGloss"), false);
    effectDescriptor.putUnitDouble(charIDToTypeID("Sftn"), charIDToTypeID("#Pxl"), embossSoften);
    effectDescriptor.putBoolean(stringIDToTypeID("useShape"), true);
    effectContour.putString(charIDToTypeID("Nm  "), "Linear");
    effectDescriptor.putObject(charIDToTypeID("MpgS"), charIDToTypeID("ShpC"), effectContour);
    effectDescriptor.putBoolean(charIDToTypeID("AntA"), false);
    effectDescriptor.putUnitDouble(charIDToTypeID("Inpr"), charIDToTypeID("#Prc"), contourRange);
    effectDescriptor.putBoolean(stringIDToTypeID("useTexture"), false);
    return(effectDescriptor);
}

// -----------------------------------------
// newGlowEffect()
//   glowOpacity = 100.0;            // 0 - 100 %
//   glowSize = 20.0;                // 0 - 250 px
//   contourName = "Ring - Double";  // [Linear], [Ring], [Ring - Double]
// -----------------------------------------
function newGlowEffect(glowColor, glowOpacity, glowSize, contourName) {
    var effectDescriptor = new ActionDescriptor();
    var effectColor = new ActionDescriptor();
    var glowContour = new ActionDescriptor();
    var glowBlendMode = "Nrml";         // normal[Nrml], screen[Scrn]
    var glowSpread = 15.0;              // 0 - 100 %
    var glowNoise = 0.0;                // 0 - 100 %
    var contourRange = 50.0;            // 0 - 100 %
    var contourJitter = 0.0;            // 0 - 100 %

    //-------------------------------------
    // build the glow description
    //-------------------------------------
    effectDescriptor.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID(glowBlendMode));
    effectColor.putDouble(charIDToTypeID("Rd  "), glowColor.rgb.red);
    effectColor.putDouble(charIDToTypeID("Grn "), glowColor.rgb.green);
    effectColor.putDouble(charIDToTypeID("Bl  "), glowColor.rgb.blue);
    effectDescriptor.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), effectColor);
    effectDescriptor.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), glowOpacity);
    effectDescriptor.putEnumerated(charIDToTypeID("GlwT"), charIDToTypeID("BETE"), charIDToTypeID("SfBL"));
    effectDescriptor.putUnitDouble(charIDToTypeID("Ckmt"), charIDToTypeID("#Pxl"), glowSpread);
    effectDescriptor.putUnitDouble(charIDToTypeID("blur"), charIDToTypeID("#Pxl"), glowSize);
    effectDescriptor.putUnitDouble(charIDToTypeID("Nose"), charIDToTypeID("#Prc"), glowNoise);
    effectDescriptor.putUnitDouble(charIDToTypeID("ShdN"), charIDToTypeID("#Prc"), contourJitter);
    effectDescriptor.putBoolean(charIDToTypeID("AntA"), false);
    glowContour.putString(charIDToTypeID("Nm  "), contourName);
    effectDescriptor.putObject(charIDToTypeID("TrnS"), charIDToTypeID("ShpC"), glowContour);
    effectDescriptor.putUnitDouble(charIDToTypeID("Inpr"), charIDToTypeID("#Prc"), contourRange);
    return(effectDescriptor);
}

// -------------------------------------------------------
// waitForRedraw()
// -------------------------------------------------------
function waitForRedraw() {
    var eventWait = charIDToTypeID("Wait");
    var enumRedrawComplete = charIDToTypeID("RdCm");
    var typeState = charIDToTypeID("Stte");
    var keyState = charIDToTypeID("Stte");
    var desc = new ActionDescriptor();

    desc.putEnumerated(keyState, typeState, enumRedrawComplete);
    executeAction(eventWait, desc, DialogModes.NO);
    return;
}

// -------------------------------------------------------
// newGuide()
// -------------------------------------------------------
function newGuide(vert, pct) {
    var hvOrient;
    var pixs;
    var desc1 = new ActionDescriptor();
    var desc2 = new ActionDescriptor();

    if (vert) {
        hvOrient = "Vrtc";
        pixs = pct * 0.01 * docCanvas.sH;
    } else {
        hvOrient = "Hrzn";
        pixs = pct * 0.01 * docCanvas.sV;
    }
    desc2.putUnitDouble(charIDToTypeID("Pstn"), charIDToTypeID("#Pxl"), pixs);
    desc2.putEnumerated(charIDToTypeID("Ornt"), charIDToTypeID("Ornt"), charIDToTypeID(hvOrient));
    desc1.putObject(charIDToTypeID("Nw  "), charIDToTypeID("Gd  "), desc2);
    executeAction(charIDToTypeID("Mk  "), desc1, DialogModes.NO);
    return;
}

// -------------------------------------------------------
// removeGuides()
// -------------------------------------------------------
function removeGuides() {
    var refr1 = new ActionReference();
    var desc1 = new ActionDescriptor();

    refr1.putEnumerated(charIDToTypeID("Gd  "), charIDToTypeID("Ordn"), charIDToTypeID("Al  "));
    desc1.putReference(charIDToTypeID("null"), refr1);
    executeAction(charIDToTypeID("Dlt "), desc1, DialogModes.NO);
    return;
}

// -------------------------------------------------------
// newRGBColor()
// -------------------------------------------------------
function newRGBColor(r, g, b) {
    var newColor = new SolidColor();

    newColor.rgb.red = r;
    newColor.rgb.green = g;
    newColor.rgb.blue = b;
    return(newColor);
}

// ---------------------------------------
// px2in()
// ---------------------------------------
function px2in(pixels) {

    return(Math.round(pixels / canvasPPI * 100) / 100);
}

// ---------------------------------------
// in2px()
// ---------------------------------------
function in2px(inches) {

    return(Math.round(inches * canvasPPI));
}

// -----------------------------------------
// replaceUrlBlanks()
// replace %20:" " and trim to max length
// -----------------------------------------
function replaceUrlBlanks(urlString, lth) {
    var newUrl = new String(urlString);     // new url string
    var urlBlanks  = new RegExp(/\%20/g);

    newUrl = newUrl.replace(urlBlanks, " ");
    if (lth != undefined && newUrl.length > lth+1)
        newUrl = "~" + newUrl.substr(newUrl.length-lth, newUrl.length);
    return(newUrl);
}

// -----------------------------------------
// getElapsedTime()
// -----------------------------------------
function getElapsedTime(startTime) {
    var now = new Date();
    var timeDiff = Number(0);
    var timeString = new String("");
    timeDiff = Math.round((now - startTime) / 1000);
    if (timeDiff > 3600) {
        timeString = Math.round(timeDiff / 3600) + " hours ";
        timeDiff = Math.round(timeDiff % 3600);
    }
    if (timeDiff > 60) {
        timeString = timeString + Math.round(timeDiff / 60) + " minutes ";
        timeDiff = Math.round(timeDiff % 60);
    } else if (timeString.length > 0) {
        timeString = timeString + "0 minutes ";
    }
    timeString = timeString + Math.round(timeDiff) + " seconds ";
    return(timeString);
}

// -----------------------------------------
// showUsage()
// -----------------------------------------
function showUsage(reason) {
    var msgStr = "";

    msgStr += "\n" + crSymbol + " 2008 Rags Int., Inc. Rags Gardner: www.rags-int-inc.com\n";
    msgStr += "\nThis is a Modified version that builds Photo Collage Templates";
    msgStr += "\nthat are compatable with John J. McAssey's Photo Collage Toolkit scripts.\n";
    msgStr += "\nBasic operation:";
    msgStr += "\nThis script will build a template for image collages.  Specify a size for the main";
    msgStr += "\n(large) image and the secondary (small) images in inches.  Also a size for the";
    msgStr += "\ncanvas and some default borders as a percentage of the canvas and small images sizes.";
    msgStr += "\n\nIt will build a new canvas and place the images in unique layers.  If scale canvas";
    msgStr += "\nis checked the canvas size will be based on the image sizes and layout.  If it is not";
    msgStr += "\nchecked the image sizes may be scaled if they do not fit in the user selected canvas."; 
    msgStr += "\nThus the image aspect ratios are more important than the actual sizes.";
    msgStr += "\n\nThe alignment options determine where the main image will be placed relative to the";
    msgStr += "\ncanvas and small images.  The edge percent specifies the minimum border around the";
    msgStr += "\nimage (% of image size).  These may be adjusted as the layout is created to preserve";
    msgStr += "\nsymmetry.";
/* JJMack
    msgStr += "\n\nIf preview layout is checked, a preview will be created on a single layer. If not checked,";
    msgStr += "\nthe template with layers for each image will be built and the script will end with the";
    msgStr += "\ntemplate left open.";
    msgStr += "\n\nLayer Styles";
    msgStr += "\nDoubleRing:    Double Ring Glow (Button) from PS default styles";
    msgStr += "\nCollageStyle1: User supplied PS style, sample uses bevel & emboss";
    msgStr += "\nCollageStyle2: User supplied PS style, sample uses inner glow & stroke";
    msgStr += "\nCollageStyle3: User supplied PS style, sample uses drop shadow & b/w color overlay";
    msgStr += "\nCollageStyle4: User supplied PS style, sample uses inner glow & bevel & emboss";
    msgStr += "\n\nCollageStyle1-4 must be loaded to the Photoshop styles folder, [ps]/Presets/Styles/.";
    msgStr += "\nA sample is provided as CollageBuilderStyles.asl.  These must then be loaded in the";
    msgStr += "\nPS Styles menu pallet.  Or you can create your own styles with these names.";
    msgStr += "\n\nA preview layout will emulate these styles.  Each preview canvas is dismissed on the";
    msgStr += "\nnext operation by default.  This is provided simply to review the basic layout geometry.";
    msgStr += "\n\nThe images can be opened and placed in the template later with the";
    msgStr += "\ncompanion script, CollageLoader.jsx.";
 JJMack */
    msgStr += "\n\nThese templates can be saved and/or modified as desired for future use.";
/* JJMack
    msgStr += "\n\nThese templates can be saved and/or modified as desired for future use.  The layer";
    msgStr += "\nnaming convention must be preserved, MainImage(xx) and smImage(xx).  If additional";
    msgStr += "\nlayers are created that do not conform to these conventions, they will simply be";
    msgStr += "\nignored.  The layer styles, image size, orientation, and position can be altered as";
    msgStr += "\ndesired.  Thus these templates can be saved with any customization desired.  The";
 JJmack */
    msgStr += "\nThese templates can be saved with any customization desired.  The";
    msgStr += "\ncollage images will be scaled to fit the layer size as they are loaded.  If the image has";
    msgStr += "\ntransparent pixels in the border, the layer shape will change accordingly and the layer";
    msgStr += "\nedge style will warp to fit. Be creative.";
/* JJMack
    msgStr += "\nedge style will warp to fit.  Similar effects can be obtained by applying a layer mask to";
    msgStr += "\nthe template layer.  In this case, some image cropping may be observed.  Be creative.";
 JJMack */
    alert(scriptName + " " + reason + msgStr);
    return;
}

// -----------------------
// getScriptPath()
// from the exception data
// -----------------------
function getScriptPath() {
    var fpath = null;
    var dbLevel;
    var ex;

    try {
        dbLevel = $.level;   // save
        $.level = 0;
        undefined_variable;  // throw an exception
    } catch(ex) {
        fpath = ex.fileName; // path/file
    } finally {
        $.level = dbLevel;   // restore
    }
    fpath = fpath.substring(0, fpath.lastIndexOf("/")+1);
    return(fpath);
}

// -----------------------------------------
// getMyScriptFileName()
// from the exception data
// -----------------------------------------
function getMyScriptFileName() {
    var fname = null;
    var dbLevel;
    var ex;

    try {
       dbLevel = $.level;   // save
       $.level = 0;
       undefined_variable;  // throw an exception
    } catch(ex) {
       fname = ex.fileName; // path/file
    } finally {
      $.level = dbLevel;    // restore
    }
    fname = fname.substring(fname.lastIndexOf("/")+1, fname.lastIndexOf("."));
    return(fname);
}

// -----------------------------------------
// cleanUp()
// -----------------------------------------
function cleanUp() {
    var ex;

    app.preferences.rulerUnits = initRulerUnits;
    app.DisplayDialogs = initDisplayDialogs;
    app.backgroundColor = initBgColor;
    app.foregroundColor = initFgColor;
    try {
		if (iconCreated) {
		    docRefIcon.close(SaveOptions.DONOTSAVECHANGES);
            docRefIcon = null; 
		}
        if (iconCreated && File(iconURL).exists)
            File(iconURL).remove();
    } catch(ex) {} // ignore invalid object
    try {
        if (docRefIcon != null)
            docRefIcon.close(SaveOptions.DONOTSAVECHANGES);
    } catch(ex) {} // ignore invalid object
    return;
}

// -----------------------------------------
// mainFunction()
// -----------------------------------------
function mainFunction() {
    var retCd;
    var mainMsg;
    var saveOpts;

    //-----------
    // Initialize
    //-----------
    app.DisplayDialogs = DialogModes.NO;
    app.preferences.rulerUnits = Units.PIXELS;
    iconPath = new String($.getenv ("TEMP") + "/"); // try the OS TEMP directory
    if (iconPath == "/")
        iconPath = getScriptPath();                 // try the ~/presets/scripts directory
    iconURL = iconPath + defaultIconName;
    /// if (!confirm(scriptName + " Use color icon in menus?\n" + replaceUrlBlanks(iconURL)))
    ///     useIconPreview = false;
    //-----------------------------------------
    // open an icon image for the color chooser
    //-----------------------------------------
    if (useIconPreview) {
        if (File(iconURL).exists) {
            if (confirm(" Icon file found:\n  " + replaceUrlBlanks(iconURL) +
                        "\n\nRemove it?")) {
                if (!File(iconURL).remove()) {
                    alert(scriptName + "Could not remove Icon:\n" + replaceUrlBlanks(iconURL));
                    return;
                }
            }
        }
        app.documents.add(40, 20, 72, defaultIconName,
                          NewDocumentMode.RGB, DocumentFill.BACKGROUNDCOLOR);
        docRefIcon = app.activeDocument;
        saveOpts = new PNGSaveOptions();
        saveOpts.interlaced = false;
        docRefIcon.saveAs(File(iconURL), saveOpts, false, Extension.LOWERCASE);
       // docRefIcon.close(SaveOptions.DONOTSAVECHANGES);
       // docRefIcon = null;                      // close the PS document
        iconCreated = true;                     // icon created by this script
    }
    //-----------------------------------
    // build the options dialog menus
    // set defaults from global variables
    //-----------------------------------
    dlg = new Options();
    layerMenu = new LayerMenu(useIconPreview);
    colorScheme = new ColorScheme(useIconPreview);
    colorMenu = new ColorMenu(useIconPreview);
    while (1) {
        //--------------
        // show the menu
        //--------------
        retCd = dlg.showMenu();    // returns 1 or 2
        if (retCd != 1)            // user cancel
            break;
        //--------------------------------------
        // close the current preview or template
        //--------------------------------------
        if (dismissPreview && docRefBase != null)
            docRefBase.close(SaveOptions.DONOTSAVECHANGES);
        //----------------------------------
        // build the desired template layers
        //----------------------------------
        if (!canvasPreview)
            buildTime = buildTemplate();
        else
            buildTime = previewTemplate();
        app.preferences.rulerUnits = initRulerUnits;
    }
    //----------------------------
    // finished
    //----------------------------
    if (dismissPreview && docRefBase != null)
        docRefBase.close(SaveOptions.DONOTSAVECHANGES);
    return;
}

// =======================================================
// =======================================================
// JavaScript EntryPoint
// =======================================================
// =======================================================
var crSymbol = new String("\u00A9");              // (c) symbol
var docRefBase = null;                            // base template document
var docRefIcon = null;                            // the PNG icon document
var defaultIconName = "CollageBuilderIcon.png";   // default PNG image name
var iconPath = "";                                // the PNG image file path
var iconURL;                                      // the PNG image path + name
var iconCreated = false;                          // icon created by this script
var templateFile;                                 // template file name
var initRulerUnits;                               // save ruler units
var initDisplayDialogs;                           // save dialog settings
var initBgColor;                                  // save BG color
var initFgColor;                                  // save FG color
var strVer = new String(app.version);             // photoshop version string
var psVer;                                        // photoshop version
var mainAnchor;                                   // main image anchor point
var smallAnchors;                                 // small image anchor points
var docCanvas;                                    // document canvas anchor and size
var imgArea;                                      // canvas image area anchor and size
var mainImage;                                    // main image anchor and size
var smallImage;                                   // small image anchor and size
var whiteColor = newRGBColor(255, 255, 255);      // white
var blackColor = newRGBColor(0, 0, 0);            // black
var sepiaColor = newRGBColor(43, 2, 2);           // sepia
var imageEdgeSize = 1;                            // preview image edge stroke size
var textColor = newRGBColor(0, 0, 0);             // black
var textStrokeColor = newRGBColor(255, 255, 255); // white
var imageScale;                                   // image size scaling
var styleInvalid = false;                         // layer style not found
var buildTime = "";                               // build time message
var dlg;                                          // options menu
var layerMenu;                                    // layer options menu
var colorScheme;                                  // color scheme menu
var colorMenu;                                    // color chooser menu
var e;                                            // exception information
var lineMsg = " ";                                // exception line number
var codeMsg = "";                                 // exception code number

psVer = parseFloat(strVer.substring(0, strVer.lastIndexOf(".")));
if (psVer < 9.0) {
    alert(scriptName + " uses menu functions not avaliable with Photoshop version " + psVer);
} else {
    scriptName = getMyScriptFileName() + " " + scriptVersion;
    initRulerUnits = app.preferences.rulerUnits;
    initDisplayDialogs = app.DisplayDialogs;
    initBgColor = app.backgroundColor;
    initFgColor = app.foregroundColor;
    //------------------------
    // Dispatch mainFunction()
    //------------------------
    try {
        mainFunction();
    } catch(e) {
        if (e.number != undefined)
            codeMsg = " errCode[" + e.number + "]"; // exception code number
        if (e.line != undefined)
            lineMsg = " line[" + e.line + "]";      // exception line number
        alert("Main() " + codeMsg + lineMsg + " Exception:\n" + e,
            scriptName + " Exception!");            // show the error
    }
    cleanUp();                                      // restore rulers...
}

function layerForward(){
	var idslct = charIDToTypeID( "slct" );
	    var desc26 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref19 = new ActionReference();
 	       var idLyr = charIDToTypeID( "Lyr " );
 	       var idOrdn = charIDToTypeID( "Ordn" );
	        var idFrwr = charIDToTypeID( "Frwr" );
	        ref19.putEnumerated( idLyr, idOrdn, idFrwr );
 	   desc26.putReference( idnull, ref19 );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc26.putBoolean( idMkVs, false );
	executeAction( idslct, desc26, DialogModes.NO );
}

function selectTranparency(){
	var idsetd = charIDToTypeID( "setd" );
	    var desc26 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
 	       var ref9 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idfsel = charIDToTypeID( "fsel" );
	        ref9.putProperty( idChnl, idfsel );
	    desc26.putReference( idnull, ref9 );
	    var idT = charIDToTypeID( "T   " );
	        var ref10 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idChnl = charIDToTypeID( "Chnl" );
 	       var idTrsp = charIDToTypeID( "Trsp" );
	        ref10.putEnumerated( idChnl, idChnl, idTrsp );
 	   desc26.putReference( idT, ref10 );
	executeAction( idsetd, desc26, DialogModes.NO );
}

function  saveAlpha(alphaName){
	var idDplc = charIDToTypeID( "Dplc" );
	    var desc27 = new ActionDescriptor();
 	   var idnull = charIDToTypeID( "null" );
	        var ref11 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idfsel = charIDToTypeID( "fsel" );
	        ref11.putProperty( idChnl, idfsel );
	    desc27.putReference( idnull, ref11 );
	    var idNm = charIDToTypeID( "Nm  " );
	    desc27.putString( idNm, alphaName );
	executeAction( idDplc, desc27, DialogModes.NO );
}

function makeLayer(name){
	var idMk = charIDToTypeID( "Mk  " );
	    var desc138 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref91 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        ref91.putClass( idLyr );
	    desc138.putReference( idnull, ref91 );
	    var idUsng = charIDToTypeID( "Usng" );
	        var desc139 = new ActionDescriptor();
	        var idNm = charIDToTypeID( "Nm  " );
	        desc139.putString( idNm, name );
	    var idLyr = charIDToTypeID( "Lyr " );
	    desc138.putObject( idUsng, idLyr, desc139 );
	executeAction( idMk, desc138, DialogModes.NO );
}

function selectChannelTrans(name){  
	var idsetd = charIDToTypeID( "setd" );
	    var desc22 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref20 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idfsel = charIDToTypeID( "fsel" );
 	       ref20.putProperty( idChnl, idfsel );
 	   desc22.putReference( idnull, ref20 );
	    var idT = charIDToTypeID( "T   " );
	        var ref21 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        ref21.putName( idChnl, name );
 	   desc22.putReference( idT, ref21 );
	executeAction( idsetd, desc22, DialogModes.NO );
}

function addChannelTrans(image) {
	var idAdd = charIDToTypeID( "Add " );
	    var desc23 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref22 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        ref22.putName( idChnl, image );
	    desc23.putReference( idnull, ref22 );
	    var idT = charIDToTypeID( "T   " );
	        var ref23 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idfsel = charIDToTypeID( "fsel" );
	        ref23.putProperty( idChnl, idfsel );
	    desc23.putReference( idT, ref23 );
	executeAction( idAdd, desc23, DialogModes.NO );
}

function fillColor(){
	// Hard coded Fill with light gray
	var idFl = charIDToTypeID( "Fl  " );
	    var desc31 = new ActionDescriptor();
	    var idUsng = charIDToTypeID( "Usng" );
	    var idFlCn = charIDToTypeID( "FlCn" );
	    var idClr = charIDToTypeID( "Clr " );
	    desc31.putEnumerated( idUsng, idFlCn, idClr );
	    var idClr = charIDToTypeID( "Clr " );
	        var desc32 = new ActionDescriptor();
 	       var idRd = charIDToTypeID( "Rd  " );
	        desc32.putDouble( idRd, 221.996109 );
	        var idGrn = charIDToTypeID( "Grn " );
	        desc32.putDouble( idGrn, 221.996109 );
	        var idBl = charIDToTypeID( "Bl  " );
	        desc32.putDouble( idBl, 221.996109 );
	    var idRGBC = charIDToTypeID( "RGBC" );
 	   desc31.putObject( idClr, idRGBC, desc32 );
 	   var idOpct = charIDToTypeID( "Opct" );
	    var idPrc = charIDToTypeID( "#Prc" );
	    desc31.putUnitDouble( idOpct, idPrc, 100.000000 );
	    var idMd = charIDToTypeID( "Md  " );
	    var idBlnM = charIDToTypeID( "BlnM" );
	    var idNrml = charIDToTypeID( "Nrml" );
	    desc31.putEnumerated( idMd, idBlnM, idNrml );
	executeAction( idFl, desc31, DialogModes.NO );
}

function addTexture(){  
	// texturizer sandstone
	var idTxtz = charIDToTypeID( "Txtz" );
	    var desc87 = new ActionDescriptor();
	    var idGEfk = charIDToTypeID( "GEfk" );
	    var idGEft = charIDToTypeID( "GEft" );
	    var idTxtz = charIDToTypeID( "Txtz" );
	    desc87.putEnumerated( idGEfk, idGEft, idTxtz );
	    var idTxtT = charIDToTypeID( "TxtT" );
	    var idTxtT = charIDToTypeID( "TxtT" );
	    var idTxSt = charIDToTypeID( "TxSt" );
	    desc87.putEnumerated( idTxtT, idTxtT, idTxSt );
	    var idScln = charIDToTypeID( "Scln" );
	    desc87.putInteger( idScln, 85 );
	    var idRlf = charIDToTypeID( "Rlf " );
	    desc87.putInteger( idRlf, 6 );
	    var idLghD = charIDToTypeID( "LghD" );
	    var idLghD = charIDToTypeID( "LghD" );
	    var idLDTL = charIDToTypeID( "LDTL" );
	    desc87.putEnumerated( idLghD, idLghD, idLDTL );
	    var idInvT = charIDToTypeID( "InvT" );
	    desc87.putBoolean( idInvT, false );
	try{
		executeAction( idTxtz, desc87, DialogModes.NO );
	}catch(e){}
}

function addStyle(Style){
	var idASty = charIDToTypeID( "ASty" );
	    var desc20 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref3 = new ActionReference();
	        var idStyl = charIDToTypeID( "Styl" );
	        ref3.putName( idStyl, Style );
	    desc20.putReference( idnull, ref3 );
	    var idT = charIDToTypeID( "T   " );
	        var ref4 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref4.putEnumerated( idLyr, idOrdn, idTrgt );
	    desc20.putReference( idT, ref4 );
	try{
		executeAction( idASty, desc20, DialogModes.NO);
	}catch(e){}
}

function addClipHueAdj(){ 
	// Add a Clipped Hue and Saturation Adjustment layer
	var idMk = charIDToTypeID( "Mk  " );
	    var desc90 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref66 = new ActionReference();
	        var idAdjL = charIDToTypeID( "AdjL" );
	        ref66.putClass( idAdjL );
	    desc90.putReference( idnull, ref66 );
	    var idUsng = charIDToTypeID( "Usng" );
	        var desc91 = new ActionDescriptor();
	        var idGrup = charIDToTypeID( "Grup" );
	        desc91.putBoolean( idGrup, true );
	        var idType = charIDToTypeID( "Type" );
	            var desc92 = new ActionDescriptor();
	            var idpresetKind = stringIDToTypeID( "presetKind" );
	            var idpresetKindType = stringIDToTypeID( "presetKindType" );
	            var idpresetKindDefault = stringIDToTypeID( "presetKindDefault" );
	            desc92.putEnumerated( idpresetKind, idpresetKindType, idpresetKindDefault );
	            var idClrz = charIDToTypeID( "Clrz" );
	            desc92.putBoolean( idClrz, false );
	        var idHStr = charIDToTypeID( "HStr" );
	        desc91.putObject( idType, idHStr, desc92 );
	    var idAdjL = charIDToTypeID( "AdjL" );
	    desc90.putObject( idUsng, idAdjL, desc91 );
	executeAction( idMk, desc90, DialogModes.NO );

	// Adjust hue adjustment layer
	var idsetd = charIDToTypeID( "setd" );
	    var desc182 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref106 = new ActionReference();
	        var idAdjL = charIDToTypeID( "AdjL" );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref106.putEnumerated( idAdjL, idOrdn, idTrgt );
	    desc182.putReference( idnull, ref106 );
	    var idT = charIDToTypeID( "T   " );
	        var desc183 = new ActionDescriptor();
	        var idClrz = charIDToTypeID( "Clrz" );
	        desc183.putBoolean( idClrz, true );
	        var idAdjs = charIDToTypeID( "Adjs" );
	            var list27 = new ActionList();
	                var desc184 = new ActionDescriptor();
	                var idChnl = charIDToTypeID( "Chnl" );
	                var idChnl = charIDToTypeID( "Chnl" );
	                var idCmps = charIDToTypeID( "Cmps" );
	                desc184.putEnumerated( idChnl, idChnl, idCmps );
	                var idH = charIDToTypeID( "H   " );
	                desc184.putInteger( idH, 48 );
	                var idStrt = charIDToTypeID( "Strt" );
	                desc184.putInteger( idStrt, 78 );
	                var idLght = charIDToTypeID( "Lght" );
	                desc184.putInteger( idLght, 2 );
	            var idHsttwo = charIDToTypeID( "Hst2" );
	            list27.putObject( idHsttwo, desc184 );
	        desc183.putList( idAdjs, list27 );
	    var idHStr = charIDToTypeID( "HStr" );
	    desc182.putObject( idT, idHStr, desc183 );
	executeAction( idsetd, desc182, DialogModes.NO );
}

function targetCont(name){
	var idslct = charIDToTypeID( "slct" );
	    var desc96 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref68 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        ref68.putName( idLyr, name );	
	    desc96.putReference( idnull, ref68 );
	    var idselectionModifier = stringIDToTypeID( "selectionModifier" );
	    var idselectionModifierType = stringIDToTypeID( "selectionModifierType" );
	    var idaddToSelectionContinuous = stringIDToTypeID( "addToSelectionContinuous" );
	    desc96.putEnumerated( idselectionModifier, idselectionModifierType, idaddToSelectionContinuous );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc96.putBoolean( idMkVs, false );
	executeAction( idslct, desc96, DialogModes.NO );
}

function makeGroup(name){  
	var idMk = charIDToTypeID( "Mk  " );
	    var desc97 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref69 = new ActionReference();
	        var idlayerSection = stringIDToTypeID( "layerSection" );
	        ref69.putClass( idlayerSection );
	    desc97.putReference( idnull, ref69 );
	    var idFrom = charIDToTypeID( "From" );
	        var ref70 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref70.putEnumerated( idLyr, idOrdn, idTrgt );
	    desc97.putReference( idFrom, ref70 );
	    var idUsng = charIDToTypeID( "Usng" );
	        var desc98 = new ActionDescriptor();
	        var idNm = charIDToTypeID( "Nm  " );
	        desc98.putString( idNm, name );
	    var idlayerSection = stringIDToTypeID( "layerSection" );
	    desc97.putObject( idUsng, idlayerSection, desc98 );
	executeAction( idMk, desc97, DialogModes.NO );
}

function hideGroup(){ 
	var idHd = charIDToTypeID( "Hd  " );
	    var desc118 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var list11 = new ActionList();
	            var ref78 = new ActionReference();
	            var idLyr = charIDToTypeID( "Lyr " );
	            var idOrdn = charIDToTypeID( "Ordn" );
	            var idTrgt = charIDToTypeID( "Trgt" );
	            ref78.putEnumerated( idLyr, idOrdn, idTrgt );
	        list11.putReference( ref78 );
	    desc118.putList( idnull, list11 );
	executeAction( idHd, desc118, DialogModes.NO );
}

//==================== Set View Fit on Screen ==============
function SetViewFitonScreen() {
	// Menu View>screen Mode Standard
	var desc1 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), sTID("screenModeStandard"));
	desc1.putReference(cTID('null'), ref1);
	executeAction(cTID('slct'), desc1, DialogModes.NO);
	// Menu View>Fit on screen
	var desc1 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('FtOn'));
	desc1.putReference(cTID('null'), ref1);
	executeAction(cTID('slct'), desc1, DialogModes.NO);
};
// end JavaScript