/* ==========================================================
// 2012  John J. McAssey (JJMack)
// ======================================================= */

// This script is supplied as is. It is provided as freeware.
// The author accepts no liability for any problems arising from its use.

/* Help Category note tag menu can be used to place script in automate menu
<javascriptresource>
<about>$$$/JavaScripts/ChangeTextSize/About=JJMack's ChangeTextSize.^r^rCopyright 2012 Mouseprints.^r^rChange Image Stamps text size.^rIf Images have text stamps their current text size will be shown.^rChange or accept the size and position shown then check the results.^rIf the results are you want click cancel or enter 0 for the font size!</about>
<category>JJMack's Collage Script</category>
</javascriptresource>
*/

// enable double-clicking from Mac Finder or Windows Explorer
#target photoshop // this command only works in Photoshop CS2 and higher

// bring application forward for double-click events
app.bringToFront();

// ensure at least one document open
if (!documents.length) alert('There are no documents open.', 'No Document');
else {
	// declare Global variables

	main(); // at least one document exists proceed
}
///////////////////////////////////////////////////////////////////////////////
//                            main function                                  //
///////////////////////////////////////////////////////////////////////////////
function main() {
	// declare local variables
	var orig_ruler_units = app.preferences.rulerUnits;
	var orig_type_units = app.preferences.typeUnits;
	var orig_display_dialogs = app.displayDialogs;
	app.displayDialogs = DialogModes.NO;		// Set Dialogs off
	app.preferences.rulerUnits = Units.PIXELS;	// Set the ruler units to PIXELS
	app.preferences.typeUnits = TypeUnits.POINTS;    // Set Type units to POINTS
	try { code(); }
	// display error message if something goes wrong
	catch(e) { alert(e + ': on line ' + e.line, 'Script Error', true); }
	app.displayDialogs = orig_display_dialogs;	// Reset display dialogs 
	app.preferences.typeUnits  = orig_type_units;	// Reset ruler units to original settings     
	app.preferences.rulerUnits = orig_ruler_units;	// Reset units to original settings
}
///////////////////////////////////////////////////////////////////////////////
//                           main function end                               //
///////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////
// The real code is embedded into this function so that at any point it can return //
// to the main line function to let it restore users edit environment and end      //
/////////////////////////////////////////////////////////////////////////////////////
function code() {
	var savactiveLayer = activeDocument.activeLayer;
	selectNoLayers();
	var layers = activeDocument.layers;
	if (layers[0].kind != LayerKind.TEXT) { alert("Top layer not a text layer.");}
	else {
		var currSize = layers[0].textItem.size.value ;
		var numberOfImages = getAlphaImageChannels();
		if ( numberOfImages == 0 ) { alert("No Image mapping Alpha channels"); }
                else {
			Position = 8;
			while ( currSize != 0 ) {
				currSize = Number(prompt("Enter text point size. Cancel or 0 to accept current size", currSize ));
				if (isNaN(currSize)) { currSize = 0 ; }
				if ( currSize != 0 ) {
					var Position = Number(prompt("Select Position\n1 2 3\n4 5 6\n7 8 9", Position));
					if (isNaN(Position)) { Position = 8; }
					for (var i = 0; i<numberOfImages; i++) {
						if (layers[i].kind == LayerKind.TEXT) { 
							layers[i].textItem.size = currSize + "pt" ;
							activeDocument.activeLayer = layers[i];			
							loadAlpha("Image " + (numberOfImages-i) );
							switch (Position){
							case 1 : align('AdLf'); align('AdTp'); break;
							case 2 : align('AdCH'); align('AdTp'); break;
							case 3 : align('AdRg'); align('AdTp'); break;
							case 4 : align('AdLf'); align('AdCV'); break;
							case 5 : align('AdCH'); align('AdCV'); break;
							case 6 : align('AdRg'); align('AdCV'); break;
							case 7 : align('AdLf'); align('AdBt'); break;
							case 8 : align('AdCH'); align('AdBt'); break;
							case 9 : align('AdRg'); align('AdBt'); break;
							default : break;
							}

						}
					}
				}
				activeDocument.selection.deselect();
				activeDocument.activeLayer = savactiveLayer;
				refresh();
			}
		} 
	}
	activeDocument.activeLayer = savactiveLayer; 
}

//////////////////////////////////////////////////////////////////////////////////
//			Helper Functions					//
//////////////////////////////////////////////////////////////////////////////////

function getAlphaImageChannels() {
	for (var n = 1; n < 999; n++) {
		// ======Load Image n Selection===============================
		var idsetd = charIDToTypeID( "setd" );
		    var desc2 = new ActionDescriptor();
		    var idnull = charIDToTypeID( "null" );
		        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
		        var idfsel = charIDToTypeID( "fsel" );
		        ref1.putProperty( idChnl, idfsel );
		    desc2.putReference( idnull, ref1 );
		    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
		        var idChnl = charIDToTypeID( "Chnl" );
		        ref2.putName( idChnl, "Image " + n );
		    desc2.putReference( idT, ref2 );
		try{
			executeAction( idsetd, desc2, DialogModes.NO );
		}catch(e){
			//alert ("n = " + n);
			activeDocument.selection.deselect();
			return n - 1;
		}
	}
}


function getAlphaImageChannels() {
	for (var n = 1; n < 999; n++) {
		// ======Load Image n Selection===============================
		var idsetd = charIDToTypeID( "setd" );
		    var desc2 = new ActionDescriptor();
		    var idnull = charIDToTypeID( "null" );
		        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
		        var idfsel = charIDToTypeID( "fsel" );
		        ref1.putProperty( idChnl, idfsel );
		    desc2.putReference( idnull, ref1 );
		    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
		        var idChnl = charIDToTypeID( "Chnl" );
		        ref2.putName( idChnl, "Image " + n );
		    desc2.putReference( idT, ref2 );
		try{
			executeAction( idsetd, desc2, DialogModes.NO );
		}catch(e){
			activeDocument.selection.deselect();
			//alert ("n = " + n);
			return n - 1;
		}
	}
}

function loadAlpha(channel) {
	var idsetd = charIDToTypeID( "setd" );
	    var desc2 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idfsel = charIDToTypeID( "fsel" );
	        ref1.putProperty( idChnl, idfsel );
	    desc2.putReference( idnull, ref1 );
	    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        ref2.putName( idChnl, channel );
	    desc2.putReference( idT, ref2 );
	executeAction( idsetd, desc2, DialogModes.NO );
}

// -----------------------------------------
// Align Layers to selection
// -----------------------------------------
function align(method) {
	var desc = new ActionDescriptor();
	var ref = new ActionReference();
	ref.putEnumerated( charIDToTypeID( "Lyr " ), charIDToTypeID( "Ordn" ), charIDToTypeID( "Trgt" ) );
	desc.putReference( charIDToTypeID( "null" ), ref );
	desc.putEnumerated( charIDToTypeID( "Usng" ), charIDToTypeID( "ADSt" ), charIDToTypeID( method ) );
	try{
		executeAction( charIDToTypeID( "Algn" ), desc, DialogModes.NO );
	}catch(e){}
}

function selectNoLayers() {
	var descriptor = new ActionDescriptor();
	var reference = new ActionReference();
	reference.putEnumerated( stringIDToTypeID( "layer" ), stringIDToTypeID( "ordinal" ), stringIDToTypeID( "targetEnum" ));
	descriptor.putReference( charIDToTypeID( "null" ), reference );
	executeAction( stringIDToTypeID( "selectNoLayers" ), descriptor, DialogModes.NO );
}