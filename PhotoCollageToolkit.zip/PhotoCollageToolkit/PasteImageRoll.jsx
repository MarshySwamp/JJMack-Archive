/* ==========================================================
// 2012  John J. McAssey (JJMack) 
// ======================================================= */

// This script is supplied as is. It is provided as freeware. 
// The author accepts no liability for any problems arising from its use.

/* Help 
<javascriptresource>
<about>$$$/JavaScripts/PasteImageRoll/About=JJMack's PasteImageRoll^r^rCopyright 2012 Mouseprints.^r^rCreate a document for printing on roll paper^rcan also be used as a wall hanging when^rall selected images have the same orientation.^rImages will be rotated to match cell orientation</about>
<category>JJMack's Collage Script</category>
</javascriptresource>
*/

//Set Defaults here
var dfltRes = 300;	// default print DPI
var dfltCpys = 1;	// default image copies
var dfltPw  = 16;	// default roll paper width in inches
var dfltPl  = '';	// default roll paper length in feet. if set to null script will use 100 ft.
var dfltCw  = 4;	// default cell width in inches best if it divides paper with evenly.
var dfltCh  = 6;	// default cell height in inches
var dfltBw  = 0;	// default Border width in inches example .2 for 1/5 inch
var dfltGw  = 0;	// default Grout width in inches example .2 for 1/5 inch
var dfltRt  = true; // default Rotate image orientation for best fit
//End Defaults

var startDisplayDialogs = app.displayDialogs;
var startRulerUnits = app.preferences.rulerUnits;
app.displayDialogs = DialogModes.NO;
app.preferences.rulerUnits = Units.PIXELS; // tell ps to work with pixels

try {
	// begin dialog layout
	var RollPaperDialog = new Window('dialog');
	RollPaperDialog.text = 'Paste Image Roll';
	RollPaperDialog.frameLocation = [78, 100];
	RollPaperDialog.alignChildren = 'center';

	RollPaperDialog.PrintResPnl = RollPaperDialog.add('panel', [2, 2, 200, 56], 'Print Resolution');
		RollPaperDialog.PrintResPnl.add('statictext', [10, 16, 50, 48], 'DPI ');
		RollPaperDialog.PrintResPnl.docResEdt = RollPaperDialog.PrintResPnl.add('edittext', [50, 13, 90, 34], dfltRes, {name:'prtRes'});
		RollPaperDialog.PrintResPnl.docResEdt.helpTip = 'Image Resolution';
		RollPaperDialog.PrintResPnl.add('statictext', [96, 16, 140, 48], 'Copies ');
		RollPaperDialog.PrintResPnl.imgCpysEdt = RollPaperDialog.PrintResPnl.add('edittext', [140, 13, 175, 34], dfltCpys, {name:'imgCpys'});
		RollPaperDialog.PrintResPnl.imgCpysEdt.helpTip = 'Number of copies of selected Images';

	RollPaperDialog.PaperSizePnl = RollPaperDialog.add('panel', [2, 2, 200, 56], 'Roll Paper Size');
		RollPaperDialog.PaperSizePnl.add('statictext', [10, 16, 50, 48], 'Width ');
		RollPaperDialog.PaperSizePnl.aspectWidthEdt = RollPaperDialog.PaperSizePnl.add('edittext', [50, 13, 90, 34], dfltPw, {name:'pprWth'});
		RollPaperDialog.PaperSizePnl.aspectWidthEdt.helpTip = 'Roll width in inches';
		RollPaperDialog.PaperSizePnl.add('statictext', [96, 16, 140, 48], 'Length ');
		RollPaperDialog.PaperSizePnl.aspectHeightEdt = RollPaperDialog.PaperSizePnl.add('edittext', [140, 13, 175, 34], dfltPl, {name:'pprLnth'});
		RollPaperDialog.PaperSizePnl.aspectHeightEdt.helpTip = 'Remaing roll length in feet';

	RollPaperDialog.CellSizePnl = RollPaperDialog.add('panel', [2, 2, 200, 56], 'Tile Cell Size');
		RollPaperDialog.CellSizePnl.add('statictext', [10, 16, 50, 48], 'Width ');
		RollPaperDialog.CellSizePnl.aspectWidthEdt = RollPaperDialog.CellSizePnl.add('edittext', [50, 13, 90, 34], dfltCw, {name:'cllWth'});
		RollPaperDialog.CellSizePnl.aspectWidthEdt.helpTip = 'Width in inches';
		RollPaperDialog.CellSizePnl.add('statictext', [96, 16, 140, 48], 'Height ');
		RollPaperDialog.CellSizePnl.aspectHeightEdt = RollPaperDialog.CellSizePnl.add('edittext', [140, 13, 175, 34], dfltCh, {name:'cllHgt'});
		RollPaperDialog.CellSizePnl.aspectHeightEdt.helpTip = 'Height in inches';

	RollPaperDialog.GroutSizePnl = RollPaperDialog.add('panel', [2, 2, 200, 56], 'Grout Size');
		RollPaperDialog.GroutSizePnl.add('statictext', [10, 16, 50, 48], 'Border ');
		RollPaperDialog.GroutSizePnl.aspectWidthEdt = RollPaperDialog.GroutSizePnl.add('edittext', [50, 13, 90, 34], dfltBw, {name:'grtBdr'});
		RollPaperDialog.GroutSizePnl.aspectWidthEdt.helpTip = 'Width in inches';
		RollPaperDialog.GroutSizePnl.add('statictext', [96, 16, 140, 48], 'Grout ');
		RollPaperDialog.GroutSizePnl.aspectHeightEdt = RollPaperDialog.GroutSizePnl.add('edittext', [140, 13, 175, 34], dfltGw, {name:'grtWth'});
		RollPaperDialog.GroutSizePnl.aspectHeightEdt.helpTip = 'Height in inches';
		
	RollPaperDialog.rotateForBestFitPnl = RollPaperDialog.add('panel', [2, 2, 200, 56], 'Rotate Image For Best Fit');
		RollPaperDialog.rotateForBestFitPnl.add('checkbox',[14, 13, 190, 34],'Rotate Images', {name:'Rt'},);
		RollPaperDialog.rotateForBestFitPnl.Rt.value=dfltRt;
		RollPaperDialog.rotateForBestFitPnl.helpTip = 'Image Orintation to match Tile Orientation';
		
	var buttons = RollPaperDialog.add('group');
	buttons.orientation = 'row';
			var okBtn = buttons.add('button');
		okBtn.text = 'OK';
		okBtn.properties = {name: 'ok'};
			var cancelBtn = buttons.add('button');
		cancelBtn.text = 'Cancel';
		cancelBtn.properties = {name: 'cancel'};

		RollPaperDialog.onShow = function() {
			var ww = RollPaperDialog.bounds.width;  
			var hh = RollPaperDialog.bounds.height;  
			RollPaperDialog.bounds.x  = 78;  
			RollPaperDialog.bounds.y  = 100;  
			RollPaperDialog.bounds.width  = ww;  
			RollPaperDialog.bounds.height  = hh;  
		}

		// do not allow anything except for numbers 0-9
		RollPaperDialog.PrintResPnl.docResEdt.addEventListener ('keydown', NumericEditKeyboardHandler);
		RollPaperDialog.PrintResPnl.imgCpysEdt.addEventListener ('keydown', NumericEditKeyboardHandler);
		RollPaperDialog.PaperSizePnl.aspectWidthEdt.addEventListener ('keydown', DesmalEditKeyboardHandler);
		RollPaperDialog.PaperSizePnl.aspectHeightEdt.addEventListener ('keydown', DesmalEditKeyboardHandler);
		RollPaperDialog.CellSizePnl.aspectWidthEdt.addEventListener ('keydown', DesmalEditKeyboardHandler);
		RollPaperDialog.CellSizePnl.aspectHeightEdt.addEventListener ('keydown', DesmalEditKeyboardHandler);
		RollPaperDialog.GroutSizePnl.aspectWidthEdt.addEventListener ('keydown', DesmalEditKeyboardHandler);
		RollPaperDialog.GroutSizePnl.aspectHeightEdt.addEventListener ('keydown', DesmalEditKeyboardHandler);
		
	// display dialog and only continues on OK button press (OK = 1, Cancel = 2)
	if (RollPaperDialog.show() == 1) {
		//variables passed from user interface
		var res		= String(RollPaperDialog.PrintResPnl.prtRes.text); if (res=="") { res = dfltRes;} 
		var copies	= String(RollPaperDialog.PrintResPnl.imgCpys.text); if (copies=="") { copies = dfltCpys;}
		var pprwidth    = String(RollPaperDialog.PaperSizePnl.pprWth.text); if (pprwidth=="") { pprwidth = dfltPw;}
		var pprlength   = String(RollPaperDialog.PaperSizePnl.pprLnth.text); if (pprlength=='') { pprlength= 100; }
		var cellwidth   = String(RollPaperDialog.CellSizePnl.cllWth.text); if (cellwidth=="") { cellwidth = dfltCw;}
		var cellheight  = String(RollPaperDialog.CellSizePnl.cllHgt.text); if (cellheight=="") { cellheight = dfltCh;}
		var borderwidth = String(RollPaperDialog.GroutSizePnl.grtBdr.text); if (borderwidth=="") { borderwidth = dfltBw;}
		var groutwidth  = String(RollPaperDialog.GroutSizePnl.grtWth.text); if (groutwidth=="") { groutwidth = dfltGw;}
		
		if (RollPaperDialog.rotateForBestFitPnl.Rt.value) { rotateForBestFit = true}
		else {rotateForBestFit = false;}

		var maxpaperwidth=pprwidth*res;						// Printer Paper width in pixels inches*res  
		var maxpaperlnth=pprlength*12*res;					// Printer Paper Roll length in pixels
		var width=cellwidth*res;							// Document Cell width in pixels inches*res
		var height=cellheight*res;							// Document Cell height in pixels inches*res
		var cols=0;				// Document number of columns will be determined by script using paper width and cell width  
		var rows=0;				// Document rows will be determined by script using columns and # of images selected 

		var borderspace = borderwidth*res;					// border size
		var whitespace = groutwidth*res;					// inter image spacing

		if (width>maxpaperwidth) { throw "error1"; }
		cols=Math.round(((maxpaperwidth+whitespace-2*borderspace)/(width+whitespace))-.499); //round down
		if (height>maxpaperlnth) { throw "error2"; }
		var file = selectFile(true);  
  		if (file==null) { throw "error3"; }
		if (file.length<1) { throw "error3"; }
		rows=Math.round((file.length*copies/cols)+.499);	//round up
		if ((height+whitespace)*rows+2*borderspace>(maxpaperlnth+whitespace)) { throw "error4"; }
		var doc = app.documents.add((width+whitespace)*cols-whitespace+2*borderspace, (height+whitespace)*rows-whitespace+2*borderspace, res);
		app.togglePalettes();
		var currrow=0; var pasted=0; 
		
		startDate = (getDateTime());
		SDayTime = startDate.split(", ");
		var time1 = Number(timeString());		
		
		for (var i=0;i<file.length;i++) { 
			if (file[i] instanceof File && !file[i].name.match(/\.(nef|cr3|cr2|crw|dcs|raf|arw|orf|dng|psd|tif|tiff|jpg|jpe|jpeg|png|bmp|)$/i) ) continue; //next file if not matched
			//app.load(file[i]); 								// load it into a document
			open(File(file[i])); 							// Open a document
			var backFile= app.activeDocument;				// image document
			var imageName = backFile.name;					// image file name			
			if (rotateForBestFit) {
				if (backFile.width.value<backFile.height.value&&width>height ) { backFile.rotateCanvas(-90.0);  } // Rotate portraits
				if (backFile.height.value<backFile.width.value&&height>width ) { backFile.rotateCanvas(-90.0);  } // Rotate landscapes
				}
			if (backFile.width.value/backFile.height.value > width/height) { backFile.resizeImage(null, height, res, ResampleMethod.BICUBIC); } // wider
			else {backFile.resizeImage(width, null, res, ResampleMethod.BICUBIC);} // same aspect ratio or taller
			//flatten(); //handle layered images			// flatten active document incase its layered. Kills transparency
			backFile.artLayers.add();						// insure there are Layers to handle Transparency
			backFile.selection.selectAll();					// select all
			backFile.selection.copy(true); 					//copy merge resized image into clipboard
			backFile.close(SaveOptions.DONOTSAVECHANGES); 	//close image without saving changes
			for (var n=0;n<copies;n++) {					// number of copies				
				var x =pasted*(width+whitespace)+borderspace;
				var y =currrow*(height+whitespace)+borderspace;
				var selectedRegion = Array(Array(x,y), Array(x+width,y), Array(x+width,y+height), Array(x,y+height));
				doc.selection.select(selectedRegion);
				doc.paste(true); 							//paste image into masked layer your document
				doc.activeLayer.name=imageName;				//label layer with image file name
				doc.selection.select(selectedRegion);
				align('AdCH'); align('AdCV');
				doc.selection.deselect();
				pasted++
				if ( pasted==cols ) { pasted=0; currrow++; }
				}
			}
		app.togglePalettes();
		
		var time2 = Number(timeString());
		endDate = (getDateTime());
		EDayTime = endDate.split(", ");		

		var msg = "To paste in "  + file.length + " Image files" ;
		
		refresh();		
		alert("Start " +  SDayTime[1] + " on "+ SDayTime[0] + "\n"
			+ "Time  "
			//+ ((time2-time1)/1000 )+" Seconds "
			+((time2-time1)/60000 ).toPrecision(2)+" Minutes" 
			//+((time2-time1)/3600000 ).toPrecision(1)+" Hours" 
			+ "\nEnd   " + EDayTime[1]+ " on " + EDayTime[0]
			+ "\n" + msg
			);    
		
		}
	else {
		//alert('Operation Canceled.');
		}
	// Return the app preferences
	app.preferences.rulerUnits = startRulerUnits;
	app.displayDialogs = startDisplayDialogs;
	}
catch(err){
	// Return the app preferences
	app.preferences.rulerUnits = startRulerUnits;
	app.displayDialogs = startDisplayDialogs;
	if (err=="error1") {alert("Paper width exceeded reduce the cell width");}
	else if (err=="error2") {alert("Paper roll length exceeded reduce cell height");}
	else if (err=="error3") {alert("No Images Selected");}
	else if (err=="error4") {alert("Paper roll length exceeded try selecting fewer images or reducing cell height");}
	// Lot's of things can go wrong, Give a generic alert and see if they want the details
	else if ( confirm("Sorry, something major happened and I can't continue! Would you like to see more info?" ) ) { alert(err + ': on line ' + err.line ); }
	}

// -----------------------------------------
// flatten Image
// -----------------------------------------
function flatten() {
	try{
		executeAction( charIDToTypeID( "FltI" ), undefined, DialogModes.NO );
	}catch(e){}
}

// -----------------------------------------
// Align Layers to selection
// -----------------------------------------
function align(method) {
	var desc = new ActionDescriptor();
	var ref = new ActionReference();
	ref.putEnumerated( charIDToTypeID( "Lyr " ), charIDToTypeID( "Ordn" ), charIDToTypeID( "Trgt" ) );
	desc.putReference( charIDToTypeID( "null" ), ref );
	desc.putEnumerated( charIDToTypeID( "Usng" ), charIDToTypeID( "ADSt" ), charIDToTypeID( method ) );
	try{
		executeAction( charIDToTypeID( "Algn" ), desc, DialogModes.NO );
	}catch(e){}
}

///////////////////////////////////////////////////////////////////////////////
// Function: NumericEditKeyboardHandler
// Usage: Do not allow anything except for numbers 0-9
// Input: ScriptUI keydown event
// Return: <nothing> key is rejected and beep is sounded if invalid
///////////////////////////////////////////////////////////////////////////////
function NumericEditKeyboardHandler (event) {

    try {

        var keyIsOK = KeyIsNumeric (event) ||
					  KeyIsDelete (event) ||
					  KeyIsLRArrow (event) ||
					  KeyIsTabEnterEscape (event);

        if (! keyIsOK) {
            //    Bad input: tell ScriptUI not to accept the keydown event
            event.preventDefault();

            /*    Notify user of invalid input: make sure NOT
			       to put up an alert dialog or do anything which
		                 requires user interaction, because that
		                 interferes with preventing the 'default'
		                 action for the keydown event */
            app.beep();
        }
    }
    catch (e) {
        ; // alert ("Ack! bug in NumericEditKeyboardHandler: " + e);
    }
}

function DesmalEditKeyboardHandler (event) {

    try {

        var keyIsOK = KeyIsNumeric (event) ||
					  KeyIsPeriod (event) ||
					  KeyIsDelete (event) ||
					  KeyIsLRArrow (event) ||
					  KeyIsTabEnterEscape (event);

        if (! keyIsOK) {
            //    Bad input: tell ScriptUI not to accept the keydown event
            event.preventDefault();

            /*    Notify user of invalid input: make sure NOT
			       to put up an alert dialog or do anything which
		                 requires user interaction, because that
		                 interferes with preventing the 'default'
		                 action for the keydown event */
            app.beep();
        }
    }
    catch (e) {
        ; // alert ("Ack! bug in NumericEditKeyboardHandler: " + e);
    }
}

//    key identifier functions
function KeyHasModifier (event) {
    return event.shiftKey || event.ctrlKey || event.altKey || event.metaKey;
}

function KeyIsNumeric (event) {
    return  (event.keyName >= '0') && (event.keyName <= '9') && ! KeyHasModifier (event);
}

function KeyIsPeriod (event) {
    return  (event.keyName == 'Period') && ! KeyHasModifier (event);
}


function KeyIsDelete (event) {
    //    Shift-delete is ok
    return ((event.keyName == 'Backspace') || (event.keyName == 'Delete')) && ! (event.ctrlKey);
}

function KeyIsLRArrow (event) {
    return ((event.keyName == 'Left') || (event.keyName == 'Right')) && ! (event.altKey || event.metaKey);
}

function KeyIsTabEnterEscape (event) {
    return event.keyName == 'Tab' || event.keyName == 'Enter' || event.keyName == 'Escape';
}
function selectFile (multi) {   
	if (multi == true) {var theString = "please select files"}   
	else {var theString = "please select one file"};   
	if ($.os.search(/windows/i) != -1) {var theFiles = File.openDialog (theString, '*.nef;*.cr3;*.cr2;*.crw;*.dcs;*.raf;*.arw;*.orf;*.dng;*.psd;*.psdt;*.tif;*.tiff;*.jpg;*.jpe;*.jpeg;*.png;*.bmp', multi)}   
	else {var theFiles = File.openDialog (theString, getFiles, multi)};   
	////// filter files  for mac //////   
	function getFiles (theFile) {   
		if (theFile.name.match(/\.(nef|cr3|cr2|crw|dcs|raf|arw|orf|dng|psd|tif|tiff|jpg|jpe|jpeg|png|bmp)$/i) || theFile.constructor.name == "Folder") {  
			return true   
			};   
	};   
	return theFiles   
};	

// Function for returning current date and time
function getDateTime() {
    var date = new Date();
    var dateTime = "";
    if ((date.getMonth() + 1) < 10) { dateTime += "0" + (date.getMonth() + 1) + "/"; }
	else { dateTime += (date.getMonth() + 1) + "/"; }
    if (date.getDate() < 10) { dateTime += "0" + date.getDate() + "/"; }
	else { dateTime += date.getDate() + "/"; }
    dateTime += date.getFullYear() + ", ";
    if (date.getHours() < 10) { dateTime += "0" + date.getHours() + ":"; }
	else { dateTime += date.getHours() + ":"; }
    if (date.getMinutes() < 10) { dateTime += "0" + date.getMinutes() + ":"; } 
	else { dateTime += date.getMinutes() + ":"; }
    if (date.getSeconds() < 10) { dateTime += "0" + date.getSeconds(); }
	else { dateTime += date.getSeconds(); }
    return dateTime;
}

function timeString () {
	var now = new Date();
	return now.getTime()
};	