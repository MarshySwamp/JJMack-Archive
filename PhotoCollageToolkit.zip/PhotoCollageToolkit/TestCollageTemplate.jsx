/* ==========================================================
// 2010  John J. McAssey (JJMack)
// ======================================================= */

// This script is supplied as is. It is provided as freeware.
// The author accepts no liability for any problems arising from its use.

// Image files and Template Alpha Channel "Image 1" should have the same orientation matching Aspect
// ratio is even better.  This script will try to transform the placed Images to match the Image 1 Alpha channel as
// best as it can and even try to handle orientation miss matches.

/* Help Category note tag menu can be used to place script in automate menu
<javascriptresource>
<about>$$$/JavaScripts/TestCollageTemplate/About=JJMack's Test Collage Template.^r^rCopyright 2010 Mouseprints.^r^rTest Populate the Photo Collage Template being made with Images^rThis script has no Dialog</about>
<category>JJMack's Collage Script</category>
</javascriptresource>
*/

// enable double-clicking from Mac Finder or Windows Explorer
#target photoshop // this command only works in Photoshop CS2 and higher

// bring application forward for double-click events
app.bringToFront();
// ensure at least one document open
if (!documents.length) alert('There are no documents open.', 'No Document');
else {
	main(); // at least one document exists proceed
}
/////////////////////////////////////////////////////////////////////////////////////////
function main() {
	// declare Global variables
	//////////////////////////////////
	//       SET-UP Preferences	//       
	//////////////////////////////////
	//@include "PCTpreferences.jsx"
	cTID = function(s) { return app.charIDToTypeID(s); };
	sTID = function(s) { return app.stringIDToTypeID(s); };

	// Save the current preferences
	var startRulerUnits = app.preferences.rulerUnits;
	var startTypeUnits = app.preferences.typeUnits;
	var startDisplayDialogs = app.displayDialogs;

	// Set Photoshop to use pixels and display no dialogs
	app.displayDialogs = DialogModes.NO;
	app.preferences.rulerUnits = Units.PIXELS;
	app.preferences.typeUnits = TypeUnits.PIXELS;

	var textStyle = textStyleList[Number(textStyleDefault)];
	var imageStyle = imageStyleList[Number(imageStyleDefault)];

	//open(File(templateFile));
	var doc = activeDocument;
	var Name='';
	var saveFile ='';
	//var templateName = activeDocument.name.replace(/\.[^\.]+$/, '');
	// Isolate Tenplate Name
	var templateName =  decodeURI(templateFile).replace(/\.[^\.]+$/, '');	// strip the extension off
	var templateName =  templateName.substr(templateName.lastIndexOf("\\")+1);

	var layers = activeDocument.layers;
	activeDocument.activeLayer = layers[layers.length-1];						// Target Bottom Layer
	if ( !activeDocument.activeLayer.isBackgroundLayer ) {
		alert("Selected Template file does not have the Required Photoshop Background Layer");
	} else { 											// Has Background
		var abort = false;
		// ======Load Image 1 Selection===============================
		var idsetd = charIDToTypeID( "setd" );
		    var desc2 = new ActionDescriptor();
		    var idnull = charIDToTypeID( "null" );
		        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
		        var idfsel = charIDToTypeID( "fsel" );
		        ref1.putProperty( idChnl, idfsel );
		    desc2.putReference( idnull, ref1 );
		    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
		        var idChnl = charIDToTypeID( "Chnl" );
		        ref2.putName( idChnl, "Image 1" );
		    desc2.putReference( idT, ref2 );
		try{
			executeAction( idsetd, desc2, DialogModes.NO );
		}catch(e){
			alert("Selected Template file does not have the Required Image 1 Alpha Channel");
			var abort = true
		}

		var collageNumber = 1;
		var imageNumber = 1;
		var numberOfImages = getAlphaImageChannels()
		prefixlist = new Array();
		//alert("numberOfImages = " + numberOfImages );
		fileList = new Array();

		if (!abort) { 									// Create Collage
			activeDocument.selection.deselect();

			var docWidth =  app.activeDocument.width;
			var docHeight = app.activeDocument.height;
			var docResolution = app.activeDocument.resolution;

			WorkOnDupe();								// Work on duplicate of template
			//doAction("Set View for Place", "Actions for Scripts");			// Set View for Place
			SetViewforPlace()
			//activeDocument.activeLayer = layers[layers.length-1];			// Target Background Layer
			//makeLayer();								// New empty Layer
			//app.activeDocument.activeLayer.name = "Image Lid";			// Name Layer

			// Loop Image File Start
			for (var i = 1; i < numberOfImages + 1; i++) {

				var layers = activeDocument.layers;
				activeDocument.activeLayer = layers[layers.length-1-imageNumber+1];	 // Target Background Layer or last placed image

				makeLayer();							// Make Layer
				makeLayer();							// Make Layer
				fillBlack();							// Fill with Black
				loadAlpha("Image " + imageNumber);				// Loade Image Alpha Channel for Mask
				deleteSelection();						// Delete image area
				app.activeDocument.activeLayer.fillOpacity = 65;		// set opacity 65%
				layerBackward();						// Select Layer Backwards
				fillColor();							// Fill Image area with color
				activeDocument.selection.deselect();				// deselect
				//doAction("Interactive Place", "Actions for Scripts");		// Place in Image
				//InteractivePlace()
				//fileList[i] = app.activeDocument.activeLayer.name;
				//fileList[i] = File.openDialog("Select Image" , "Select:*.nef;*.cr3;*.cr2;*.crw;*.dcs;*.raf;*.arw;*.orf;*.dng;*.psd;*.psdt;*.tif;*.tiff;*.jpg;*.jpe;*.jpeg;*.png;*.bmp");
				var dir = Folder(imagePath);
				app.refresh();
				fileList[i] = dir.openDlg("Select Image" , "Select:*.nef;*.cr3;*.cr2;*.crw;*.dcs;*.raf;*.arw;*.orf;*.dng;*.psd;*.psdt;*.tif;*.tiff;*.jpg;*.jpe;*.jpeg;*.png;*.bmp");
				if ( fileList[i] == null ) {					// User canceled
					i = numberOfImages + 1;
					deleteLayer();						// Delete Layer
					layerForward();						// Select Layer Forward
					deleteLayer();						// Delete Layer
					alert("Image Selection Canceled");
				}
				else {
					placeImage(fileList[i]);

					// resize smart object layer to just cover canvas area aspect ratio and size
					// Get Smart Object current width and height
					var LB = activeDocument.activeLayer.bounds;
					var LWidth = (LB[2].value) - (LB[0].value);
					var LHeight = (LB[3].value) - (LB[1].value);	

					// Get Alpha Channel's width and height Selection Bounds did not work???
					makeLayer();						// Make Temp Work Layer
					loadAlpha("Image " + imageNumber );			// Load Image Alpha Channel
					fillBlack();							
					activeDocument.selection.invert();			// Inverse
					// If image size equals canvas size no pixels neill be selected clear will fail
					try{
						activeDocument.selection.clear();		// One clear did not work
						activeDocument.selection.clear();		// Two did the trick
					}catch(e){}
					activeDocument.selection.deselect();			// Deselect
					var SB = activeDocument.activeLayer.bounds;		// Get the bounds of the work layer
					var SWidth = (SB[2].value) - (SB[0].value);		// Area width
					var SHeight = (SB[3].value) - (SB[1].value);		// Area height
					activeDocument.activeLayer.remove();			// Remove Work layer

					var userResampleMethod = app.preferences.interpolation;	// Save interpolation settings
					app.preferences.interpolation = ResampleMethod.BICUBIC;	// resample interpolation bicubic	

					if (LWidth/LHeight<SWidth/SHeight) { // Smart Object layer Aspect Ratio less the Canvas area Aspect Ratio 
						var percentageChange = ((SWidth/LWidth)*100);  // Resize to canvas area width		
						activeDocument.activeLayer.resize(percentageChange,percentageChange,AnchorPosition.MIDDLECENTER);
						}
					else { 
						var percentageChange = ((SHeight/LHeight)*100); // resize to canvas area height			
						activeDocument.activeLayer.resize(percentageChange,percentageChange,AnchorPosition.MIDDLECENTER);
						}

					app.preferences.interpolation = userResampleMethod;	// Reset interpolation setting

					// Load Alpha Channel as a selection and align image to it
					loadAlpha("Image " + imageNumber);
					//align('AdTp');
					//align('AdLf');
					align('AdCV');
					align('AdCH');
					activeDocument.selection.deselect();
					try{
						//doAction("Interactive Transform", "Actions for Scripts"); // Let the user have the final word
						InteractiveTransform()
					//}catch(e){alert("Image Transform Canceled");}	
					}catch(e){}	
					// Add Layer mask using Alpha channel Image1
					loadAlpha("Image " + imageNumber);				// Loade Image Alpha Channel for Mask
					//linkedlayerMask();						// Add inked Layer Mask	
					layerMask();							// Add Layer Mask	
					// Add Photo Collage Layer Style to image layer
					addStyle(imageStyle);
					layerBackward();						// Select Layer Backwards
					deleteLayer();							// Delete Layer
					layerForward();							// Select Layer Forward
					layerForward();							// Select Layer Forward
					deleteLayer();							// Delete Layer
	
					// Isolate Image name
					var Name =  decodeURI(fileList[i]).replace(/\.[^\.]+$/, '');	// strip the extension off
					var imagePath = "";
					while (Name.indexOf("/") != -1 ) {				// Strip Path
                                                imagePath= imagePath + Name.substr(0, Name.indexOf("/") + 1);
						Name = Name.substr(Name.indexOf("/") + 1 ,);		
						}
						if (Name.indexOf("#") != -1 ) {					// Strip any prefix sequence number off	
						prefixlist[imageNumber - 1] = Name.substr(0,Name.indexOf("#") );
						Name = Name.substr(Name.indexOf("#") + 1 ,);		
					}

					// Add Filename Text if called for
					if ( 1==1 ) {
						stampFilename(textFont,textSizeFactor,textColor,Name);
						loadAlpha("Image " + imageNumber);	

						//var Position = 5;
						var Position = Number(textLocationDefault + 1);
						switch (Position){
						case 1 : align('AdLf'); align('AdTp'); break;
						case 2 : align('AdCH'); align('AdTp'); break;
						case 3 : align('AdRg'); align('AdTp'); break;
						case 4 : align('AdLf'); align('AdCV'); break;
						case 5 : align('AdCH'); align('AdCV'); activeDocument.selection.deselect(); activeDocument.activeLayer.rotate(textAngle); break;
						case 6 : align('AdRg'); align('AdCV'); break;
						case 7 : align('AdLf'); align('AdBt'); break;
						case 8 : align('AdCH'); align('AdBt'); break;
						case 9 : align('AdRg'); align('AdBt'); break;
						default : break;
						}

						activeDocument.selection.deselect();
						// Add text Layer's layer style
						addStyle(textStyle);
						try{
							//doAction("Interactive Transform", "Actions for Scripts"); // Let user have last say
							InteractiveTransform()
						}catch(e){}

						// could add code to do something with the image prefix info if it exists in prefixlist
						if ( prefixlist[imageNumber -1] != undefined ) {}

					}
					imageNumber = imageNumber + 1;
				}
			} // Image
		} // end create collage
		//doAction("Set View Fit on Screen", "Actions for Scripts");				// Set View for Place
		SetViewFitonScreen()
		//alert("Test ended after inserting " + (imageNumber-1) + " images");
	} // end has Background
	// Return the app preferences
	app.preferences.rulerUnits = startRulerUnits;
	app.preferences.typeUnits = startTypeUnits;
	app.displayDialogs = startDisplayDialogs;
} // end main

//////////////////////////////////////////////////////////////////////////////////
//				The end						//
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
//			Helper Functions					//
//////////////////////////////////////////////////////////////////////////////////

function placeImage(file) {
	/*
        // Insure Photoshop Preference is not resize paste place
	var idsetd = charIDToTypeID( "setd" );
	    var desc7 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref4 = new ActionReference();
	        var idPrpr = charIDToTypeID( "Prpr" );
	        var idGnrP = charIDToTypeID( "GnrP" );
	        ref4.putProperty( idPrpr, idGnrP );
	        var idcapp = charIDToTypeID( "capp" );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref4.putEnumerated( idcapp, idOrdn, idTrgt );
	    desc7.putReference( idnull, ref4 );
	    var idT = charIDToTypeID( "T   " );
	        var desc8 = new ActionDescriptor();
	        var idresizePastePlace = stringIDToTypeID( "resizePastePlace" );
	        desc8.putBoolean( idresizePastePlace, false );
	    var idGnrP = charIDToTypeID( "GnrP" );
	    desc7.putObject( idT, idGnrP, desc8 );
	executeAction( idsetd, desc7, DialogModes.NO );
	*/

	// =======avoid bug in cs2 and maybe CS4 ==================================
	var idslct = charIDToTypeID( "slct" );
	    var desc5 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref3 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idRGB = charIDToTypeID( "RGB " );
	        ref3.putEnumerated( idChnl, idChnl, idRGB );
	    desc5.putReference( idnull, ref3 );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc5.putBoolean( idMkVs, false );
	executeAction( idslct, desc5, DialogModes.NO );

	// Place in the file
	var idPlc = charIDToTypeID( "Plc " );
	    var desc5 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	    desc5.putPath( idnull, new File( file ) );
	    var idFTcs = charIDToTypeID( "FTcs" );
	    var idQCSt = charIDToTypeID( "QCSt" );
	    var idQcsa = charIDToTypeID( "Qcsa" );
	    desc5.putEnumerated( idFTcs, idQCSt, idQcsa );
	    var idOfst = charIDToTypeID( "Ofst" );
	        var desc6 = new ActionDescriptor();
	        var idHrzn = charIDToTypeID( "Hrzn" );
	        var idPxl = charIDToTypeID( "#Pxl" );
	        desc6.putUnitDouble( idHrzn, idPxl, 0.000000 );
	        var idVrtc = charIDToTypeID( "Vrtc" );
	        var idPxl = charIDToTypeID( "#Pxl" );
	        desc6.putUnitDouble( idVrtc, idPxl, 0.000000 );
	    var idOfst = charIDToTypeID( "Ofst" );
	    desc5.putObject( idOfst, idOfst, desc6 );
	executeAction( idPlc, desc5, DialogModes.NO );

	// because can't get the scale of a smart object, reset to 100%
	activeDocument.activeLayer.resize(100 ,100,AnchorPosition.MIDDLECENTER);

	return app.activeDocument.activeLayer;
}

function stampFilename(textFont,sizeFactor,textColor,Name) {
        /* textX and TextY positions text placement 0 and 0 Top Left corner of image in pixels	*/
	var textX = 0;									
	var textY = 0;	
	/* END Variables hard coded */

	var txtWidth =  app.activeDocument.width * .90 ;				// 90% of Doc with
	var txtHeight = app.activeDocument.height * .90 ;				// 90% of doc height

	activeDocument.selection.deselect();						// make sure no active selection
	text_layer = activeDocument.artLayers.add();					// Add a Layer
	text_layer.name = Name ;							// Name Layer
	text_layer.kind = LayerKind.TEXT;						// Make Layer a Text Layer
	text_layer.textItem.color = textColor;						// set text layer color

	/* Do not set TextType to Pargarph so the layer can be aligned
 	text_layer.textItem.kind = TextType.PARAGRAPHTEXT;				// Set text layers text type
 	*/

	text_layer.textItem.font = textFont;						// set text font
	text_layer.blendMode = BlendMode.NORMAL						// blend mode
	text_layer.textItem.fauxBold = false;						// Bold
	text_layer.textItem.fauxItalic = false;						// Italic
	text_layer.textItem.underline = UnderlineType.UNDERLINEOFF;			// Underlibn
	text_layer.textItem.capitalization = TextCase.NORMAL;				// Case
	text_layer.textItem.antiAliasMethod = AntiAlias.SHARP;				// antiAlias

	/* Calulate font size to use for keep size same for landscape and portrait base on text area size */
	if (txtWidth >= txtHeight) {var fontSize = Math.round(txtHeight / (30 * sizeFactor));}
	else {var fontSize = Math.round(txtWidth / (30 * sizeFactor));}
	if (fontSize<10){fontSize=10};							// don't use Font size smaller then 10
	text_layer.textItem.size = fontSize;						// set text font Size

	text_layer.textItem.position = Array(textX, (textY + fontSize ));		// set text layers position in and down for Stamp add in fontsize

	// Do not set Text Area so so the layer can be aligned

	text_layer.textItem.contents = Name ;
}

function WorkOnDupe() {
	var idDplc = charIDToTypeID( "Dplc" );
	    var desc2 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref1 = new ActionReference();
	        var idDcmn = charIDToTypeID( "Dcmn" );
 	       var idOrdn = charIDToTypeID( "Ordn" );
 	       var idFrst = charIDToTypeID( "Frst" );
 	       ref1.putEnumerated( idDcmn, idOrdn, idFrst );
	    desc2.putReference( idnull, ref1 );
	executeAction( idDplc, desc2, DialogModes.NO );
}

function makeLayer(){
	var idMk = charIDToTypeID( "Mk  " );
	    var desc4 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref3 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        ref3.putClass( idLyr );
	    desc4.putReference( idnull, ref3 );
	executeAction( idMk, desc4, DialogModes.NO );
}


function layerBackward(){
	var idslct = charIDToTypeID( "slct" );
	    var desc9 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
 	       var ref6 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idBckw = charIDToTypeID( "Bckw" );
 	       ref6.putEnumerated( idLyr, idOrdn, idBckw );
	    desc9.putReference( idnull, ref6 );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc9.putBoolean( idMkVs, false );
	executeAction( idslct, desc9, DialogModes.NO );
}

function layerForward(){
	var idslct = charIDToTypeID( "slct" );
	    var desc26 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref19 = new ActionReference();
 	       var idLyr = charIDToTypeID( "Lyr " );
 	       var idOrdn = charIDToTypeID( "Ordn" );
	        var idFrwr = charIDToTypeID( "Frwr" );
	        ref19.putEnumerated( idLyr, idOrdn, idFrwr );
 	   desc26.putReference( idnull, ref19 );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc26.putBoolean( idMkVs, false );
	executeAction( idslct, desc26, DialogModes.NO );
}

function fillBlack(){
// ============Fill with Black==========================================
	var idFl = charIDToTypeID( "Fl  " );
 	   var desc11 = new ActionDescriptor();
	    var idUsng = charIDToTypeID( "Usng" );
	    var idFlCn = charIDToTypeID( "FlCn" );
  	  var idBlck = charIDToTypeID( "Blck" );
 	   desc11.putEnumerated( idUsng, idFlCn, idBlck );
	    var idOpct = charIDToTypeID( "Opct" );
	    var idPrc = charIDToTypeID( "#Prc" );
	    desc11.putUnitDouble( idOpct, idPrc, 100.000000 );
	    var idMd = charIDToTypeID( "Md  " );
	    var idBlnM = charIDToTypeID( "BlnM" );
	    var idNrml = charIDToTypeID( "Nrml" );
	    desc11.putEnumerated( idMd, idBlnM, idNrml );
	executeAction( idFl, desc11, DialogModes.NO );
}

function fillColor(){
	var idFl = charIDToTypeID( "Fl  " );
  	  var desc17 = new ActionDescriptor();
 	   var idUsng = charIDToTypeID( "Usng" );
 	   var idFlCn = charIDToTypeID( "FlCn" );
	    var idClr = charIDToTypeID( "Clr " );
	    desc17.putEnumerated( idUsng, idFlCn, idClr );
 	   var idClr = charIDToTypeID( "Clr " );
 	       var desc18 = new ActionDescriptor();
 	       var idH = charIDToTypeID( "H   " );
	        var idAng = charIDToTypeID( "#Ang" );
	        desc18.putUnitDouble( idH, idAng, 172.232666 );
	        var idStrt = charIDToTypeID( "Strt" );
	        desc18.putDouble( idStrt, 35.686275 );
	        var idBrgh = charIDToTypeID( "Brgh" );
	        desc18.putDouble( idBrgh, 93.725490 );
	    var idHSBC = charIDToTypeID( "HSBC" );
 	   desc17.putObject( idClr, idHSBC, desc18 );
	    var idOpct = charIDToTypeID( "Opct" );
	    var idPrc = charIDToTypeID( "#Prc" );
	    desc17.putUnitDouble( idOpct, idPrc, 100.000000 );
 	   var idMd = charIDToTypeID( "Md  " );
	    var idBlnM = charIDToTypeID( "BlnM" );
	    var idNrml = charIDToTypeID( "Nrml" );
	    desc17.putEnumerated( idMd, idBlnM, idNrml );
	executeAction( idFl, desc17, DialogModes.NO );
}

function deleteSelection(){
	var idDlt = charIDToTypeID( "Dlt " );
	executeAction( idDlt, undefined, DialogModes.NO );
}


function deleteLayer(){
	var idDlt = charIDToTypeID( "Dlt " );
  	  var desc25 = new ActionDescriptor();
   	 var idnull = charIDToTypeID( "null" );
    	    var ref18 = new ActionReference();
    	    var idLyr = charIDToTypeID( "Lyr " );
  	      var idOrdn = charIDToTypeID( "Ordn" );
  	      var idTrgt = charIDToTypeID( "Trgt" );
 	       ref18.putEnumerated( idLyr, idOrdn, idTrgt );
 	   desc25.putReference( idnull, ref18 );
	executeAction( idDlt, desc25, DialogModes.NO );
}

function addStyle(Style){
	var idASty = charIDToTypeID( "ASty" );
	    var desc20 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref3 = new ActionReference();
	        var idStyl = charIDToTypeID( "Styl" );
	        ref3.putName( idStyl, Style );
	    desc20.putReference( idnull, ref3 );
	    var idT = charIDToTypeID( "T   " );
	        var ref4 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref4.putEnumerated( idLyr, idOrdn, idTrgt );
	    desc20.putReference( idT, ref4 );
	try{
		executeAction( idASty, desc20, DialogModes.NO);
	}catch(e){}
}

function SaveAsJPEG(saveFile, jpegQuality){
	var doc = activeDocument;
	if (doc.bitsPerChannel != BitsPerChannelType.EIGHT) doc.bitsPerChannel = BitsPerChannelType.EIGHT;
	jpgSaveOptions = new JPEGSaveOptions();
	jpgSaveOptions.embedColorProfile = true;
	jpgSaveOptions.formatOptions = FormatOptions.STANDARDBASELINE;
	jpgSaveOptions.matte = MatteType.NONE;
	jpgSaveOptions.quality = jpegQuality;
	activeDocument.saveAs(File(saveFile+".jpg"), jpgSaveOptions, true,Extension.LOWERCASE);
}

function SaveAsPSD( inFileName, inEmbedICC ) {
	var psdSaveOptions = new PhotoshopSaveOptions();
	psdSaveOptions.embedColorProfile = inEmbedICC;
	app.activeDocument.saveAs( File( inFileName + ".psd" ), psdSaveOptions );
}

function SaveAsPDF( saveFile ) {
	var idsave = charIDToTypeID( "save" );
	    var desc2 = new ActionDescriptor();
	    var idAs = charIDToTypeID( "As  " );
	        var desc3 = new ActionDescriptor();
	        var idpdfPresetFilename = stringIDToTypeID( "pdfPresetFilename" );
	        desc3.putString( idpdfPresetFilename, "High Quality Print" );
	        var idpdfCompatibilityLevel = stringIDToTypeID( "pdfCompatibilityLevel" );
	        var idpdfCompatibilityLevel = stringIDToTypeID( "pdfCompatibilityLevel" );
	        var idpdfoneeight = stringIDToTypeID( "pdf18" );
	        desc3.putEnumerated( idpdfCompatibilityLevel, idpdfCompatibilityLevel, idpdfoneeight );
	        var idpdfCompressionType = stringIDToTypeID( "pdfCompressionType" );
	        desc3.putInteger( idpdfCompressionType, 7 );
	    var idPhtP = charIDToTypeID( "PhtP" );
	    desc2.putObject( idAs, idPhtP, desc3 );
	    var idIn = charIDToTypeID( "In  " );
	    desc2.putPath( idIn, new File( saveFile + ".pdf" ) );
	executeAction( idsave, desc2, DialogModes.NO );
}

function align(method) {
	var desc = new ActionDescriptor();
	var ref = new ActionReference();
	ref.putEnumerated( charIDToTypeID( "Lyr " ), charIDToTypeID( "Ordn" ), charIDToTypeID( "Trgt" ) );
	desc.putReference( charIDToTypeID( "null" ), ref );
	desc.putEnumerated( charIDToTypeID( "Usng" ), charIDToTypeID( "ADSt" ), charIDToTypeID( method ) );
	try{
		executeAction( charIDToTypeID( "Algn" ), desc, DialogModes.NO );
	}catch(e){}
}

function getAlphaImageChannels() {
	for (var n = 1; n < 999; n++) {
		// ======Load Image n Selection===============================
		var idsetd = charIDToTypeID( "setd" );
		    var desc2 = new ActionDescriptor();
		    var idnull = charIDToTypeID( "null" );
		        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
		        var idfsel = charIDToTypeID( "fsel" );
		        ref1.putProperty( idChnl, idfsel );
		    desc2.putReference( idnull, ref1 );
		    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
		        var idChnl = charIDToTypeID( "Chnl" );
		        ref2.putName( idChnl, "Image " + n );
		    desc2.putReference( idT, ref2 );
		try{
			executeAction( idsetd, desc2, DialogModes.NO );
		}catch(e){
			//alert ("n = " + n);
			return n - 1;
		}

	}
}


// ======Load Alpha Channel Selection===============================
function loadAlpha(channel) {
	var idsetd = charIDToTypeID( "setd" );
	    var desc2 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idfsel = charIDToTypeID( "fsel" );
	        ref1.putProperty( idChnl, idfsel );
	    desc2.putReference( idnull, ref1 );
	    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        ref2.putName( idChnl, channel );
	    desc2.putReference( idT, ref2 );
	executeAction( idsetd, desc2, DialogModes.NO );
}

// =======linked layer Mask========================================
function linkedlayerMask() {
	var idMk = charIDToTypeID( "Mk  " );
	    var desc3 = new ActionDescriptor();
	    var idNw = charIDToTypeID( "Nw  " );
	    var idChnl = charIDToTypeID( "Chnl" );
	    desc3.putClass( idNw, idChnl );
	    var idAt = charIDToTypeID( "At  " );
	        var ref3 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idMsk = charIDToTypeID( "Msk " );
	        ref3.putEnumerated( idChnl, idChnl, idMsk );
	    desc3.putReference( idAt, ref3 );
	    var idUsng = charIDToTypeID( "Usng" );
	    var idUsrM = charIDToTypeID( "UsrM" );
	    var idRvlS = charIDToTypeID( "RvlS" );
	    desc3.putEnumerated( idUsng, idUsrM, idRvlS );
	executeAction( idMk, desc3, DialogModes.NO );
}

// =======Un linked layer Mask========================================
function layerMask() {
	var idMk = charIDToTypeID( "Mk  " );
	    var desc3 = new ActionDescriptor();
	    var idNw = charIDToTypeID( "Nw  " );
	    var idChnl = charIDToTypeID( "Chnl" );
	    desc3.putClass( idNw, idChnl );
	    var idAt = charIDToTypeID( "At  " );
	        var ref3 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idMsk = charIDToTypeID( "Msk " );
	        ref3.putEnumerated( idChnl, idChnl, idMsk );
	    desc3.putReference( idAt, ref3 );
	    var idUsng = charIDToTypeID( "Usng" );
	    var idUsrM = charIDToTypeID( "UsrM" );
	    var idRvlS = charIDToTypeID( "RvlS" );
	    desc3.putEnumerated( idUsng, idUsrM, idRvlS );
	executeAction( idMk, desc3, DialogModes.NO );
	// =======================================================
	var idsetd = charIDToTypeID( "setd" );
	    var desc2 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref1 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref1.putEnumerated( idLyr, idOrdn, idTrgt );
	    desc2.putReference( idnull, ref1 );
	    var idT = charIDToTypeID( "T   " );
	        var desc3 = new ActionDescriptor();
	        var idUsrs = charIDToTypeID( "Usrs" );
	        desc3.putBoolean( idUsrs, false );
	    var idLyr = charIDToTypeID( "Lyr " );
	    desc2.putObject( idT, idLyr, desc3 );
	executeAction( idsetd, desc2, DialogModes.NO );
}

///////////////////////////////////////////////////////////////////////////////
// Function: initExportInfo
// Usage: create our default parameters
// Input: a new Object
// Return: a new object with params set to default
///////////////////////////////////////////////////////////////////////////////
function initExportInfo(exportInfo) {
    exportInfo.destination = new String("");
    exportInfo.fileNamePrefix = new String("untitled_");
    exportInfo.visibleOnly = false;
//    exportInfo.fileType = psdIndex;
    exportInfo.icc = true;
    exportInfo.jpegQuality = 8;
    exportInfo.psdMaxComp = true;
    exportInfo.tiffCompression = TIFFEncoding.NONE;
    exportInfo.tiffJpegQuality = 8;
    exportInfo.pdfEncoding = PDFEncoding.JPEG;
    exportInfo.pdfJpegQuality = 8;
    exportInfo.targaDepth = TargaBitsPerPixels.TWENTYFOUR;
    exportInfo.bmpDepth = BMPDepthType.TWENTYFOUR;

    try {
         exportInfo.destination = Folder(app.activeDocument.fullName.parent).fsName; // destination folder
        var tmp = app.activeDocument.fullName.name;
        exportInfo.fileNamePrefix = decodeURI(tmp.substring(0, tmp.indexOf("."))); // filename body part
    } catch(someError) {
        exportInfo.destination = new String("");
//        exportInfo.fileNamePrefix = app.activeDocument.name; // filename body part
    }
}

// Find the location where this script resides
function findScript() {
	var where = "";
	try {
		FORCEERROR = FORCERRROR;
	}
	catch(err) {
		// alert(err.fileName);
		// alert(File(err.fileName).exists);
		where = File(err.fileName);
	}
	return where;
}

// Function for returning current date and time

    function getDateTime() {
        var date = new Date();
        var dateTime = "";
        if ((date.getMonth() + 1) < 10) {
            dateTime += "0" + (date.getMonth() + 1) + "/";
        } else {
            dateTime += (date.getMonth() + 1) + "/";
        }
        if (date.getDate() < 10) {
            dateTime += "0" + date.getDate() + "/";
        } else {
            dateTime += date.getDate() + "/";
        }
        dateTime += date.getFullYear() + ", ";
        if (date.getHours() < 10) {
            dateTime += "0" + date.getHours() + ":";
        } else {
            dateTime += date.getHours() + ":";
        }
        if (date.getMinutes() < 10) {
            dateTime += "0" + date.getMinutes() + ":";
        } else {
            dateTime += date.getMinutes() + ":";
        }
        if (date.getSeconds() < 10) {
            dateTime += "0" + date.getSeconds();
        } else {
            dateTime += date.getSeconds();
        }
        return dateTime;
    }

// resetPrefs function for resetting the preferences
	function resetPrefs() {
		preferences.rulerUnits = startRulerUnits;
		preferences.typeUnits = startTypeUnits;
		displayDialogs = startDisplayDialogs;
	}

// CheckVersion
function CheckVersion() {
	var numberArray = version.split(".");
	if ( numberArray[0] < 9 ) {
		alert( "You must use Photoshop CS2 or later to run this script!" );
		throw( "You must use Photoshop CS2 or later to run this script!" );
	}
}

// load my params from the xml file on disk if it exists
// gParams["myoptionname"] = myoptionvalue
// I wrote a very simple xml parser, I'm sure it needs work
function LoadParamsFromDisk ( loadFile, params ) {
	// var params = new Array();
	if ( loadFile.exists ) {
		loadFile.open( "r" );
		var projectSpace = ReadHeader( loadFile );
		if ( projectSpace == GetScriptNameForXML() ) {
			while ( ! loadFile.eof ) {
				var starter = ReadHeader( loadFile );
				var data = ReadData( loadFile );
				var ender = ReadHeader( loadFile );
				if ( ( "/" + starter ) == ender ) {
					params[starter] = data;
				}
				// force boolean values to boolean types
				if ( data == "true" || data == "false" ) {
					params[starter] = data == "true";
				}
			}
		}
		loadFile.close();
		if ( params["version"] != gVersion ) {
			// do something here to fix version conflicts
			// this should do it
			params["version"] = gVersion;
		}
	}
	return params;
}

// save out my params, this is much easier
function SaveParamsToDisk ( saveFile, params ) {
	saveFile.encoding = "UTF8";
	saveFile.open( "w", "TEXT", "????" );
	// unicode signature, this is UTF16 but will convert to UTF8 "EF BB BF"
	saveFile.write("\uFEFF");
	var scriptNameForXML = GetScriptNameForXML();
	saveFile.writeln( "<" + scriptNameForXML + ">" );
	for ( var p in params ) {
		saveFile.writeln( "\t<" + p + ">" + params[p] + "</" + p + ">" );
	}
	saveFile.writeln( "</" + scriptNameForXML + ">" );
	saveFile.close();
}

// you can't save certain characters in xml, strip them here
// this list is not complete
function GetScriptNameForXML () {
	var scriptNameForXML = new String( gScriptName );
	var charsToStrip = Array( " ", "'", "." );
	for (var a = 0; a < charsToStrip.length; a++ )  {
		var nameArray = scriptNameForXML.split( charsToStrip[a] );
		scriptNameForXML = "";
		for ( var b = 0; b < nameArray.length; b++ ) {
			scriptNameForXML += nameArray[b];
		}
	}
	return scriptNameForXML;
}

// figure out what I call my params file
function GetDefaultParamsFile() {
	//var paramsFolder = new Folder( path + "/Presets/" + gScriptName );
	//var paramsFolder = new Folder( Folder.temp + "/JJMack's Scripts/" + gScriptName );
	var paramsFolder = new Folder( "~/Application Data/JJMack's Scripts/" + gScriptName );
	//alert("paramsFolder = " + paramsFolder );
	paramsFolder.create();
	return ( new File( paramsFolder + "/" + gScriptName + ".xml" ) );
}

// a very crude xml parser, this reads the "Tag" of the <Tag>Data</Tag>
function ReadHeader( inFile ) {
	var returnValue = "";
	if ( ! inFile.eof ) {
		var c = "";
		while ( c != "<" && ! inFile.eof ) {
			c = inFile.read( 1 );
		}
		while ( c != ">" && ! inFile.eof ) {
			c = inFile.read( 1 );
			if ( c != ">" ) {
				returnValue += c;
			}
		}
	} else {
		returnValue = "end of file";
	}
	return returnValue;
}

// very crude xml parser, this reads the "Data" of the <Tag>Data</Tag>
function ReadData( inFile ) {
	var returnValue = "";
	if ( ! inFile.eof ) {
		var c = "";
		while ( c != "<" && ! inFile.eof ) {
			c = inFile.read( 1 );
			if ( c != "<" ) {
				returnValue += c;
			}
		}
		inFile.seek( -1, 1 );
	}
	return returnValue;
}

// Actions converted with X's ActionFileToJavascript

//==================== Set View for Place ==============
function SetViewforPlace() {
  // Menu View>Fit On Screen
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('FtOn'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
  // Menu View>Zoom out
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('ZmOt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
  // Menu View>screen Mode Full Screen With Menubar
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), sTID("screenModeFullScreenWithMenubar"));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
};

//==================== Interactive Place ==============
function InteractivePlace() {
  // Menu File>Place
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('Plce'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
};

//==================== Interactive Transform ==============
function InteractiveTransform() {
  // Menu Edit>Free transform
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('FrTr'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
};

//==================== Set View Fit on Screen ==============
function SetViewFitonScreen() {
  // Menu View>screen Mode Standard
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), sTID("screenModeStandard"));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
  // Menu View>Fit on screen
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('FtOn'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
};
