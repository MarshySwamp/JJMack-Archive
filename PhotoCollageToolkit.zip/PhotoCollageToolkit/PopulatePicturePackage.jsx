/* ==========================================================
// 2010  John J. McAssey (JJMack)
// ======================================================= */

// This script is supplied as is. It is provided as freeware.
// The author accepts no liability for any problems arising from its use.

// Image files and Template Alpha Channel "Image 1" should have the same orientation matching Aspect
// ratio is even better.  This script will try to transform the placed Images to match the Image 1 Alpha channel as
// best as it can and even try to handle orientation miss matches.

/* Help Category note tag menu can be used to place script in automate menu
<javascriptresource>
<about>$$$/JavaScripts/PopulatePicturePackage/About=JJMack's Populate Picture Package.^r^rCopyright 2012 Mouseprints.^r^rPopulate Collage template as a Picture Package</about>
<category>JJMack's Collage Script</category>
</javascriptresource>
*/

// enable double-clicking from Mac Finder or Windows Explorer
#target photoshop // this command only works in Photoshop CS2 and higher

// bring application forward for double-click events
app.bringToFront();

//////////////////////////////////
//       SET-UP Preferences	//       
//////////////////////////////////
//@include "PCTpreferences.jsx"


cTID = function(s) { return app.charIDToTypeID(s); };
sTID = function(s) { return app.stringIDToTypeID(s); };

//

var gVersion = 1.0;

// a global variable for the title of the dialog
// this string will also be used for the preferences file I write to disk
// Photoshop Install Directory/Presets/Image Processor/Image Processor.xml for example

var gScriptName = "PopPpackage";


// remember the dialog modes
var saveDialogMode = app.displayDialogs;
app.displayDialogs = DialogModes.NO;

try {
	// make sure they are running Photoshop CS2
	CheckVersion();

}
// Lot's of things can go wrong, Give a generic alert and see if they want the details
catch(e) {
	if ( confirm("Sorry, something major happened and I can't continue! Would you like to see more info?" ) ) {
		alert(e);
	}
}

// Save the current preferences
var startRulerUnits = app.preferences.rulerUnits;
var startTypeUnits = app.preferences.typeUnits;
var startDisplayDialogs = app.displayDialogs;

// Set Photoshop to use pixels and display no dialogs
app.displayDialogs = DialogModes.NO;
app.preferences.rulerUnits = Units.PIXELS;
app.preferences.typeUnits = TypeUnits.PIXELS;

	
// Set the script location

var scriptLocation = findScript() + "0";

// Stuff I don't know much about
var strButtonSelect = localize("$$$/JavaScripts/ExportLayersToFiles/Select=Select...");
var strButtonBrowse = localize("$$$/JavaScripts/ExportLayersToFiles/Browse=Browse...");
var strAlertSpecifyTemplateFile = localize("$$$/JavaScripts/ExportLayersToFiles/SpecifyTemplateFile=Please specify a template file.");
var strAlertTemplateFileNotExist = localize("$$$/JavaScripts/ExportLayersToFiles/TemplateFileDoesNotExist=Template file does not exist.");
var strAlertSpecifyInputFolder = localize("$$$/JavaScripts/ExportLayersToFiles/SpecifyInputFolder=Please specify an input folder.");
var strAlertInputFolderNotExist = localize("$$$/JavaScripts/ExportLayersToFiles/InputFolderDoesNotExist=Input folder does not exist.");
var strAlertSpecifyDestination = localize("$$$/JavaScripts/ExportLayersToFiles/SpecifyDestination=Please specify an output folder.");
var strAlertDestinationNotExist = localize("$$$/JavaScripts/ExportLayersToFiles/DestionationDoesNotExist=Output folder does not exist.");

var exportInfo = new Object();
initExportInfo(exportInfo);										// ??????
	
// define the dialog	
// [left, top, right, bottom]
function createDialog(){

	// Create an empty dialog window near the upper left of the screen
	var dlg = new Window('dialog', 'PopPpackage');
	dlg.frameLocation = [78, 100];

	// Add a panel to hold title and 'message text' strings
	dlg.msgPn0 = dlg.add('panel', undefined, 'Template File');
	dlg.msgPn0.orientation = "column";
	dlg.msgPn0.alignChildren = 'Right';
	// Add a panel to hold title and 'message text' strings
	dlg.msgPn0.TemplateFile = dlg.msgPn0.add('group');
	dlg.msgPn0.TemplateFile.orientation = "row";
	dlg.msgPn0.etTemplateFile = dlg.msgPn0.add("edittext", undefined, exportInfo.destination.toString());
	dlg.msgPn0.etTemplateFile.preferredSize.width = 550;
	dlg.msgPn0.etTemplateFile.helpTip = "Choose a collage template to populate.";

	dlg.msgPn0.btnSelect = dlg.msgPn0.add("button", undefined, strButtonSelect);
	dlg.msgPn0.btnSelect.helpTip = "Select a collage template to populate.";
	dlg.msgPn0.btnSelect.onClick = function() {
		var dir = Folder(dlg.msgPn0.etTemplateFile.text.substr(0, dlg.msgPn0.etTemplateFile.text.lastIndexOf("\\")+1));
		if (!dir.exists) var dir =  Folder(templateFolder);
		dlg.selTemplateFile = dir.openDlg(dlg.msgPn0.etTemplateFile.text , "Select:*.psd;*.psdt;*.psb");
		if ( dlg.selTemplateFile != null ) {
	        dlg.msgPn0.etTemplateFile.text = dlg.selTemplateFile.fsName;
	    }
		//dlg.msgPn0.defaultElement.active = true;
	}

	// Add a panel to hold title and 'message text' strings
	
	dlg.msgPn2 = dlg.add('panel', undefined, 'Input Folder');
	dlg.msgPn2.orientation = "column";
	dlg.msgPn2.alignChildren = 'Right';

	dlg.msgPn2.InputFolder = dlg.msgPn2.add('group');
	dlg.msgPn2.InputFolder.orientation = "row";
	dlg.msgPn2.etInputFolder = dlg.msgPn2.add("edittext", undefined, exportInfo.destination.toString());
	dlg.msgPn2.etInputFolder.preferredSize.width = 550;
	dlg.msgPn2.etInputFolder.helpTip = "Choose a folder of images to process.";

	dlg.msgPn2.btnBrowse = dlg.msgPn2.add("button", undefined, strButtonBrowse);
	dlg.msgPn2.btnBrowse.helpTip = "Select a folder of images to process.";
	dlg.msgPn2.btnBrowse.onClick = function() {
		var defaultFolder = dlg.msgPn2.etInputFolder.text;
		var testFolder = new Folder(dlg.msgPn2.etInputFolder.text);
		if (!testFolder.exists) {
//			defaultFolder = "~";
			defaultFolder = imagePath;
		}
		// var selFolder = Folder.selectDialog(dlg.msgPn2.etInputFolder.text, defaultFolder);
		dlg.selInputFolder = Folder.selectDialog(dlg.msgPn2.etInputFolder.text, defaultFolder);
		if ( dlg.selInputFolder != null ) {
	        dlg.msgPn2.etInputFolder.text = dlg.selInputFolder.fsName;
	    }
		//dlg.msgPn2.defaultElement.active = true;
	}
	/*
	// Add a panel to hold title and 'message text' strings
	dlg.msgPn3 = dlg.add('panel', undefined, 'Output Folder');
	dlg.msgPn3.orientation = "column";
	dlg.msgPn3.alignChildren = 'Right';

	dlg.msgPn3.Destination = dlg.msgPn3.add('group');
	dlg.msgPn3.Destination.orientation = "row";
	dlg.msgPn3.etDestination = dlg.msgPn3.add("edittext", undefined, exportInfo.destination.toString());
	dlg.msgPn3.etDestination.preferredSize.width = 550;
	dlg.msgPn3.etDestination.helpTip = "Choose a folder to export your collages to.";

	dlg.msgPn3.btnBrowse = dlg.msgPn3.add("button", undefined, strButtonBrowse);
	dlg.msgPn3.btnBrowse.helpTip = "Select a folder to export your collages to.";
	dlg.msgPn3.btnBrowse.onClick = function() {
		var defaultFolder = dlg.msgPn3.etDestination.text;
		var testFolder = new Folder(dlg.msgPn3.etDestination.text);
		if (!testFolder.exists) {
			defaultFolder = "~";
		}
		dlg.selOutputFolder = Folder.selectDialog(dlg.msgPn3.etDestination.text, defaultFolder);
		if ( dlg.selOutputFolder != null ) {
	        dlg.msgPn3.etDestination.text = dlg.selOutputFolder.fsName;
	    }
		//dlg.msgPn3.defaultElement.active = true;
	}
	*/	

	// Add a panel to hold title and 'message text' strings
	dlg.msgPnl = dlg.add('panel', undefined, 'Options');
	dlg.msgPnl.orientation = "column";
	dlg.msgPnl.alignChildren = 'right';

	//dlg.msgPnl.StampFilename = dlg.msgPnl.add('group');
	//dlg.msgPnl.StampFilename.orientation = "row";
	//dlg.msgPnl.StampFilename.alignment='left';
	//dlg.msgPnl.StampFilename.st = dlg.msgPnl.StampFilename.add('checkbox', undefined, 'Stamp File Name on Collage   OR');
	//dlg.msgPnl.StampFilename.helpTip = "Stamp Filename on Collage.";

	dlg.msgPnl.StampImage = dlg.msgPnl.add('group');
	dlg.msgPnl.StampImage.orientation = "row";
	dlg.msgPnl.StampImage.alignment='left';
	dlg.msgPnl.StampImage.st = dlg.msgPnl.StampImage.add('checkbox', undefined, 'Stamp Filename on Image');
	dlg.msgPnl.StampImage.helpTip = "Stamp Filename on Image.";

	dlg.msgPnl.grp5a =dlg.msgPnl.add('group');
	dlg.msgPnl.grp5a.orientation='row';
	dlg.msgPnl.grp5a.alignment='fill';
	dlg.msgPnl.grp5a.st1 = dlg.msgPnl.grp5a.add('statictext',undefined,'Name Stamp Text  Location:');
	var position =['Top Left','Top Center','Top Right','Center Left','Center','Center Right','Bottom Left','Bottom Center','Bottom Right'];
	dlg.msgPnl.grp5a.dd1 = dlg.msgPnl.grp5a.add('dropdownlist',undefined,position);
	dlg.msgPnl.grp5a.dd1.selection=textLocationDefault;

	dlg.msgPnl.grp6a =dlg.msgPnl.add('group');
	dlg.msgPnl.grp6a.orientation='row';
	dlg.msgPnl.grp6a.alignment='fill';
	dlg.msgPnl.grp6a.st1 = dlg.msgPnl.grp6a.add('statictext',undefined,'Font');
	fontlist = new Array();
	psfontlist = new Array();
	for (var i=0,len=app.fonts.length;i<len;i++) {
		//fontlist[i] =  app.fonts[i].name;
		try { 
			if ( app.fonts[i].name!=app.fonts[i+1].name &&  app.fonts[i].name.indexOf("Acumin") == -1) {
				fontlist.push(app.fonts[i].name);
				psfontlist.push(app.fonts[i].postScriptName);
				}
			}
		catch(e) { 
			if ( app.fonts[i].name.indexOf("Acumin") == -1) {}
				fontlist.push(app.fonts[i].name);
				psfontlist.push(app.fonts[i].postScriptName);
			}
		}
	dlg.msgPnl.grp6a.dd1 = dlg.msgPnl.grp6a.add('dropdownlist',undefined,fontlist);
	dlg.msgPnl.grp6a.dd1.selection=1;

	dlg.msgPnl.grp7a =dlg.msgPnl.add('group');
	dlg.msgPnl.grp7a.orientation='row';
	dlg.msgPnl.grp7a.alignment='fill';
	dlg.msgPnl.grp7a.st1 = dlg.msgPnl.grp7a.add('statictext',undefined,'Text Layer Style:  ');
	dlg.msgPnl.grp7a.dd1 = dlg.msgPnl.grp7a.add('dropdownlist',undefined,textStyleList);
	dlg.msgPnl.grp7a.dd1.preferredSize.width = 160;
	dlg.msgPnl.grp7a.dd1.selection=textStyleDefault;

	dlg.msgPnl.grp8a =dlg.msgPnl.add('group');
	dlg.msgPnl.grp8a.orientation='row';
	dlg.msgPnl.grp8a.alignment='fill';
	dlg.msgPnl.grp8a.st1 = dlg.msgPnl.grp8a.add('statictext',undefined,'Image Layer Style:');
	dlg.msgPnl.grp8a.dd1 = dlg.msgPnl.grp8a.add('dropdownlist',undefined,imageStyleList);
	dlg.msgPnl.grp8a.dd1.preferredSize.width = 160;
	dlg.msgPnl.grp8a.dd1.selection=imageStyleDefault;

	/*
	dlg.msgPnl.SavePDFfile = dlg.msgPnl.add('group');
	dlg.msgPnl.SavePDFfile.orientation = "row";
	dlg.msgPnl.SavePDFfile.alignment='left';
	dlg.msgPnl.SavePDFfile.st = dlg.msgPnl.SavePDFfile.add('checkbox', undefined, 'Save PDF file');
	dlg.msgPnl.SavePDFfile.helpTip = "Save a PDF file instead of a PSD file.";

	dlg.msgPnl.SaveJPGfile = dlg.msgPnl.add('group');
	dlg.msgPnl.SaveJPGfile.orientation = "row";
	dlg.msgPnl.SaveJPGfile.alignment='left';
	dlg.msgPnl.SaveJPGfile.st = dlg.msgPnl.SaveJPGfile.add('checkbox', undefined, 'Save JPG file');
	dlg.msgPnl.SaveJPGfile.helpTip = "Save a flat Jpeg file as well.";
	*/

	// Add a panel with buttons to test parameters and
	dlg.buttonPanel = dlg.add('panel', undefined);
	dlg.buttonPanel.orientation = "row";
	dlg.buttonPanel.cancelBtn = dlg.buttonPanel.add ('button', undefined,'Cancel');
	dlg.buttonPanel.helpBtn = dlg.buttonPanel.add ('button', undefined,'Help');
	dlg.buttonPanel.runBtn = dlg.buttonPanel.add ('button', undefined,'Create Collage');

	return dlg;
	}

	var params = new Array();
	params['TemplateFile'] = "";
	
	params['InputFolder'] = "";
	/*
	params['OutputFolder'] = "";
	*/
	params['TextLocationNumber'] = textLocationDefault;
	params['FontNumber'] = "1";
	params['FontStyleNumber'] = textStyleDefault;
	params['ImageStyleNumber'] = imageStyleDefault;
	params['SavePDF'] = "";

	LoadParamsFromDisk( GetDefaultParamsFile(), params );

        function initializeDialog (PopPpackage){
		with(PopPpackage) {

		msgPn0.etTemplateFile.text = params['TemplateFile'];
		
		msgPn2.etInputFolder.text = params['InputFolder'];
		/*
		msgPn3.etDestination.text = params['OutputFolder'];
		*/
		msgPnl.grp5a.dd1.selection = params['TextLocationNumber'];
		msgPnl.grp6a.dd1.selection = params['FontNumber'];
		msgPnl.grp7a.dd1.selection = params['FontStyleNumber'];
		msgPnl.grp8a.dd1.selection = params['ImageStyleNumber']

		// PopPpackage
		// checking for valid settings
		buttonPanel.runBtn.onClick = function() {

			
			// check if the template setting is proper
			var tmpltfld = PopPpackage.msgPn0.etTemplateFile.text;
			if (tmpltfld.length == 0) {
				alert(strAlertSpecifyTemplateFile);
				return;
			}
			var testFile = new File(tmpltfld);
			if (!testFile.exists) {
				alert(strAlertTemplateFileNotExist);
				return;
			}

			
			var inptfld = PopPpackage.msgPn2.etInputFolder.text;
			if (inptfld.length == 0) {
				alert(strAlertSpecifyInputFolder);
				return;
			}
			var testFolder = new Folder(inptfld);
			if (!testFolder.exists) {
				alert(strAlertInputFolderNotExist);
				return;
			}
			/*
			// check if the output folder setting is proper
			var destination = PopPpackage.msgPn3.etDestination.text;
			if (destination.length == 0) {
				alert(strAlertSpecifyDestination);
				return;
			}
			var testFolder = new Folder(destination);
			if (!testFolder.exists) {
				alert(strAlertDestinationNotExist);
				return;
			}

			// See if the input folder and the output folder are the same
			if (PopPpackage.msgPn3.etDestination.text == PopPpackage.msgPn2.etInputFolder.text) {
				var result = confirm("Are you sure you want your output folder to be the same as your input folder");
				if (result) {
				} else {
					return;
				}
			}
			*/

  	close( 1 ); // Close dialog window and process
	}

	buttonPanel.helpBtn.onClick = function() {help();}

	buttonPanel.cancelBtn.onClick = function() {close( 2 );}
	}
} // end createDialog

function runDialog(PopPpackage){
	// Warn the user if they have an open document and exit the script with return
	//if (documents.length > 0){
	//	alert ("This script requires that there are no open documents to run.");
	//return;
	//}		
	PopPpackage.onShow = function() {
		var ww = PopPpackage.bounds.width;  
		var hh = PopPpackage.bounds.height;  
		PopPpackage.bounds.x  = 78;  
		PopPpackage.bounds.y  = 100;  
		PopPpackage.bounds.width  = ww;  
		PopPpackage.bounds.height  = hh;  
		}
	return PopPpackage.show()
}

//=====================Start=====================================================
		
var PopPpackage = createDialog()	
initializeDialog(PopPpackage)

if (runDialog(PopPpackage) == 1){
	// transfer values from the dialog to my internal params
	params['TemplateFile'] = PopPpackage.msgPn0.etTemplateFile.text;
	
	params['InputFolder'] = PopPpackage.msgPn2.etInputFolder.text;
	/*
	params['OutputFolder'] = PopPpackage.msgPn3.etDestination.text;
	*/
	params['TextLocationNumber'] = PopPpackage.msgPnl.grp5a.dd1.selection;
	params['FontNumber'] = PopPpackage.msgPnl.grp6a.dd1.selection;
	params['FontStyleNumber'] = PopPpackage.msgPnl.grp7a.dd1.selection;
	params['ImageStyleNumber'] = PopPpackage.msgPnl.grp8a.dd1.selection;

	// Save the params from the above
	SaveParamsToDisk( GetDefaultParamsFile(), params );
	
	// Gets the template file from the UI
	var templateFile = PopPpackage.msgPn0.etTemplateFile.text;
	//alert(templateFile);

	
	// Gets the input folder from the UI
	var inputFolder = PopPpackage.msgPn2.etInputFolder.text;
	//alert(inputFolder);
	var inputFolder = new Folder(inputFolder);
	/*
	// Gets the output folder from the UI
	var outputFolder = PopPpackage.msgPn3.etDestination.text;
	//alert(outputFolder);
	var outputFolder = new Folder(outputFolder);
	*/

	//alert('Template="' + templateFile + '"\nImages from "' + inputFolder + '"\nSaved to "' + outputFolder +'"');

	var fontNumber = Number(PopPpackage.msgPnl.grp6a.dd1.selection.index);
	//    ChosenFontName = app.fonts[Math.round(fontNumber)].name;
    //    ChosenFontPostScriptName = app.fonts[Math.round(fontNumber)].postScriptName;
	//textFont = ChosenFontPostScriptName
	textFont = psfontlist[fontNumber];
 	//alert("ChosenFontName = " + ChosenFontName + "\nChosenFontPostScriptName = " + ChosenFontPostScriptName  );

	var textStyle = textStyleList[Number(PopPpackage.msgPnl.grp7a.dd1.selection.index)];
	var imageStyle = imageStyleList[Number(PopPpackage.msgPnl.grp8a.dd1.selection.index)];
	//alert("textStyle = "  +  textStyle + " imageStyle = " + imageStyle );

	open(File(templateFile));
	var doc = activeDocument;
	var Name='';
	var saveFile ='';
	//var templateName = activeDocument.name.replace(/\.[^\.]+$/, '');
	// Isolate Tenplate Name
	var templateName =  decodeURI(templateFile).replace(/\.[^\.]+$/, '');	// strip the extension off
	var templateName =  templateName.substr(templateName.lastIndexOf("\\")+1);	

	var layers = activeDocument.layers;
	activeDocument.activeLayer = layers[layers.length-1];						// Target Bottom Layer
	if ( !activeDocument.activeLayer.isBackgroundLayer ) {
		alert("Selected Template file does not have the Required Photoshop Background Layer");
	} else { 											// Has Background
		var abort = false;
		// ======Load Image 1 Selection===============================
		var idsetd = charIDToTypeID( "setd" );
		    var desc2 = new ActionDescriptor();
		    var idnull = charIDToTypeID( "null" );
		        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
		        var idfsel = charIDToTypeID( "fsel" );
		        ref1.putProperty( idChnl, idfsel );
		    desc2.putReference( idnull, ref1 );
		    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
		        var idChnl = charIDToTypeID( "Chnl" );
		        ref2.putName( idChnl, "Image 1" );
		    desc2.putReference( idT, ref2 );
		try{
			executeAction( idsetd, desc2, DialogModes.NO );
		}catch(e){
			alert("Selected Template file does not have the Required Image 1 Alpha Channel");
			var abort = true
		}

		var collageNumber = 1;
		var imageNumber = 1;
		var numberOfImages = getAlphaImageChannels()
		prefixlist = new Array();
		//alert("numberOfImages = " + numberOfImages );
		fileList = new Array();

		if (!abort) { 									// Create Collage
			activeDocument.selection.deselect();

			var docWidth =  app.activeDocument.width;
			var docHeight = app.activeDocument.height;
			var docResolution = app.activeDocument.resolution;

			WorkOnDupe();								// Work on duplicate of template

			// Loop Image File Start
			var fileList = inputFolder.getFiles(/\.(nef|cr3|cr2|crw|dcs|raf|arw|orf|dng|jpg|tif|psd|eps|png|bmp)$/i);

			// Loop Image File Start
			for (var i = 0; i < 1; i++) {


				if ( fileList[i] == undefined ) {				// Out of images
					alert("No Images Canceled");
				}
				else {

					//Hack for Picture Package all openimgs in template should have same orintation Portrait or Lancscape if to be framed
					for (var n = 0; n < numberOfImages ; n++) {

						var layers = activeDocument.layers;
						activeDocument.activeLayer = layers[layers.length-1-imageNumber+1];	// Target Background Layer or last placed image
						placeImage(fileList[i]);					// Place in Image
						//fileList[i] = app.activeDocument.activeLayer.name;
						//alert("Layer name =" + fileList[i] );

						// Get Smart Object current width and height
						var LB = activeDocument.activeLayer.bounds;
						var LWidth = (LB[2].value) - (LB[0].value);
						var LHeight = (LB[3].value) - (LB[1].value);
						//alert("bounds = " + LB + "\nLWidth = " + LWidth + " LHeight = " + LHeight );
						// Get Alpha Channel's width and height Selection Bounds did not work???
						makeLayer();						// Make Temp Work Layer
						loadAlpha("Image " + imageNumber );			// Load Image Alpha Channel
						fillBlack();							
						activeDocument.selection.invert();			// Inverse
						// If image size equals canvas size no pixels neill be selected clear will fail
						try{
							activeDocument.selection.clear();		// One clear did not work
							activeDocument.selection.clear();		// Two did the trick
						}catch(e){}
						activeDocument.selection.deselect();			// Deselect
						var SB = activeDocument.activeLayer.bounds;		// Get the bounds of the work layer
						var SWidth = (SB[2].value) - (SB[0].value);		// Area width
						var SHeight = (SB[3].value) - (SB[1].value);		// Area height
						activeDocument.activeLayer.remove();			// Remove Work layer

						//Rotate smart object layer to match template images orintation
						if (SWidth<SHeight&&LWidth>LHeight ) { activeDocument.activeLayer.rotate(-90.0);  } // Rotate portraits
						if (SHeight<SWidth&&LHeight>LWidth ) { activeDocument.activeLayer.rotate(-90.0);  } // Rotate landscapes
						// Get Smart Object current width and height
						var LB = activeDocument.activeLayer.bounds;
						var LWidth = (LB[2].value) - (LB[0].value);
						var LHeight = (LB[3].value) - (LB[1].value);
						//alert("bounds = " + LB + "\nLWidth = " + LWidth + " LHeight = " + LHeight );

						// Resize Smart Object Layer by some pertentage to Fill the selction
						// Anchor point Top Left Calulate width and height needed to cover Image n
						//alert("LWidth = " + LWidth + " SWidth = " + SWidth + "\nLHeight = " + LHeight + " SHeight = " + SHeight );

						if ( (LWidth >= SWidth) && (LHeight >= SHeight) ) {			// down size
							//alert("Down Sizing");
							// Both sides are larger test if Aspect Ratios are compatible
							if ( ((SWidth <= SHeight ) &&  (LWidth <= LHeight )) || ((SHeight <= SWidth ) &&  (LHeight <= LWidth )) ) {
 								// Landscape to Landscape or Portrait to Pottrait fit smaler side
								if (SWidth >= SHeight) { 				// Landscape fit Height
									//alert ("Landscape Cutout");
									var HpercentageChange = ((SHeight/LHeight)*100)
									var NWidth = LWidth * HpercentageChange / 100 ;	// % of Width is new Width
									if ( NWidth >= SWidth ) { var percentageChange = HpercentageChange ; } // % OK
									else { var percentageChange = ((SWidth/LWidth)*100);}
								}
								else {							// Portrait fit width
									//alert ("Portrait Cutout");
									var WpercentageChange = ((SWidth/LWidth)*100);
									var NHeight = LHeight * WpercentageChange / 100 ;	// % of hight is new height
									if ( NHeight >= SHeight ) { var percentageChange = WpercentageChange ; } // % OK
									else { var percentageChange = ((SHeight/LHeight)*100); }
								}
							}
							else {								// aspect Ratio change
								//alert("Aspect Ratio Change");
								if (SWidth >= SHeight) { 				// Landscape fit Portrait width to landscape width
									//alert ("Landscape Cutout");
									var percentageChange = ((SWidth/LWidth)*100);
								}
								else {							// Portrait fit Landscape height to Portrait height
									//alert ("Portrait Cutout");
									var percentageChange = ((SHeight/LHeight)*100);
								}
							}
						}
						else {									// up size
							//alert("Up Sizing");
							if ( LWidth <= SWidth && LHeight <= SHeight ) {			// Both image sides need to be increased in size
				 				//alert("Up Sizing both");
								if ( SWidth <= SHeight ) { 				//test if fitting image width will work
									var WpercentageChange = ((SWidth/LWidth)*100);	//calc % fit image width to cutout width
									var NHeight = LHeight * WpercentageChange / 100 ;	// % of hight is new height
									if ( NHeight >= SHeight ) { var percentageChange = WpercentageChange ; } // % OK
									else { var percentageChange = ((SHeight/LHeight)*100); }
								}
								else {
									var HpercentageChange = ((SHeight/LHeight)*100)
									var NWidth = LWidth * HpercentageChange / 100 ;	// % of Width is new Width
									if ( NWidth >= SWidth ) { var percentageChange = HpercentageChange ; } // % OK
									else { var percentageChange = ((SWidth/LWidth)*100); }
								}
							}
							else {								// only one side needs to be increassed in side
				 				//alert("only one side needs up sizing");
								if ( SWidth <= LWidth ) {
									var HpercentageChange = ((SHeight/LHeight)*100)
									var NWidth = LWidth * HpercentageChange / 100 ;	// % of Width is new Width
									if ( NWidth >= SWidth ) { var percentageChange = HpercentageChange ; } // % OK
									else { var percentageChange = ((SWidth/LWidth)*100); }
								} 							// then fit the image Hieght to cutout
								else {
									var WpercentageChange = ((SWidth/LWidth)*100);
									var NHeight = LHeight * WpercentageChange / 100 ;	// % of hight is new height
									if ( NHeight >= SHeight ) { var percentageChange = WpercentageChange ; } // % OK
									else { var percentageChange = ((SHeight/LHeight)*100); }
								}	// fit the image width to cutout
							}
						}
						var NWidth = LWidth * percentageChange / 100 ;	// % of Width is new Width
						var NHeight = LHeight * percentageChange / 100 ;	// % of hight is new height
						//alert("Image Width = " + LWidth + " Height = " +  LHeight
						//	+ "\nCutout Width = " + SWidth + " Height = " +  SHeight
						//	+ "\npercentageChange = " + percentageChange
						//	+ "\nNew Image Width = " + NWidth + " Height = " +  NHeight );
						// Transform Smart Object Layer
						var userResampleMethod = app.preferences.interpolation;
						app.preferences.interpolation = ResampleMethod.BILINEAR;	// resample interpolation biliner
						activeDocument.activeLayer.resize(percentageChange,percentageChange,AnchorPosition.MIDDLECENTER);
						app.preferences.interpolation = userResampleMethod;
						// Load Alpha Channel as a selection and align image to it
						loadAlpha("Image " + imageNumber);
						//align('AdTp');
						//align('AdLf');
						align('AdCV');
						align('AdCH');
						// Add Layer mask using Alpha channel Image1
						// linkedlayerMask();						// Add inked Layer Mask	
						layerMask();							// Add Layer Mask
						targetRGB()
						// Add Photo Collage Layer Style to image layer
						addStyle(imageStyle);

						// Isolate Image name
						var Name =  decodeURI(fileList[i]).replace(/\.[^\.]+$/, '');	// strip the extension off
						var imagePath = "";
						while (Name.indexOf("/") != -1 ) {				// Strip Path
                                               	 imagePath= imagePath + Name.substr(0, Name.indexOf("/") + 1);
							Name = Name.substr(Name.indexOf("/") + 1 ,);		
							}
						if (Name.indexOf("#") != -1 ) {					// Strip any prefix sequence number off	
							prefixlist[imageNumber - 1] = Name.substr(0,Name.indexOf("#") );
							Name = Name.substr(Name.indexOf("#") + 1 ,);		
						}

						// Add Filename Text if called for
						if ( PopPpackage.msgPnl.StampImage.st.value) {
							stampFilename(textFont,textSizeFactor,textColor,Name);

							loadAlpha("Image " + imageNumber);

							//var Position = 5;
							var Position = Number(PopPpackage.msgPnl.grp5a.dd1.selection.index) + 1;
							switch (Position){
							case 1 : align('AdLf'); align('AdTp'); break;
							case 2 : align('AdCH'); align('AdTp'); break;
							case 3 : align('AdRg'); align('AdTp'); break;
							case 4 : align('AdLf'); align('AdCV'); break;
							case 5 : align('AdCH'); align('AdCV'); activeDocument.selection.deselect(); activeDocument.activeLayer.rotate(textAngle); break;
							case 6 : align('AdRg'); align('AdCV'); break;
							case 7 : align('AdLf'); align('AdBt'); break;
							case 8 : align('AdCH'); align('AdBt'); break;
							case 9 : align('AdRg'); align('AdBt'); break;
							default : break;
							}

							activeDocument.selection.deselect();
							// Add text Layer's layer style
							addStyle(textStyle);

							// could add code to do something with the image prefix info if it exists in prefixlist
							if ( prefixlist[imageNumber -1] != undefined ) {}

				  		}
						imageNumber = imageNumber + 1;
					} 
				} // Image
			}
		} // end create collage
		//doAction("Set View Fit on Screen", "Actions for Scripts");				// Set View for Place
		SetViewFitonScreen()
	} // end has Background
} // end if (runDvackage) == 1)

// Return the app preferences
app.preferences.rulerUnits = startRulerUnits;
app.preferences.typeUnits = startTypeUnits;
app.displayDialogs = saveDialogMode;

//////////////////////////////////////////////////////////////////////////////////
//				The end						//
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
//			Helper Functions					//
//////////////////////////////////////////////////////////////////////////////////

function placeImage(file) {
	/*
        // Insure Photoshop Preference is not resize paste place
	var idsetd = charIDToTypeID( "setd" );
	    var desc7 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref4 = new ActionReference();
	        var idPrpr = charIDToTypeID( "Prpr" );
	        var idGnrP = charIDToTypeID( "GnrP" );
	        ref4.putProperty( idPrpr, idGnrP );
	        var idcapp = charIDToTypeID( "capp" );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref4.putEnumerated( idcapp, idOrdn, idTrgt );
	    desc7.putReference( idnull, ref4 );
	    var idT = charIDToTypeID( "T   " );
	        var desc8 = new ActionDescriptor();
	        var idresizePastePlace = stringIDToTypeID( "resizePastePlace" );
	        desc8.putBoolean( idresizePastePlace, false );
	    var idGnrP = charIDToTypeID( "GnrP" );
	    desc7.putObject( idT, idGnrP, desc8 );
	executeAction( idsetd, desc7, DialogModes.NO );
	*/
	// =======avoid bug in cs2 and maybe CS4 ==================================
	var idslct = charIDToTypeID( "slct" );
	    var desc5 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref3 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idRGB = charIDToTypeID( "RGB " );
	        ref3.putEnumerated( idChnl, idChnl, idRGB );
	    desc5.putReference( idnull, ref3 );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc5.putBoolean( idMkVs, false );
	executeAction( idslct, desc5, DialogModes.NO );

	// Place in the file
	var idPlc = charIDToTypeID( "Plc " );
	    var desc5 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	    desc5.putPath( idnull, new File( file ) );
	    var idFTcs = charIDToTypeID( "FTcs" );
	    var idQCSt = charIDToTypeID( "QCSt" );
	    var idQcsa = charIDToTypeID( "Qcsa" );
	    desc5.putEnumerated( idFTcs, idQCSt, idQcsa );
	    var idOfst = charIDToTypeID( "Ofst" );
	        var desc6 = new ActionDescriptor();
	        var idHrzn = charIDToTypeID( "Hrzn" );
	        var idPxl = charIDToTypeID( "#Pxl" );
	        desc6.putUnitDouble( idHrzn, idPxl, 0.000000 );
	        var idVrtc = charIDToTypeID( "Vrtc" );
	        var idPxl = charIDToTypeID( "#Pxl" );
	        desc6.putUnitDouble( idVrtc, idPxl, 0.000000 );
	    var idOfst = charIDToTypeID( "Ofst" );
	    desc5.putObject( idOfst, idOfst, desc6 );
	executeAction( idPlc, desc5, DialogModes.NO );

	// because can't get the scale of a smart object, reset to 100%
	activeDocument.activeLayer.resize(100 ,100,AnchorPosition.MIDDLECENTER);

	return app.activeDocument.activeLayer;
}

function targetRGB() {

	// =======avoid bug in cs2 and maybe CS4 ==================================
	var idslct = charIDToTypeID( "slct" );
	    var desc5 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref3 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idRGB = charIDToTypeID( "RGB " );
	        ref3.putEnumerated( idChnl, idChnl, idRGB );
	    desc5.putReference( idnull, ref3 );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc5.putBoolean( idMkVs, false );
	executeAction( idslct, desc5, DialogModes.NO );
}


function stampFilename(textFont,sizeFactor,textColor,Name) {
        /* textX and TextY positions text placement 0 and 0 Top Left corner of image in pixels	*/
	var textX = 0;									
	var textY = 0;	
	/* END Variables hard coded */

	var txtWidth =  app.activeDocument.width * .90 ;				// 90% of Doc with
	var txtHeight = app.activeDocument.height * .90 ;				// 90% of doc height

	activeDocument.selection.deselect();						// make sure no active selection
	text_layer = activeDocument.artLayers.add();					// Add a Layer
	text_layer.name = Name ;							// Name Layer
	text_layer.kind = LayerKind.TEXT;						// Make Layer a Text Layer
	text_layer.textItem.color = textColor;						// set text layer color

	/* Do not set TextType to Pargarph so the layer can be aligned
 	text_layer.textItem.kind = TextType.PARAGRAPHTEXT;				// Set text layers text type
 	*/

	text_layer.textItem.font = textFont;						// set text font
	text_layer.blendMode = BlendMode.NORMAL						// blend mode
	text_layer.textItem.fauxBold = false;						// Bold
	text_layer.textItem.fauxItalic = false;						// Italic
	text_layer.textItem.underline = UnderlineType.UNDERLINEOFF;			// Underlibn
	text_layer.textItem.capitalization = TextCase.NORMAL;				// Case
	text_layer.textItem.antiAliasMethod = AntiAlias.SHARP;				// antiAlias

	/* Calulate font size to use for keep size same for landscape and portrait base on text area size */
	if (txtWidth >= txtHeight) {var fontSize = Math.round(txtHeight / (30 * sizeFactor));}
	else {var fontSize = Math.round(txtWidth / (30 * sizeFactor));}
	if (fontSize<10){fontSize=10};							// don't use Font size smaller then 10
	text_layer.textItem.size = fontSize;						// set text font Size

	text_layer.textItem.position = Array(textX, (textY + fontSize ));		// set text layers position in and down for Stamp add in fontsize

	// Do not set Text Area so so the layer can be aligned

	text_layer.textItem.contents = Name ;
}

function WorkOnDupe() {
	var idDplc = charIDToTypeID( "Dplc" );
	    var desc2 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref1 = new ActionReference();
	        var idDcmn = charIDToTypeID( "Dcmn" );
 	       var idOrdn = charIDToTypeID( "Ordn" );
 	       var idFrst = charIDToTypeID( "Frst" );
 	       ref1.putEnumerated( idDcmn, idOrdn, idFrst );
	    desc2.putReference( idnull, ref1 );
	executeAction( idDplc, desc2, DialogModes.NO );

	var idslct = charIDToTypeID( "slct" );
 	   var desc3 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
      	  var ref2 = new ActionReference();
     	   var idDcmn = charIDToTypeID( "Dcmn" );
    	    ref2.putOffset( idDcmn, -1 );
  	  desc3.putReference( idnull, ref2 );
	executeAction( idslct, desc3, DialogModes.NO );

	activeDocument.close(SaveOptions.DONOTSAVECHANGES);
}

function makeLayer(){
	var idMk = charIDToTypeID( "Mk  " );
	    var desc4 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref3 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        ref3.putClass( idLyr );
	    desc4.putReference( idnull, ref3 );
	executeAction( idMk, desc4, DialogModes.NO );
}


function layerBackward(){
	var idslct = charIDToTypeID( "slct" );
	    var desc9 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
 	       var ref6 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idBckw = charIDToTypeID( "Bckw" );
 	       ref6.putEnumerated( idLyr, idOrdn, idBckw );
	    desc9.putReference( idnull, ref6 );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc9.putBoolean( idMkVs, false );
	executeAction( idslct, desc9, DialogModes.NO );
}

function layerForward(){
	var idslct = charIDToTypeID( "slct" );
	    var desc26 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref19 = new ActionReference();
 	       var idLyr = charIDToTypeID( "Lyr " );
 	       var idOrdn = charIDToTypeID( "Ordn" );
	        var idFrwr = charIDToTypeID( "Frwr" );
	        ref19.putEnumerated( idLyr, idOrdn, idFrwr );
 	   desc26.putReference( idnull, ref19 );
	    var idMkVs = charIDToTypeID( "MkVs" );
	    desc26.putBoolean( idMkVs, false );
	executeAction( idslct, desc26, DialogModes.NO );
}

function fillBlack(){
// ============Fill with Black==========================================
	var idFl = charIDToTypeID( "Fl  " );
 	   var desc11 = new ActionDescriptor();
	    var idUsng = charIDToTypeID( "Usng" );
	    var idFlCn = charIDToTypeID( "FlCn" );
  	  var idBlck = charIDToTypeID( "Blck" );
 	   desc11.putEnumerated( idUsng, idFlCn, idBlck );
	    var idOpct = charIDToTypeID( "Opct" );
	    var idPrc = charIDToTypeID( "#Prc" );
	    desc11.putUnitDouble( idOpct, idPrc, 100.000000 );
	    var idMd = charIDToTypeID( "Md  " );
	    var idBlnM = charIDToTypeID( "BlnM" );
	    var idNrml = charIDToTypeID( "Nrml" );
	    desc11.putEnumerated( idMd, idBlnM, idNrml );
	executeAction( idFl, desc11, DialogModes.NO );
}

function fillColor(){
	var idFl = charIDToTypeID( "Fl  " );
  	  var desc17 = new ActionDescriptor();
 	   var idUsng = charIDToTypeID( "Usng" );
 	   var idFlCn = charIDToTypeID( "FlCn" );
	    var idClr = charIDToTypeID( "Clr " );
	    desc17.putEnumerated( idUsng, idFlCn, idClr );
 	   var idClr = charIDToTypeID( "Clr " );
 	       var desc18 = new ActionDescriptor();
 	       var idH = charIDToTypeID( "H   " );
	        var idAng = charIDToTypeID( "#Ang" );
	        desc18.putUnitDouble( idH, idAng, 172.232666 );
	        var idStrt = charIDToTypeID( "Strt" );
	        desc18.putDouble( idStrt, 35.686275 );
	        var idBrgh = charIDToTypeID( "Brgh" );
	        desc18.putDouble( idBrgh, 93.725490 );
	    var idHSBC = charIDToTypeID( "HSBC" );
 	   desc17.putObject( idClr, idHSBC, desc18 );
	    var idOpct = charIDToTypeID( "Opct" );
	    var idPrc = charIDToTypeID( "#Prc" );
	    desc17.putUnitDouble( idOpct, idPrc, 100.000000 );
 	   var idMd = charIDToTypeID( "Md  " );
	    var idBlnM = charIDToTypeID( "BlnM" );
	    var idNrml = charIDToTypeID( "Nrml" );
	    desc17.putEnumerated( idMd, idBlnM, idNrml );
	executeAction( idFl, desc17, DialogModes.NO );
}

function deleteSelection(){
	var idDlt = charIDToTypeID( "Dlt " );
	executeAction( idDlt, undefined, DialogModes.NO );
}

function deleteLayer(){
	var idDlt = charIDToTypeID( "Dlt " );
  	  var desc25 = new ActionDescriptor();
   	 var idnull = charIDToTypeID( "null" );
    	    var ref18 = new ActionReference();
    	    var idLyr = charIDToTypeID( "Lyr " );
  	      var idOrdn = charIDToTypeID( "Ordn" );
  	      var idTrgt = charIDToTypeID( "Trgt" );
 	       ref18.putEnumerated( idLyr, idOrdn, idTrgt );
 	   desc25.putReference( idnull, ref18 );
	executeAction( idDlt, desc25, DialogModes.NO );
}

function addStyle(Style){
	var idASty = charIDToTypeID( "ASty" );
	    var desc20 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref3 = new ActionReference();
	        var idStyl = charIDToTypeID( "Styl" );
	        ref3.putName( idStyl, Style );
	    desc20.putReference( idnull, ref3 );
	    var idT = charIDToTypeID( "T   " );
	        var ref4 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref4.putEnumerated( idLyr, idOrdn, idTrgt );
	    desc20.putReference( idT, ref4 );
	try{
		executeAction( idASty, desc20, DialogModes.NO);
	}catch(e){}
}

function SaveAsJPEG(saveFile, jpegQuality){
	var doc = activeDocument;
	if (doc.bitsPerChannel != BitsPerChannelType.EIGHT) doc.bitsPerChannel = BitsPerChannelType.EIGHT;
	jpgSaveOptions = new JPEGSaveOptions();
	jpgSaveOptions.embedColorProfile = true;
	jpgSaveOptions.formatOptions = FormatOptions.STANDARDBASELINE;
	jpgSaveOptions.matte = MatteType.NONE;
	jpgSaveOptions.quality = jpegQuality;
	activeDocument.saveAs(File(saveFile+".jpg"), jpgSaveOptions, true,Extension.LOWERCASE);
}

function SaveAsPSD( inFileName, inEmbedICC ) {
	var psdSaveOptions = new PhotoshopSaveOptions();
	psdSaveOptions.embedColorProfile = inEmbedICC;
	app.activeDocument.saveAs( File( inFileName + ".psd" ), psdSaveOptions );
}

function SaveAsPDF( saveFile ) {
	var idsave = charIDToTypeID( "save" );
	    var desc2 = new ActionDescriptor();
	    var idAs = charIDToTypeID( "As  " );
	        var desc3 = new ActionDescriptor();
	        var idpdfPresetFilename = stringIDToTypeID( "pdfPresetFilename" );
	        desc3.putString( idpdfPresetFilename, "High Quality Print" );
	        var idpdfCompatibilityLevel = stringIDToTypeID( "pdfCompatibilityLevel" );
	        var idpdfCompatibilityLevel = stringIDToTypeID( "pdfCompatibilityLevel" );
	        var idpdfoneeight = stringIDToTypeID( "pdf18" );
	        desc3.putEnumerated( idpdfCompatibilityLevel, idpdfCompatibilityLevel, idpdfoneeight );
	        var idpdfCompressionType = stringIDToTypeID( "pdfCompressionType" );
	        desc3.putInteger( idpdfCompressionType, 7 );
	    var idPhtP = charIDToTypeID( "PhtP" );
	    desc2.putObject( idAs, idPhtP, desc3 );
	    var idIn = charIDToTypeID( "In  " );
	    desc2.putPath( idIn, new File( saveFile + ".pdf" ) );
	executeAction( idsave, desc2, DialogModes.NO );
}

function align(method) {
	var desc = new ActionDescriptor();
	var ref = new ActionReference();
	ref.putEnumerated( charIDToTypeID( "Lyr " ), charIDToTypeID( "Ordn" ), charIDToTypeID( "Trgt" ) );
	desc.putReference( charIDToTypeID( "null" ), ref );
	desc.putEnumerated( charIDToTypeID( "Usng" ), charIDToTypeID( "ADSt" ), charIDToTypeID( method ) );
	try{
		executeAction( charIDToTypeID( "Algn" ), desc, DialogModes.NO );
	}catch(e){}
}

function getAlphaImageChannels() {
	for (var n = 1; n < 999; n++) {
		// ======Load Image n Selection===============================
		var idsetd = charIDToTypeID( "setd" );
		    var desc2 = new ActionDescriptor();
		    var idnull = charIDToTypeID( "null" );
		        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
		        var idfsel = charIDToTypeID( "fsel" );
		        ref1.putProperty( idChnl, idfsel );
		    desc2.putReference( idnull, ref1 );
		    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
		        var idChnl = charIDToTypeID( "Chnl" );
		        ref2.putName( idChnl, "Image " + n );
		    desc2.putReference( idT, ref2 );
		try{
			executeAction( idsetd, desc2, DialogModes.NO );
		}catch(e){
			//alert ("n = " + n);
			return n - 1;
		}

	}
}


// ======Load Alpha Channel Selection===============================
function loadAlpha(channel) {
	var idsetd = charIDToTypeID( "setd" );
	    var desc2 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref1 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idfsel = charIDToTypeID( "fsel" );
	        ref1.putProperty( idChnl, idfsel );
	    desc2.putReference( idnull, ref1 );
	    var idT = charIDToTypeID( "T   " );
	        var ref2 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        ref2.putName( idChnl, channel );
	    desc2.putReference( idT, ref2 );
	executeAction( idsetd, desc2, DialogModes.NO );
}

// =======linked layer Mask========================================
function linkedlayerMask() {
	var idMk = charIDToTypeID( "Mk  " );
	    var desc3 = new ActionDescriptor();
	    var idNw = charIDToTypeID( "Nw  " );
	    var idChnl = charIDToTypeID( "Chnl" );
	    desc3.putClass( idNw, idChnl );
	    var idAt = charIDToTypeID( "At  " );
	        var ref3 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idMsk = charIDToTypeID( "Msk " );
	        ref3.putEnumerated( idChnl, idChnl, idMsk );
	    desc3.putReference( idAt, ref3 );
	    var idUsng = charIDToTypeID( "Usng" );
	    var idUsrM = charIDToTypeID( "UsrM" );
	    var idRvlS = charIDToTypeID( "RvlS" );
	    desc3.putEnumerated( idUsng, idUsrM, idRvlS );
	executeAction( idMk, desc3, DialogModes.NO );
}

// =======Un linked layer Mask========================================
function layerMask() {
	var idMk = charIDToTypeID( "Mk  " );
	    var desc3 = new ActionDescriptor();
	    var idNw = charIDToTypeID( "Nw  " );
	    var idChnl = charIDToTypeID( "Chnl" );
	    desc3.putClass( idNw, idChnl );
	    var idAt = charIDToTypeID( "At  " );
	        var ref3 = new ActionReference();
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idChnl = charIDToTypeID( "Chnl" );
	        var idMsk = charIDToTypeID( "Msk " );
	        ref3.putEnumerated( idChnl, idChnl, idMsk );
	    desc3.putReference( idAt, ref3 );
	    var idUsng = charIDToTypeID( "Usng" );
	    var idUsrM = charIDToTypeID( "UsrM" );
	    var idRvlS = charIDToTypeID( "RvlS" );
	    desc3.putEnumerated( idUsng, idUsrM, idRvlS );
	executeAction( idMk, desc3, DialogModes.NO );
	// =======================================================
	var idsetd = charIDToTypeID( "setd" );
	    var desc2 = new ActionDescriptor();
	    var idnull = charIDToTypeID( "null" );
	        var ref1 = new ActionReference();
	        var idLyr = charIDToTypeID( "Lyr " );
	        var idOrdn = charIDToTypeID( "Ordn" );
	        var idTrgt = charIDToTypeID( "Trgt" );
	        ref1.putEnumerated( idLyr, idOrdn, idTrgt );
	    desc2.putReference( idnull, ref1 );
	    var idT = charIDToTypeID( "T   " );
	        var desc3 = new ActionDescriptor();
	        var idUsrs = charIDToTypeID( "Usrs" );
	        desc3.putBoolean( idUsrs, false );
	    var idLyr = charIDToTypeID( "Lyr " );
	    desc2.putObject( idT, idLyr, desc3 );
	executeAction( idsetd, desc2, DialogModes.NO );
}

function help() {
	try{
		var URL = new File(Folder.temp + "/PhotoCollageToolkit.html");
		URL.open("w");
		URL.writeln('<html><HEAD><meta HTTP-EQUIV="REFRESH" content="0; url=http://www.mouseprints.net/old/dpr/PhotoCollageToolkit.html"></HEAD></HTML>');
		URL.close();
		URL.execute();
	}catch(e){
		alert("Error, Can Not Open.");
	};
}

///////////////////////////////////////////////////////////////////////////////
// Function: initExportInfo
// Usage: create our default parameters
// Input: a new Object
// Return: a new object with params set to default
///////////////////////////////////////////////////////////////////////////////
function initExportInfo(exportInfo) {
    exportInfo.destination = new String("");
    exportInfo.fileNamePrefix = new String("untitled_");
    exportInfo.visibleOnly = false;
//    exportInfo.fileType = psdIndex;
    exportInfo.icc = true;
    exportInfo.jpegQuality = 8;
    exportInfo.psdMaxComp = true;
    exportInfo.tiffCompression = TIFFEncoding.NONE;
    exportInfo.tiffJpegQuality = 8;
    exportInfo.pdfEncoding = PDFEncoding.JPEG;
    exportInfo.pdfJpegQuality = 8;
    exportInfo.targaDepth = TargaBitsPerPixels.TWENTYFOUR;
    exportInfo.bmpDepth = BMPDepthType.TWENTYFOUR;

    try {
         exportInfo.destination = Folder(app.activeDocument.fullName.parent).fsName; // destination folder
        var tmp = app.activeDocument.fullName.name;
        exportInfo.fileNamePrefix = decodeURI(tmp.substring(0, tmp.indexOf("."))); // filename body part
    } catch(someError) {
        exportInfo.destination = new String("");
//        exportInfo.fileNamePrefix = app.activeDocument.name; // filename body part
    }
}

// Find the location where this script resides
function findScript() {
	var where = "";
	try {
		FORCEERROR = FORCERRROR;
	}
	catch(err) {
		// alert(err.fileName);
		// alert(File(err.fileName).exists);
		where = File(err.fileName);
	}
	return where;
}

// Function for returning current date and time

    function getDateTime() {
        var date = new Date();
        var dateTime = "";
        if ((date.getMonth() + 1) < 10) {
            dateTime += "0" + (date.getMonth() + 1) + "/";
        } else {
            dateTime += (date.getMonth() + 1) + "/";
        }
        if (date.getDate() < 10) {
            dateTime += "0" + date.getDate() + "/";
        } else {
            dateTime += date.getDate() + "/";
        }
        dateTime += date.getFullYear() + ", ";
        if (date.getHours() < 10) {
            dateTime += "0" + date.getHours() + ":";
        } else {
            dateTime += date.getHours() + ":";
        }
        if (date.getMinutes() < 10) {
            dateTime += "0" + date.getMinutes() + ":";
        } else {
            dateTime += date.getMinutes() + ":";
        }
        if (date.getSeconds() < 10) {
            dateTime += "0" + date.getSeconds();
        } else {
            dateTime += date.getSeconds();
        }
        return dateTime;
    }

// resetPrefs function for resetting the preferences
	function resetPrefs() {
		preferences.rulerUnits = startRulerUnits;
		preferences.typeUnits = startTypeUnits;
		displayDialogs = startDisplayDialogs;
	}

// CheckVersion
function CheckVersion() {
	var numberArray = version.split(".");
	if ( numberArray[0] < 9 ) {
		alert( "You must use Photoshop CS2 or later to run this script!" );
		throw( "You must use Photoshop CS2 or later to run this script!" );
	}
}

// load my params from the xml file on disk if it exists
// gParams["myoptionname"] = myoptionvalue
// I wrote a very simple xml parser, I'm sure it needs work
function LoadParamsFromDisk ( loadFile, params ) {
	// var params = new Array();
	if ( loadFile.exists ) {
		loadFile.open( "r" );
		var projectSpace = ReadHeader( loadFile );
		if ( projectSpace == GetScriptNameForXML() ) {
			while ( ! loadFile.eof ) {
				var starter = ReadHeader( loadFile );
				var data = ReadData( loadFile );
				var ender = ReadHeader( loadFile );
				if ( ( "/" + starter ) == ender ) {
					params[starter] = data;
				}
				// force boolean values to boolean types
				if ( data == "true" || data == "false" ) {
					params[starter] = data == "true";
				}
			}
		}
		loadFile.close();
		if ( params["version"] != gVersion ) {
			// do something here to fix version conflicts
			// this should do it
			params["version"] = gVersion;
		}
	}
	return params;
}

// save out my params, this is much easier
function SaveParamsToDisk ( saveFile, params ) {
	saveFile.encoding = "UTF8";
	saveFile.open( "w", "TEXT", "????" );
	// unicode signature, this is UTF16 but will convert to UTF8 "EF BB BF"
	saveFile.write("\uFEFF");
	var scriptNameForXML = GetScriptNameForXML();
	saveFile.writeln( "<" + scriptNameForXML + ">" );
	for ( var p in params ) {
		saveFile.writeln( "\t<" + p + ">" + params[p] + "</" + p + ">" );
	}
	saveFile.writeln( "</" + scriptNameForXML + ">" );
	saveFile.close();
}

// you can't save certain characters in xml, strip them here
// this list is not complete
function GetScriptNameForXML () {
	var scriptNameForXML = new String( gScriptName );
	var charsToStrip = Array( " ", "'", "." );
	for (var a = 0; a < charsToStrip.length; a++ )  {
		var nameArray = scriptNameForXML.split( charsToStrip[a] );
		scriptNameForXML = "";
		for ( var b = 0; b < nameArray.length; b++ ) {
			scriptNameForXML += nameArray[b];
		}
	}
	return scriptNameForXML;
}

// figure out what I call my params file
function GetDefaultParamsFile() {
	//var paramsFolder = new Folder( path + "/Presets/" + gScriptName );
	//var paramsFolder = new Folder( Folder.temp + "/JJMack's Scripts/" + gScriptName );
	var paramsFolder = new Folder( "~/Application Data/JJMack's Scripts/" + gScriptName );
	//alert("paramsFolder = " + paramsFolder );
	paramsFolder.create();
	return ( new File( paramsFolder + "/" + gScriptName + ".xml" ) );
}

// a very crude xml parser, this reads the "Tag" of the <Tag>Data</Tag>
function ReadHeader( inFile ) {
	var returnValue = "";
	if ( ! inFile.eof ) {
		var c = "";
		while ( c != "<" && ! inFile.eof ) {
			c = inFile.read( 1 );
		}
		while ( c != ">" && ! inFile.eof ) {
			c = inFile.read( 1 );
			if ( c != ">" ) {
				returnValue += c;
			}
		}
	} else {
		returnValue = "end of file";
	}
	return returnValue;
}

// very crude xml parser, this reads the "Data" of the <Tag>Data</Tag>
function ReadData( inFile ) {
	var returnValue = "";
	if ( ! inFile.eof ) {
		var c = "";
		while ( c != "<" && ! inFile.eof ) {
			c = inFile.read( 1 );
			if ( c != "<" ) {
				returnValue += c;
			}
		}
		inFile.seek( -1, 1 );
	}
	return returnValue;
}


// Actions converted with X's ActionFileToJavascript

//==================== Set View for Place ==============
function SetViewforPlace() {
  // Menu View>Fit On Screen
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('FtOn'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
  // Menu View>Zoom out
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('ZmOt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
  // Menu View>screen Mode Full Screen With Menubar
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), sTID("screenModeFullScreenWithMenubar"));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
};

//==================== Interactive Place ==============
function InteractivePlace() {
  // Menu File>Place
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('Plce'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
};

//==================== Interactive Transform ==============
function InteractiveTransform() {
  // Menu Edit>Free transform
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('FrTr'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
};

//==================== Set View Fit on Screen ==============
function SetViewFitonScreen() {
  // Menu View>screen Mode Standard
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), sTID("screenModeStandard"));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
  // Menu View>Fit on screen
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Mn  '), cTID('MnIt'), cTID('FtOn'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(cTID('slct'), desc1, DialogModes.NO);
};

