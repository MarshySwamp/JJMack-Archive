Place the .jxs files in Photoshop Presets\Scripts Folder
Drop the .atn files and .asl files onto Photoshop to load the actions and Layer styles
Unzip CollageTemplates.zip into "C:\Program Files\Adobe\Adobe Photoshop Templates" or any folder you want to keep your collage templates in.
You will see the scripts listed in Photoshop menu File>Scripts>script name

Files in zip

 1.) ReadMe.txt (this text)

 2.) JJmack's Photo Collage Toolkit Scripts.atn
 3.) SnowGlobe.atn

 4.) Photo Collage Styles.asl
 5.) Photo Collage Text Styles.asl

 6.) CollageTemplates.zip

 7.) HelpPhotoCollageToolkit.jsx
 8.) LayerToAlphaChan.jsx
 9.) CollageTemplateBuilder.jsx
10.) TestCollageTemplate.jsx
11.) InteractivePopulateCollage.jsx
12.) PopulateCollageTemplate.jsx
13.) BatchOneImageCollage.jsx
14.) BatchMultiImageCollage.jsx
15.) ReplaceCollageImage.jsx
16.) ChangeTextSize.jsx
17.) PasteImageRoll.jsx
18.) BatchPicturePackage.jsx
19.) BatchPicturePackageNoRotate.jsx
20.) PopulatePicturePackage.jsx
21.) PCTpreferences.jsx

22.) BatchMockupTemplates.jsx
23.) BatchUpdateSmartObject.jsx
24.) BatchReplaceOneObject.jsx
25.) PopulateAlbumPageMockups.jsx